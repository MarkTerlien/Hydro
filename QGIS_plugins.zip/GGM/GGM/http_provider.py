#!/usr/bin/env python

###################################################
#                                                 #
# Class to validate ISO19115 with Geonovum       # 
#                                                 #
# Author: MTJ                                     #
# Date:   1-8-2012                                #
#                                                 #
###################################################

import mimetypes
import urllib2

class iso19115validator :
    
    def __init__( self, url, proxy ):
        
        try :
            
            if url == None :            
                self.url = 'http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService'
            else :
                self.url = url
            if proxy == None :
                self.proxy = {'http': 'http://172.29.10.10:3128'}
            else :
                self.proxy = proxy
            
            # Force urllib2 to use proxy
            proxy_support = urllib2.ProxyHandler(self.proxy)
            opener = urllib2.build_opener(proxy_support)
            urllib2.install_opener(opener)
            
        except Exception, err:
            raise    


    def validate_file ( self, file_name, validation_type_id ) :
        try :
            
            #test_urllib(URL, "/genericvalidator/xmlService/validateFileService", [("id", 140)], [("file", "deNieuweKaartvanNederland.xml" ,open("C:/projects/ggm/testdata/deNieuweKaartvanNederland.xml", "rb").read())])
            fields = [("id", validation_type_id)]   
            files = [("file", "deNieuweKaartvanNederland.xml" ,open(file_name, "rb").read())]
            
            content_type, body = encode_multipart_formdata(fields, files)    
            #request = urllib2.Request('http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService')
            request = urllib2.Request(self.url)
            request.add_header('Content-type', content_type)
            request.add_header('Content-length', len(body))
            request.add_data(body) 
        
            print
            print 'OUTGOING DATA:'
            print request.get_data()
        
            print
            print 'SERVER RESPONSE:'
            print urllib2.urlopen(request).read()              
            

        except Exception, err:
            raise              

    def encode_multipart_formdata( self, fields, files):
        LIMIT = '----------lImIt_of_THE_fIle_eW_$'
        CRLF = '\r\n'
        L = []
        for (key, value) in fields:
            L.append('--' + LIMIT)
            L.append('Content-Disposition: form-data; name="%s"' % key)
            L.append('')
            L.append(str(value))
        for (key, filename, value) in files:
            L.append('--' + LIMIT)
            L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
            L.append('Content-Type: %s' % get_content_type(filename))
            L.append('')
            L.append(str(value))
        L.append('--' + LIMIT + '--')
        L.append('')
        body = CRLF.join(L)
        content_type = 'multipart/form-data; boundary=%s' % LIMIT
        return content_type, body
    
    def get_content_type( self, filename):
        return mimetypes.guess_type(filename)[0] or 'application/octet-stream'

            
            """

#response = minidom.parse(urllib.urlopen(url, proxies = {'http': PROXY}))
PROXY = 'http://172.29.10.10:3128'
URL = 'validatie-dataspecificaties.geostandaarden.nl'
import httplib



def post_multipart(host, selector, fields, files):
    
    content_type, body = encode_multipart_formdata(fields, files)
    
    print content_type
    print body
    
    #if urllib2.getproxies().get('http') :    
    #h = httplib.HTTPConnection("172.29.10.10", 3128)
    #h.putrequest('POST', 'http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService')
    #else :
    h = httplib.HTTP(host)
    h.putrequest('POST', selector)
    
    h.putheader('content-type', content_type)
    h.putheader('content-length', str(len(body)))
    h.endheaders()
    h.send(body)
    errcode, errmsg, headers = h.getreply()
    return h.file.read()


def test_urllib ( host, selector, fields, files ) :
    
    

    content_type, body = encode_multipart_formdata(fields, files)    
    request = urllib2.Request('http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService')
    request.add_header('Content-type', content_type)
    request.add_header('Content-length', len(body))
    request.add_data(body) 

    print
    print 'OUTGOING DATA:'
    print request.get_data()

    print
    print 'SERVER RESPONSE:'
    print urllib2.urlopen(request).read()   

def encode_multipart_formdata(fields, files):
    LIMIT = '----------lImIt_of_THE_fIle_eW_$'
    CRLF = '\r\n'
    L = []
    for (key, value) in fields:
        L.append('--' + LIMIT)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(str(value))
    for (key, filename, value) in files:
        L.append('--' + LIMIT)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % get_content_type(filename))
        L.append('')
        L.append(str(value))
    L.append('--' + LIMIT + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % LIMIT
    return content_type, body

def get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'

    
    


#########################################################


proxy_support = urllib2.ProxyHandler({'http': 'http://172.29.10.10:3128'})
opener = urllib2.build_opener(proxy_support)
urllib2.install_opener(opener)


#print http_proxy
#result = post_multipart(URL, "/genericvalidator/xmlService/validateFileService", [("id", 140)], [("file", "deNieuweKaartvanNederland.xml" ,open("C:/projects/ggm/testdata/deNieuweKaartvanNederland.xml", "rb").read())])
test_urllib(URL, "/genericvalidator/xmlService/validateFileService", [("id", 140)], [("file", "deNieuweKaartvanNederland.xml" ,open("C:/projects/ggm/testdata/deNieuweKaartvanNederland.xml", "rb").read())])



"""

