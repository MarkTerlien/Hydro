from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *

"""
class TableListWidget(QListWidget):
    def __init__(self, OracleConnection):
	QListWidget.__init__(self)
	self.OracleConnection = OracleConnection
	self.add_items()

    def add_items(self):
	for table in self.OracleConnection.get_spatial_tables() :
		self.addItem(QListWidgetItem(str(table)))

# create the dialog for the qwidget builder
class GgmDialog(QtGui.QDialog):
    def __init__(self, OracleConnection):
        QtGui.QDialog.__init__(self)
	self.OracleConnection = OracleConnection
	self.TableList = TableListWidget ( self.OracleConnection )
	layout = QVBoxLayout()
	layout.addWidget(self.TableList)
	self.setLayout(layout)	

"""	

class TableListWidget(QListWidget):
    def __init__(self, OracleConnectionFunction ):
	QListWidget.__init__(self)
	self.OracleConnectionFunction = OracleConnectionFunction
	self.add_items()

    def add_items(self):
	for item in self.OracleConnectionFunction :
		self.addItem(QListWidgetItem(str(item)))

# create the dialog for the qwidget builder
class dropdownList(QtGui.QDialog ):
    def __init__(self, OracleConnectionFunction ):
        QtGui.QDialog.__init__(self)
	self.OracleConnectionFunction = OracleConnectionFunction
	self.TableList = TableListWidget ( self.OracleConnectionFunction )
	layout = QVBoxLayout()
	layout.addWidget(self.TableList)
	self.setLayout(layout)	      