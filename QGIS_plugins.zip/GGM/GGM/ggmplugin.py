"""
/***************************************************************************
    PluginBuilder
                                 A QGIS plugin
    Creates a skeleton QGIS plugin for use as a starting point
                             -------------------
        begin                : 2011-01-20
        copyright            : (C) 2011 by GeoApt LLC
        email                : gsherman@geoapt.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
"""

# Import PyQt  libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *

# Import qgis libraries
from qgis.core import *
from qgis.gui import *
from qgis.utils import *

# Import other third-party libraries
import xml.dom.minidom
import win32api

# Import provider libraries
from oracle_provider import OracleProvider, GgmOracleProvider
from twitter_provider import TwitterProvider
from iso19115_provider import iso19115provider
from ggm_dialog import *

# Database connection parameter values
DB_USER_SOURCE       = "Databse user"
DB_PASSWORD_SOURCE   = "Password"
DB_TNS_SOURCE        = "Connect string"
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "alt.ldmid.transfer-solutions.com/ggm"

# HTTP parameters 
URL_ISO19115_VAL  = "Url iso19115 validator"
URL_PROXY         = "Url proxy"
USE_PROXY         = "Use proxy"
HTTP_PARAMETERS   = {}
HTTP_PARAMETERS[ URL_ISO19115_VAL ] = 'http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService'
HTTP_PARAMETERS[ URL_PROXY ]        = 'http://172.29.10.10:3128'
HTTP_PARAMETERS[ USE_PROXY ]        = True

# Map qgis geometry type id's 
QGIS_GEOMETRY_TYPES = {}
QGIS_GEOMETRY_TYPES[ 0 ] = 'Point'
QGIS_GEOMETRY_TYPES[ 1 ] = 'LineString'
QGIS_GEOMETRY_TYPES[ 2 ] = 'Polygon'
QGIS_GEOMETRY_TYPES[ 3 ] = 'UnknownGeometry'

METADATAFILE = 'c:/projects/ggm/testdata/ipo.xml'

class GgmPlugin:

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface
	
	# Open DB connection
	self.OracleConnection = GgmOracleProvider ( PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE], PARAMETER_LIST_VALUE [DB_TNS_SOURCE] )
	
	# Get pointer to map canvas	
	self.canvas = self.iface.mapCanvas()	

    def initGui(self):
        # Create action that will start plugin configuration (self, QIcon icon, QString text, QObject parent)
	self.actionOpenGgm = QAction(QIcon("C:/OSGeo4W/apps/qgis/python/plugins/GGM/database.png"), "Toon lagen", self.iface.mainWindow())
	self.actionExportMd = QAction(QIcon("C:/OSGeo4W/apps/qgis/python/plugins/GGM/database.png"), "Export metadata", self.iface.mainWindow())
	self.actionImportMd = QAction(QIcon("C:/OSGeo4W/apps/qgis/python/plugins/GGM/database.png"), "Import metadata", self.iface.mainWindow())
        self.actionAbout = QAction(QIcon("C:/OSGeo4W/apps/qgis/python/plugins/GGM/help.png"), "About", self.iface.mainWindow())	
	self.actionAbout.setWhatsThis("Geo Gegevens Magazijn Plugin About")
        
        # connect the action to the run method
        QObject.connect(self.actionOpenGgm, SIGNAL("triggered()"), self.runOpenGgm)
	QObject.connect(self.actionExportMd, SIGNAL("triggered()"), self.runExportMd)
	QObject.connect(self.actionImportMd, SIGNAL("triggered()"), self.runImportMd)	
	QObject.connect(self.actionAbout, SIGNAL("activated()"), self.about)	

        # Add toolbar button and menu item
        self.iface.addToolBarIcon(self.actionOpenGgm)
        self.iface.addPluginToMenu("&Geo Gegevens Magazijn...", self.actionOpenGgm)
	self.iface.addPluginToMenu("&Geo Gegevens Magazijn...", self.actionExportMd)
	self.iface.addPluginToMenu("&Geo Gegevens Magazijn...", self.actionImportMd)	
	self.iface.addPluginToMenu("&Geo Gegevens Magazijn...", self.actionAbout)

    def unload(self):
        # Remove the plugin menu item and icon
        self.iface.removePluginMenu("&&Geo Gegevens Magazijn...",self.actionOpenGgm)
        self.iface.removePluginMenu("&&Geo Gegevens Magazijn...",self.actionExportMd)	
        self.iface.removePluginMenu("&&Geo Gegevens Magazijn...",self.actionImportMd)		
        self.iface.removeToolBarIcon(self.actionOpenGgm)
	
    def runOpenGgm(self) :
	
	QgsMessageLog.logMessage('Get features from GGM database', 'GGM')

	# Build dialog
	self.dlg_lagen_lijst = dropdownList ( self.OracleConnection.get_spatial_tables() ) 
	self.dlg_lagen_lijst.TableList.itemClicked.connect(self.plot_features_from_db)

	# show the dialog
	self.dlg_lagen_lijst.show()
	result = self.dlg_lagen_lijst.exec_()

	"""
	
	#######################################################################

	self.TwitterConnection = TwitterProvider('C:/temp/tweets.json')
	self.TwitterConnection = TwitterProvider('C:/temp/snow.json')
	features_dict = self.TwitterConnection.get_features ()
	self.plot_features ( "Twitter", features_dict, 4326, "Point" )	
	
	#######################################################################
	
	"""

    def runExportMd(self) :
	
	QgsMessageLog.logMessage('Get metadata from GGM database', 'GGM')
	
	# Build dialog
	self.dlg_lagen_lijst = dropdownList ( self.OracleConnection.get_metadata_items() ) 
	self.dlg_lagen_lijst.TableList.itemClicked.connect(self.export_metadata)

	# show the dialog
	self.dlg_lagen_lijst.show()
	result = self.dlg_lagen_lijst.exec_()

    def runImportMd(self) :
	
	# Build dialog
	#self.dlg_lagen_lijst = dropdownList ( self.OracleConnection.get_metadata_items() ) 
	#self.dlg_lagen_lijst.TableList.itemClicked.connect(self.export_metadata)

	# show the dialog
	#self.dlg_lagen_lijst.show()
	#result = self.dlg_lagen_lijst.exec_()	
	
	file_name = METADATAFILE
	self.import_metadata( file_name )


    def about(self):
        infoString = QString("Geschreven door Mark Terlien\nEmail - mark.terlien@transfer-solutions.com\n")
        infoString = infoString.append("Company - http://transfer-solutions.com\n")
        QMessageBox.information(self.iface.mainWindow(), "Geo Gegevens Magazijn Plugin About", infoString)


    def plot_features_from_db ( self, table_name ) :
	try :
	    
	    spatial_table = str(table_name.text())
	    
	    QgsMessageLog.logMessage('Plot features from table ' + spatial_table, 'GGM')
	    
	    # Write features from db to dictionary	
	    nr_of_rows = 2000
	    features_dict = self.OracleConnection.get_features ( spatial_table, nr_of_rows ) 
	    
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'GGM')
		geometry_type  = QGIS_GEOMETRY_TYPES[self.OracleConnection.get_geometry_type( spatial_table )] 
		srid = int(self.OracleConnection.get_srid( spatial_table ))
		QgsMessageLog.logMessage('Geometry type is ' + geometry_type , 'GGM')
		if geometry_type :
		    self.plot_features ( spatial_table, features_dict, srid, geometry_type )	
	
	except Exception, err:
	    raise	    		
	
    
    def plot_features ( self, layer_name, features_dict, features_crs, geometry_type ) :
	try :
	    
	    QgsMessageLog.logMessage('Plot ' + str(geometry_type) + ' layer ' + str(layer_name), 'GGM')
	    
	    # Create layer definition
	    layer = QgsVectorLayer(geometry_type, layer_name, "memory")
	    layer.startEditing()
	    crs = QgsCoordinateReferenceSystem(features_crs, QgsCoordinateReferenceSystem.PostgisCrsId)
	    layer.setCrs(crs)
	    provider = layer.dataProvider()
	    
	    # Add attributes; When first feature create first the feature definition (first add geometry then other attributes)
	    nr_features = 0
	    for feature_id, feature_dict in features_dict.iteritems() :

		# Create the feature definition
		if nr_features == 0 :
		    provider.addAttributes( { "ID" : "string" } )
		    for attribute_name, attribute_value in feature_dict.iteritems() :
			if str.upper(str(attribute_name)) <> self.OracleConnection.geom:
			    provider.addAttributes( { str.upper(attribute_name) : "string" } )
		    
		# Initiate feature
		i = 0
		feature = QgsFeature()		
		
		# Add the geometry
		feature.setGeometry( feature_dict[self.OracleConnection.geom] )
		
		# Add unique id
		feature.addAttribute( i, QVariant( feature_id ) )
		
		# Add other attributes
		for attribute_name, attribute_value in feature_dict.iteritems() :
		    if str.upper(attribute_name) <> self.OracleConnection.geom :
			i = i + 1
			feature.addAttribute( i, QVariant( str(attribute_value) ) )
		
		# Add attribute to provider
		nr_features = nr_features + 1
		provider.addFeatures([feature])
		
	    # Update extents of provider
	    layer.commitChanges()
	    layer.updateExtents()	
    
	    # Add layer to map registry
	    QgsMapLayerRegistry.instance().addMapLayer(layer)
	    
	    # Set extent to the extent of our layer
	    self.canvas.setExtent(layer.extent())
	    
	    # Set up the map canvas layer set
	    self.canvas.setLayerSet( [ QgsMapCanvasLayer(layer) ] )	
	    self.canvas.show()
	    
	    layer.dataProvider().capabilities()
	    
	    QgsMessageLog.logMessage(str(nr_features) + ' features plotted', 'GGM')
	    QgsMessageLog.logMessage(str(layer.dataProvider().capabilities()) + ' capabilities', 'GGM')
	    
	except Exception, err:
	    raise	    
	
    def plot_features_2 ( self, layer_name, features_crs, geometry_type ) :
	try :
	    
	    QgsMessageLog.logMessage('Plot layer ' + str(layer_name), 'GGM')
	    
	    # Create layer definition
	    layer = QgsVectorLayer(geometry_type, layer_name, "memory")
	    layer.startEditing()
	    crs = QgsCoordinateReferenceSystem(features_crs, QgsCoordinateReferenceSystem.PostgisCrsId)
	    layer.setCrs(crs)
	    provider = layer.dataProvider()
	    
	    # Add attributes; When first feature create first the feature definition (first add geometry then other attributes)
	    provider, nr_features = self.OracleConnection.plot_features ( layer_name, provider) 
		
	    # Update extents of provider
	    layer.commitChanges()
	    layer.updateExtents()	
    
	    # Add layer to map registry
	    QgsMapLayerRegistry.instance().addMapLayer(layer)
	    
	    # Set extent to the extent of our layer
	    self.canvas.setExtent(layer.extent())
	    
	    # Set up the map canvas layer set
	    self.canvas.setLayerSet( [ QgsMapCanvasLayer(layer) ] )	
	    self.canvas.show()
	    
	    QgsMessageLog.logMessage(str(nr_features) + ' features plotted', 'GGM')
	    
	except Exception, err:
	    raise	    	

    def import_metadata ( self, file_name ) :
	try:
	    QgsMessageLog.logMessage('Import metadata from GGM ', 'GGM')
	    # Create metadataprovider
	    MetadataImporter = iso19115provider( self.OracleConnection, HTTP_PARAMETERS[ URL_ISO19115_VAL ], HTTP_PARAMETERS[ URL_PROXY ] , HTTP_PARAMETERS[ USE_PROXY ] )  
	    # Validate generated metadata file
	    MetadataImporter.validate_file ( 140, file_name ) 
	    MetadataImporter.write_validation_file ( file_name[:-4] + '_validatie_resulten.txt' )
	    QMessageBox.information(self.iface.mainWindow(), "Metadata validatie resultaten", str(MetadataImporter.show_metadata_validation_results()) )
	    MetadataImporter.import_metadata_file_into_db ( file_name )
	    QMessageBox.information(self.iface.mainWindow(), "Metadata import", "Metadata file " + str(file_name) + " geimporteerd" )
	except Exception, err:
	    raise
	
    def export_metadata ( self, guid ) :
	try:
	    guid = str(guid.text()).split(':')[1]
	    QgsMessageLog.logMessage('Export metadata from GGM for ' + str(guid), 'GGM')
	    # Create metadataprovider
	    MetadataExporter = iso19115provider( self.OracleConnection, HTTP_PARAMETERS[ URL_ISO19115_VAL ], HTTP_PARAMETERS[ URL_PROXY ] , HTTP_PARAMETERS[ USE_PROXY ] )  
	    # Get metadata from db and write to file
	    file_name = 'c:/temp/' + str(guid) + '.xml'
	    MetadataExporter.export_metadata_file_from_db( guid.lstrip(), file_name )
	    # Validate generated metadata file
	    MetadataExporter.validate_file ( 140, file_name ) 
	    MetadataExporter.write_validation_file ( file_name[:-4] + '_validatie_resulten.txt' )
	    QMessageBox.information(self.iface.mainWindow(), "Metadata validatie resultaten", 'Metadata file ' + str(file_name) + '\n' + '\n' + str(MetadataExporter.show_metadata_validation_results())  )
	except Exception, err:
	    raise	
	
		