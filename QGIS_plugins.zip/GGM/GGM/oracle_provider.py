# Oracle database connection
import cx_Oracle
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from PyQt4.QtCore import *
import win32api

# Oracle data types
NUMBER       = "NUMBER"
VARCHAR2     = "VARCHAR2"
DATE         = "DATE"

# Ogr data types
INTEGER   = "integer"
DOUBLE    = "real"
STRING    = "string"
DATETIME  = "string"

READARRAYSIZE        = 10000

class OracleProvider:
    """Connection class to Oracle database"""

    def __init__( self, DbUser, DbPass, DbConnect ):
        try :
            self.oracle_connection = cx_Oracle.connect(DbUser, DbPass, DbConnect)
            self.oracle_cursor = self.oracle_connection.cursor()
            self.oracle_cursor.arraysize = READARRAYSIZE
	    self.geom = "GEOM"
        except Exception, err:
            raise

    def get_spatial_tables ( self ) :
	try:
	    table_list = []
	    stmt = "select table_name from user_sdo_geom_metadata" 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		table = str(row[0])
		stmt = 'select count(1) from ' + table
		try:
		    self.oracle_cursor.execute( stmt )
		    result = self.oracle_cursor.fetchall()		
		    for count in result :
			nr_rows = int(count[0])	
			if nr_rows > 0 :
			    table_list.append(table)
		except :
		    None			    
	    return table_list
	except Exception, err:
	    raise

    def get_srid ( self, table_name ) :
	try :
	    stmt = "select srid from user_sdo_geom_metadata where table_name = :TABLE_NAME " 
	    self.oracle_cursor.execute(stmt, TABLE_NAME = table_name )
	    resultset = self.oracle_cursor.fetchmany()
	    if resultset :
		for row in resultset :
		    srid = str(row[0])
	    return srid	    
	except Exception, err:
	    raise	
	    
	

    def get_spatial_column ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_sdo_geom_metadata where table_name = :TABLE_NAME " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table )
            resultset = self.oracle_cursor.fetchmany()
            if resultset :
                for row in resultset :
                    spatial_column = str(row[0])
            return spatial_column
        except Exception, err:
	    raise 

    def get_attributes ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_tab_columns t where t.table_name = :TABLE_NAME and data_type in ( \'NUMBER\',\'VARCHAR2\',\'DATE\') " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table )
            resultset = self.oracle_cursor.fetchmany()
            attribute_list = []
            if resultset :
                for row in resultset :
                    attribute_list.append(str(row[0]))
            return attribute_list
        except Exception, err:
            raise         
	
    def get_no_pk_attributes ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_tab_columns t where t.table_name = :TABLE_NAME and data_type in ( \'NUMBER\',\'VARCHAR2\',\'DATE\') and t.column_name <> :PK_COLUMN " 
	    pk_column = self.get_primary_key ( spatial_table ) 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table, PK_COLUMN = pk_column )
            resultset = self.oracle_cursor.fetchmany()
            attribute_list = []
            if resultset :
                for row in resultset :
                    attribute_list.append(str(row[0]))
            return attribute_list
        except Exception, err:
            raise    	

    def get_data_type ( self, table, attribute ) :
            stmt = "select data_type, data_scale from user_tab_columns t where t.table_name = :TABLE_NAME and t.column_name = :COLUMN_NAME " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = table, COLUMN_NAME = attribute )
            resultset = self.oracle_cursor.fetchmany()
            if resultset :
                for row in resultset :
                    data_type  = str(row[0])
                    if row[1] <> None :
                        data_scale = int(row[1])
                    else :
                        data_scale = 0
            if data_type == VARCHAR2 :
                ogr_data_type = STRING
            if data_type == NUMBER and data_scale == 0 :
                ogr_data_type = INTEGER
            if data_type == NUMBER and data_scale > 0 :
                ogr_data_type = DOUBLE                
            if data_type == DATE :
                ogr_data_type = DATETIME                
            return ogr_data_type
	
    def get_geometries_for_table_2D( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(' +  str( self.get_spatial_column ( table_name ) ) + ') '
	    for attribute in self.get_attributes ( table_name ) :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    return resultset
	except Exception, err:
	    raise
	
    def get_geometry_type_2D( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(' +  str( self.get_spatial_column ( table_name ) ) + ') '
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum = 1 ' 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    if resultset :
		for row in resultset :
		    geom = QgsGeometry.fromWkt( str(row[0]) )
		    geometry_type = int(geom.type())
	    else :
		geometry_type = None
	    return geometry_type
	except Exception, err:
	    raise	
	
    def get_nr_of_rows( self, table_name ) :
	try :
	    stmt = 'select count(1) '
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		nr_of_rows = int(row[0])
	    return nr_of_rows
	except Exception, err:
	    raise

    def get_primary_key ( self, table_name ) :
	try :
	    stmt = 'select c2.column_name from user_constraints c1, user_cons_columns c2 where c1.constraint_name = c2.constraint_name and c1.constraint_type = \'P\' and c2.table_name = :TABLE_NAME '
	    self.oracle_cursor.execute(stmt, TABLE_NAME = table_name )
	    resultset = self.oracle_cursor.fetchmany()
	    if resultset :
		for row in resultset :
		    primary_key = str(row[0])
	    else :
		primary_key = '\'no_pk\''
	    return primary_key
	except Exception, err:
	    raise

    def get_features_2D ( self, table_name, nr_of_rows ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(' +  str( self.get_spatial_column ( table_name ) ) + ') '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum <= ' + str(nr_of_rows)  	    
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    QgsMessageLog.logMessage('Query executed', 'GGM')
	    features_dict = {}
	    for row in resultset :
		attributes_dict = {}
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			pk_id = str.upper(str(row[0]))
		    elif attribute_index == 1:
			attributes_dict[self.geom] = QgsGeometry.fromWkt( str(row[1]) )
		    else :
			attributes_dict[attribute_list[attribute_index-2]] = str(row[attribute_index])
		features_dict[pk_id] = attributes_dict
	    QgsMessageLog.logMessage('Features in dict', 'GGM')
	    return features_dict
	except Exception, err:
	    raise
	
    def plot_features_2D ( self, table_name, provider ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(' +  str( self.get_spatial_column ( table_name ) ) + ') '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 	    
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    nr_features = 0
	    for row in resultset :
		feature = QgsFeature()
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			if nr_features == 0 : 
			    provider.addAttributes( { "ID" : "string" } )
			feature.addAttribute( attribute_index, QVariant( str.upper(str(row[0])) ) )
		    elif attribute_index == 1:
			feature.setGeometry( QgsGeometry.fromWkt( str(row[1]) ))
		    else :
			if nr_features == 0 :
			    provider.addAttributes( { str.upper(attribute_list[attribute_index-2]) : "string" } )	
			feature.addAttribute( attribute_index, QVariant( str(row[attribute_index]) ) )
		nr_features = nr_features + 1
		provider.addFeatures([feature])
	    return provider, nr_features
	except Exception, err:
	    raise	

    def get_geometries( self ) :
	try :
	    stmt = 'select naam, sdo_util.to_wktgeometry(geometrie) from ggm_wijken'
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    return resultset
	except Exception, err:
	    raise

    def commit( self ) :
        """Function to commit connection"""
        self.oracle_connection.commit()

    def rollback( self ) :
        """Function to rollback connection"""
        self.oracle_connection.rollback()
	
    def rollback_close( self ) :
        """Function to rollback and close connection"""
        self.oracle_connection.rollback()
        self.oracle_connection.close()

    def commit_close( self ) :
        """Function to commit and close connection"""
        self.oracle_connection.commit()
        self.oracle_connection.close()	

    ########################################################
    #
    # Dit is GGM specifiek
    #
    ########################################################


class GgmOracleProvider ( OracleProvider ):
    """Connection class to Oracle database"""

    def __init__( self, DbUser, DbPass, DbConnect ):
        try :
            OracleProvider.__init__( self, DbUser, DbPass, DbConnect )
        except Exception, err:
            raise

    def get_metadata_items ( self ) :
	try:
	    item_list = []
	    stmt = "select naam, guid from gbm_metadata" 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		item_list.append(str(row[0]) + ": " + str(row[1]))
	    return item_list
	except Exception, err:
	    raise	
	
    def generate_iso19139 ( self, guid ) :
	try :
	    iso19139_xml = self.oracle_cursor.callfunc("exp_mdt.run_export", cx_Oracle.CLOB, [ guid ] )
	    return iso19139_xml 
	except Exception, err:
	    raise	    

    def import_iso19139 ( self, file_name ) :
	try :
	    file_clob = self.oracle_cursor.var(cx_Oracle.CLOB)
	    file_clob.setvalue(0, str( open(file_name).read() ) )
	    self.oracle_cursor.callproc("gbm_import_iso19139",[ file_clob ])		
	except Exception, err:
	    raise
	
    def get_geometries_for_table( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    for attribute in self.get_attributes ( table_name ) :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    return resultset
	except Exception, err:
	    raise
	
    def get_geometry_type( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum = 1 ' 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    if resultset :
		for row in resultset :
		    geom = QgsGeometry.fromWkt( str(row[0]) )
		    geometry_type = int(geom.type())
	    else :
		geometry_type = None
	    return geometry_type
	except Exception, err:
	    raise	
	
    def get_features ( self, table_name, nr_of_rows ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum <= ' + str(nr_of_rows)  	    
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    QgsMessageLog.logMessage('Query executed', 'GGM')
	    features_dict = {}
	    for row in resultset :
		attributes_dict = {}
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			pk_id = str.upper(str(row[0]))
		    elif attribute_index == 1:
			attributes_dict[self.geom] = QgsGeometry.fromWkt( str(row[1]) )
		    else :
			attributes_dict[attribute_list[attribute_index-2]] = str(row[attribute_index])
		features_dict[pk_id] = attributes_dict
	    QgsMessageLog.logMessage('Features in dict', 'GGM')
	    return features_dict
	except Exception, err:
	    raise
	
    def plot_features ( self, table_name, provider ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 	    
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    nr_features = 0
	    for row in resultset :
		feature = QgsFeature()
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			if nr_features == 0 : 
			    provider.addAttributes( { "ID" : "string" } )
			feature.addAttribute( attribute_index, QVariant( str.upper(str(row[0])) ) )
		    elif attribute_index == 1:
			feature.setGeometry( QgsGeometry.fromWkt( str(row[1]) ))
		    else :
			if nr_features == 0 :
			    provider.addAttributes( { str.upper(attribute_list[attribute_index-2]) : "string" } )	
			feature.addAttribute( attribute_index, QVariant( str(row[attribute_index]) ) )
		nr_features = nr_features + 1
		provider.addFeatures([feature])
	    return provider, nr_features
	except Exception, err:
	    raise	
    
    def store_taak ( self, file_name ) :
	try :
	    file_name_without_path = os.path.basename(file_name)
	    binary_data = open(file_name, 'rb').read()
	    blobfile = self.oracle_cursor.var(cx_Oracle.BLOB)
	    blobfile.setvalue(0, binary_data)	  
	    blob_length = int(self.oracle_cursor.callfunc('dbms_lob.getlength', cx_Oracle.NUMBER, [blobfile]))
	    stmt = 'select imp_bsd_seq.nextval from dual'
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		id = int(row[0])
	    stmt = 'insert into imp_bestanden ( id, bestand, mimetype, filename, last_update, charset, upload_by, blob_length, guid, status, imp_id, imp_type ) ' 
	    stmt = stmt + ' values ( :id, :bestand, :mimetype, :filename, sysdate, null, :upload_by, :blob_length, :guid, :status, null, :imp_type )'
	    query_parameters = { 'id' : id, 'bestand' : blobfile, 'mimetype' : 'text/xml', 'filename' : file_name_without_path, 'upload_by' : 'MTJ', 'blob_length' : blob_length, 'guid' : 'xyz', 'status' : 'NIEUW', 'imp_type' : 'MDT'  } 
	    self.oracle_cursor.execute( stmt, query_parameters )	
	    QgsMessageLog.logMessage('Metadata taak ' + str(id) + ' opgeslagen', 'GGM')
	    return id
	except Exception, err:
	    raise	     
     
    def start_import_iso19139 ( self, task_id ) :
	try :
	    self.oracle_cursor.callproc("imp_mdt.do_import",[ task_id ])		
	except Exception, err:
	    raise     