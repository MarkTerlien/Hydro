#!/usr/bin/env python

###################################################
#                                                 #
# Class to validate ISO19115 with Geonovum       # 
#                                                 #
# Author: MTJ                                     #
# Date:   1-8-2012                                #
#                                                 #
###################################################

# Import core libraries
import mimetypes
import urllib2
import os
import xml.dom.minidom

class iso19115provider :
    
    def __init__( self, oracle_connection, url, proxy, use_proxy ):
        try :
	    self.OracleConnection = oracle_connection
            if url == None :            
                self.url = 'http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService'
            else :
                self.url = url
            if use_proxy :
                if proxy == None :
                    self.proxy = {'http': 'http://172.29.10.10:3128'}
                else :
                    self.proxy = {'http': proxy }
                proxy_support = urllib2.ProxyHandler(self.proxy)
                opener = urllib2.build_opener(proxy_support)
                urllib2.install_opener(opener)
        except Exception, err:
            raise    

    def import_metadata_file_into_db ( self, iso19139_file ) :
	try :	
	    task_id = self.OracleConnection.store_taak ( iso19139_file ) 
	    self.OracleConnection.commit()
	    self.OracleConnection.start_import_iso19139 (task_id ) 
	    #self.OracleConnection.commit()
	except Exception, err:
	    self.OracleConnection.rollback()
	    raise

    def export_metadata_file_from_db ( self, guid, iso19139_file ) :
	try :
	    self.iso19139_xml_as_string = str(self.OracleConnection.generate_iso19139 ( guid ))
	    fOut = open (iso19139_file,'w')
	    fOut.write(self.iso19139_xml_as_string + '\n')
	    fOut.close()	    
	except Exception, err:
	    raise    	    
	
    def validate_file ( self, validation_type_id, iso19139_file ) :
        try :
            fields = [("id", validation_type_id)]   
            files = [("file", os.path.basename(iso19139_file) ,open(iso19139_file, "rb").read())]
            content_type, body = self.encode_multipart_formdata(fields, files)    
            request = urllib2.Request(self.url)
            request.add_header('Content-type', content_type)
            request.add_header('Content-length', len(body))
            request.add_data(body)     
            self.validation_xml_as_string = str(urllib2.urlopen(request).read())
        except Exception, err:
            raise              

    def encode_multipart_formdata( self, fields, files):
        LIMIT = '----------lImIt_of_THE_fIle_eW_$'
        CRLF = '\r\n'
        L = []
        for (key, value) in fields:
            L.append('--' + LIMIT)
            L.append('Content-Disposition: form-data; name="%s"' % key)
            L.append('')
            L.append(str(value))
        for (key, filename, value) in files:
            L.append('--' + LIMIT)
            L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
            L.append('Content-Type: %s' % self.get_content_type(filename))
            L.append('')
            L.append(str(value))
        L.append('--' + LIMIT + '--')
        L.append('')
        body = CRLF.join(L)
        content_type = 'multipart/form-data; boundary=%s' % LIMIT
        return content_type, body
    
    def get_content_type( self, filename):
        return mimetypes.guess_type(filename)[0] or 'application/octet-stream'

    def write_validation_file ( self, file_name ) :
	try :
	    validation_file = file_name 
	    fOut = open (validation_file,'w')
	    fOut.write(self.show_metadata_validation_results())	
	    fOut.write('############################################')	    
	    fOut.write(self.validation_xml_as_string + '\n')
	    fOut.close()	
	except Exception, err:
	    raise	
	
    def show_metadata_validation_results ( self ) :
	try:
	    output = ''
	    validation_results_dom = xml.dom.minidom.parseString(str(self.validation_xml_as_string))    
	    for validation_message in validation_results_dom.getElementsByTagName('ValidatorMessage') :
		message_type = str(validation_message.getElementsByTagName('type')[0].childNodes[0].nodeValue)
		message_text = str(validation_message.getElementsByTagName('message')[0].childNodes[0].nodeValue)
		output = output + str(message_type + ': ' + message_text +'\n')
	    return output		
	except Exception, err:
	    raise		


            
"""

#response = minidom.parse(urllib.urlopen(url, proxies = {'http': PROXY}))
PROXY = 'http://172.29.10.10:3128'
URL = 'validatie-dataspecificaties.geostandaarden.nl'
import httplib



def post_multipart(host, selector, fields, files):
    
    content_type, body = encode_multipart_formdata(fields, files)
    
    print content_type
    print body
    
    #if urllib2.getproxies().get('http') :    
    #h = httplib.HTTPConnection("172.29.10.10", 3128)
    #h.putrequest('POST', 'http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService')
    #else :
    h = httplib.HTTP(host)
    h.putrequest('POST', selector)
    
    h.putheader('content-type', content_type)
    h.putheader('content-length', str(len(body)))
    h.endheaders()
    h.send(body)
    errcode, errmsg, headers = h.getreply()
    return h.file.read()


def test_urllib ( host, selector, fields, files ) :
    
    

    content_type, body = encode_multipart_formdata(fields, files)    
    request = urllib2.Request('http://validatie-dataspecificaties.geostandaarden.nl/genericvalidator/xmlService/validateFileService')
    request.add_header('Content-type', content_type)
    request.add_header('Content-length', len(body))
    request.add_data(body) 

    print
    print 'OUTGOING DATA:'
    print request.get_data()

    print
    print 'SERVER RESPONSE:'
    print urllib2.urlopen(request).read()   

def encode_multipart_formdata(fields, files):
    LIMIT = '----------lImIt_of_THE_fIle_eW_$'
    CRLF = '\r\n'
    L = []
    for (key, value) in fields:
        L.append('--' + LIMIT)
        L.append('Content-Disposition: form-data; name="%s"' % key)
        L.append('')
        L.append(str(value))
    for (key, filename, value) in files:
        L.append('--' + LIMIT)
        L.append('Content-Disposition: form-data; name="%s"; filename="%s"' % (key, filename))
        L.append('Content-Type: %s' % get_content_type(filename))
        L.append('')
        L.append(str(value))
    L.append('--' + LIMIT + '--')
    L.append('')
    body = CRLF.join(L)
    content_type = 'multipart/form-data; boundary=%s' % LIMIT
    return content_type, body

def get_content_type(filename):
    return mimetypes.guess_type(filename)[0] or 'application/octet-stream'

    
    


#########################################################


proxy_support = urllib2.ProxyHandler({'http': 'http://172.29.10.10:3128'})
opener = urllib2.build_opener(proxy_support)
urllib2.install_opener(opener)


#print http_proxy
#result = post_multipart(URL, "/genericvalidator/xmlService/validateFileService", [("id", 140)], [("file", "deNieuweKaartvanNederland.xml" ,open("C:/projects/ggm/testdata/deNieuweKaartvanNederland.xml", "rb").read())])
test_urllib(URL, "/genericvalidator/xmlService/validateFileService", [("id", 140)], [("file", "deNieuweKaartvanNederland.xml" ,open("C:/projects/ggm/testdata/deNieuweKaartvanNederland.xml", "rb").read())])



"""

