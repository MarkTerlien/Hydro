# Oracle database connection
import simplejson
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
import win32api
import os

GEOM = "GEOM"
TEXT = "TEXT"

# Get twitter file:
# curl -k -d @locations.txt https://stream.twitter.com/1/statuses/filter.json -x proxy.transfer-solutions.com:3128  -u markterlien:gianni1990 > tweets.json
# curl -k -d @track.txt https://stream.twitter.com/1/statuses/filter.json -u markterlien:gianni1990 > snow.json

class TwitterProvider:
    """Connection class to twitter file"""

    def __init__( self, file_name ):
        try :
            self.file_name = file_name
        except Exception, err:
            raise

    def get_features ( self ) :
        try:
	    fIn = open( self.file_name,'r')
	    features_dict = {}
	    nr_features = 0
	    for line in fIn:
		if line[0] == '{' :
		    try :
			nr_features = nr_features + 1
			attributes_dict = {}
			j = simplejson.loads(line)
			attributes_dict[GEOM] = QgsGeometry.fromPoint(QgsPoint(j['geo']['coordinates'][1],j['geo']['coordinates'][0]))
			attributes_dict[TEXT] = str(j['text']) 
			features_dict[str.upper(str(nr_features))] = attributes_dict
		    except :
			None 
	    fIn.close()
	    return features_dict			
        except Exception, err:
	    raise 


import pycurl, json
import simplejson

"""
GEOM = "GEOM"
TEXT = "TEXT"

#STREAM_URL = "https://stream.twitter.com/1/statuses/filter.json?locations=4.9,51.8,5.3,52"
STREAM_URL = "https://stream.twitter.com/1/statuses/filter.json?track=snow"

USER = "markterlien"
PASS = "gianni1990"

# Use encode to convert unicode string to byte string

def on_receive(tweet):
	try :
		if tweet :
			j = simplejson.loads(str(tweet))
			attributes_dict = {}
			#attributes_dict[GEOM] = QgsGeometry.fromPoint(QgsPoint(j['geo']['coordinates'][1],j['geo']['coordinates'][0]))
			attributes_dict[TEXT] = (j['text']) 
			print attributes_dict[TEXT]
	except Exception, err:
		print tweet

conn = pycurl.Curl()
conn.setopt(pycurl.VERBOSE ,1)
conn.setopt(pycurl.USERPWD, "%s:%s" % (USER, PASS))
conn.setopt(pycurl.URL, STREAM_URL)
# Skip certificate verification
conn.setopt(pycurl.SSL_VERIFYPEER, 0)   
conn.setopt(pycurl.SSL_VERIFYHOST, 0)
#curl.setopt(pycurl.SSL_VERIFYPEER, 1)
#curl.setopt(pycurl.SSL_VERIFYHOST, 2)
#curl.setopt(pycurl.CAINFO, "/path/to/updated-certificate-chain.crt")
conn.setopt(pycurl.WRITEFUNCTION, on_receive)
conn.perform()
"""