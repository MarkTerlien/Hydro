from easygui import multpasswordbox

# Database connection parameter values
DB_USER_SOURCE       = "Databse user"
DB_PASSWORD_SOURCE   = "Password"
DB_TNS_SOURCE        = "Connect string"
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "alt.ldmid.transfer-solutions.com/ggm"

def db_connect_parameters() : 
    # Db connection
    title = 'Database connection parameters'
    msg   = "Enter database connection parameters "
    return multpasswordbox( msg, title, [ DB_TNS_SOURCE, DB_USER_SOURCE , DB_PASSWORD_SOURCE ], [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ])

    
        