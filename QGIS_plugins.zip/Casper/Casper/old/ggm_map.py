from oracle_connection import OracleConnection
from qgis.gui import *
from qgis.core import *
from PyQt4.QtGui import QAction, QMainWindow
from PyQt4.QtCore import SIGNAL, Qt, QString, QVariant


# Database connection parameter values
DB_USER_SOURCE       = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE   = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE        = "DB_TNS_SOURCE"
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "ggm_owner"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "alt.ldmid.transfer-solutions.com/ggm"


class GgmMap(QMainWindow):
    def __init__(self, layer):
        QMainWindow.__init__(self)
		
	# Build Oracle connection
        self.OracleConnection = OracleConnection ( PARAMETER_LIST_VALUE[ DB_USER_SOURCE ], PARAMETER_LIST_VALUE[ DB_PASSWORD_SOURCE ], PARAMETER_LIST_VALUE[ DB_TNS_SOURCE ] )		

	# Create layer definition
        oracle_layer = QgsVectorLayer("Polygon", "temporary_polygons", "memory")
        oracle_provider = oracle_layer.dataProvider()

        # Add fields
        oracle_provider.addAttributes( [ QgsField("name", QVariant.String) ] )
		
	# Loop over geometries
	for geometry in self.OracleConnection.get_geometries() :
	    name_geom = str(geometry[0])
	    wkt_geom = str(geometry[1])
	    feature = QgsFeature()
	    feature.setGeometry( QgsGeometry.fromWkt( wkt_geom ) )
	    feature.setAttributeMap( { 0 : QVariant( name_geom ) } )
	    oracle_provider.addFeatures( [ feature ] )

	# Update extents of provider
	oracle_provider.updateExtents()

	# Add symbology to line
	props = { 'width' : '1', 'color' : '0,0,255' }
	sl = QgsSymbolLayerV2Registry.instance().symbolLayerMetadata("SimpleLine").createSymbolLayer(props)
	s = QgsLineSymbolV2([sl])	
	oracle_layer.setRendererV2( QgsSingleSymbolRendererV2( s ) )
      
        self.canvas = QgsMapCanvas()
        self.canvas.setCanvasColor(Qt.white)
        #self.canvas.setExtent(layer.extent())
        #self.canvas.setLayerSet( [ QgsMapCanvasLayer(layer) ] )
	self.canvas.setExtent(oracle_layer.extent())
	self.canvas.setLayerSet( [ QgsMapCanvasLayer(oracle_layer) ] )
        self.setCentralWidget(self.canvas)
        
        actionZoomIn = QAction(QString("Zoom in"), self)
        actionZoomOut = QAction(QString("Zoom out"), self)
        actionPan = QAction(QString("Pan"), self)
        actionZoomIn.setCheckable(True)
        actionZoomOut.setCheckable(True)
        actionPan.setCheckable(True)
        
        self.connect(actionZoomIn, SIGNAL("triggered()"), self.zoomIn)
        self.connect(actionZoomOut, SIGNAL("triggered()"), self.zoomOut)
        self.connect(actionPan, SIGNAL("triggered()"), self.pan)
        
        self.toolbar = self.addToolBar("Canvas actions")
        self.toolbar.addAction(actionZoomIn)
        self.toolbar.addAction(actionZoomOut)
        self.toolbar.addAction(actionPan)
       
        # create the map tools
        self.toolPan = QgsMapToolPan(self.canvas)
        self.toolPan.setAction(actionPan)
        self.toolZoomIn = QgsMapToolZoom(self.canvas, False) # false = in
        self.toolZoomIn.setAction(actionZoomIn)
        self.toolZoomOut = QgsMapToolZoom(self.canvas, True) # true = out
        self.toolZoomOut.setAction(actionZoomOut)
        self.pan()
        
    def zoomIn(self):
        self.canvas.setMapTool(self.toolZoomIn)
    def zoomOut(self):
        self.canvas.setMapTool(self.toolZoomOut)
    def pan(self):
        self.canvas.setMapTool(self.toolPan)