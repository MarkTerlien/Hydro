QGIS Plugin Builder
-------------------

This is a QGIS plugin that generates a QGIS plugin template for use in creating custom plugins.
