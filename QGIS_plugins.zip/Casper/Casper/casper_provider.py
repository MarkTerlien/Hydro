# Oracle database connection
import cx_Oracle
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
from PyQt4.QtCore import *

import google_api 

# Oracle data types
NUMBER       = "NUMBER"
VARCHAR2     = "VARCHAR2"
DATE         = "DATE"

# Ogr data types
INTEGER   = "integer"
DOUBLE    = "real"
STRING    = "string"
DATETIME  = "string"

READARRAYSIZE        = 10000

class CasperProvider:
    """Connection class to Oracle database"""

    def __init__( self, DbUser, DbPass, DbConnect, QgsLogger ):
        try :
            self.oracle_connection = cx_Oracle.connect(DbUser, DbPass, DbConnect)
            self.oracle_cursor = self.oracle_connection.cursor()
            self.oracle_cursor.arraysize = READARRAYSIZE
	    self.geom = "GEOM"
	    self.QgsLogger = QgsLogger
        except Exception, err:
            raise

    def get_spatial_tables ( self ) :
	try:
	    table_list = []
	    stmt = "select table_name from user_sdo_geom_metadata" 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		table = str(row[0])
		stmt = 'select count(1) from ' + table
		try:
		    self.oracle_cursor.execute( stmt )
		    result = self.oracle_cursor.fetchall()		
		    for count in result :
			nr_rows = int(count[0])	
			if nr_rows > 0 :
			    table_list.append(table)
		except :
		    None			    
	    return table_list
	except Exception, err:
	    raise	
	
    def get_srid ( self, table_name ) :
	try :
	    stmt = "select srid from user_sdo_geom_metadata where table_name = :TABLE_NAME " 
	    self.oracle_cursor.execute(stmt, TABLE_NAME = table_name )
	    resultset = self.oracle_cursor.fetchmany()
	    if resultset :
		for row in resultset :
		    srid = str(row[0])
	    return srid	    
	except Exception, err:
	    raise	

    def get_spatial_column ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_sdo_geom_metadata where table_name = :TABLE_NAME " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table )
            resultset = self.oracle_cursor.fetchmany()
            if resultset :
                for row in resultset :
                    spatial_column = str(row[0])
            return spatial_column
        except Exception, err:
	    raise 

    def get_attributes ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_tab_columns t where t.table_name = :TABLE_NAME and data_type in ( \'NUMBER\',\'VARCHAR2\',\'DATE\') " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table )
            resultset = self.oracle_cursor.fetchmany()
            attribute_list = []
            if resultset :
                for row in resultset :
                    attribute_list.append(str(row[0]))
            return attribute_list
        except Exception, err:
            raise         
	
    def get_no_pk_attributes ( self, spatial_table ) :
        try:
            stmt = "select column_name from user_tab_columns t where t.table_name = :TABLE_NAME and data_type in ( \'NUMBER\',\'VARCHAR2\',\'DATE\') and t.column_name <> :PK_COLUMN " 
	    pk_column = self.get_primary_key ( spatial_table ) 
            self.oracle_cursor.execute(stmt, TABLE_NAME = spatial_table, PK_COLUMN = pk_column )
            resultset = self.oracle_cursor.fetchmany()
            attribute_list = []
            if resultset :
                for row in resultset :
                    attribute_list.append(str(row[0]))
            return attribute_list
        except Exception, err:
            raise    	

    def get_data_type ( self, table, attribute ) :
            stmt = "select data_type, data_scale from user_tab_columns t where t.table_name = :TABLE_NAME and t.column_name = :COLUMN_NAME " 
            self.oracle_cursor.execute(stmt, TABLE_NAME = table, COLUMN_NAME = attribute )
            resultset = self.oracle_cursor.fetchmany()
            if resultset :
                for row in resultset :
                    data_type  = str(row[0])
                    if row[1] <> None :
                        data_scale = int(row[1])
                    else :
                        data_scale = 0
            if data_type == VARCHAR2 :
                ogr_data_type = STRING
            if data_type == NUMBER and data_scale == 0 :
                ogr_data_type = INTEGER
            if data_type == NUMBER and data_scale > 0 :
                ogr_data_type = DOUBLE                
            if data_type == DATE :
                ogr_data_type = DATETIME                
            return ogr_data_type
	
    def get_geometries_for_table( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    for attribute in self.get_attributes ( table_name ) :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    return resultset
	except Exception, err:
	    raise
	
    def get_geometry_type( self, table_name ) :
	try :
	    stmt = 'select sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum = 1 ' 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    if resultset :
		for row in resultset :
		    geom = QgsGeometry.fromWkt( str(row[0]) )
		    geometry_type = int(geom.type())
	    else :
		geometry_type = None
	    return geometry_type
	except Exception, err:
	    raise	
	
    def get_nr_of_rows( self, table_name ) :
	try :
	    stmt = 'select count(1) '
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    for row in resultset :
		nr_of_rows = int(row[0])
	    return nr_of_rows
	except Exception, err:
	    raise

    def get_primary_key ( self, table_name ) :
	try :
	    stmt = 'select c2.column_name from user_constraints c1, user_cons_columns c2 where c1.constraint_name = c2.constraint_name and c1.constraint_type = \'P\' and c2.table_name = :TABLE_NAME '
	    self.oracle_cursor.execute(stmt, TABLE_NAME = table_name )
	    resultset = self.oracle_cursor.fetchmany()
	    if resultset :
		for row in resultset :
		    primary_key = str(row[0])
	    else :
		primary_key = '\'no_pk\''
	    return primary_key
	except Exception, err:
	    raise

    def get_features ( self, table_name, nr_of_rows ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) + ' where rownum <= ' + str(nr_of_rows)  	 
	    features_dict = self.get_features_dict ( stmt )  
	    self.QgsLogger.logMessage('Features in dict', 'Casper')	    
	    return features_dict 
	except Exception, err:
	    raise	    
	    
    def get_features_dict ( self, stmt, attribute_list ) : 
	try :
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    self.QgsLogger.logMessage('Query executed', 'Casper')
	    features_dict = {}
	    for row in resultset :
		attributes_dict = {}
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			pk_id = str.upper(str(row[0]))
		    elif attribute_index == 1:
			attributes_dict[self.geom] = QgsGeometry.fromWkt( str(row[1]) )
		    else :
			attributes_dict[attribute_list[attribute_index-2]] = str(row[attribute_index])
		features_dict[pk_id] = attributes_dict
	    self.QgsLogger.logMessage('Features in dict', 'Casper')
	    return features_dict		
	except Exception, err:
	    raise

    def plot_features ( self, table_name, provider ) :
	try :
	    stmt = 'select ' + self.get_primary_key ( table_name ) + ', sdo_util.to_wktgeometry(mtj_to_2d(' +  str( self.get_spatial_column ( table_name ) ) + ')) '
	    attribute_list = self.get_no_pk_attributes ( table_name ) 
	    for attribute in attribute_list :
		stmt = stmt + ',' + str(attribute)
	    stmt = stmt + ' from ' + str(table_name) 
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    nr_features = 0
	    for row in resultset :
		feature = QgsFeature()
		for attribute_index in range(0, len(row)):
		    if attribute_index == 0 :
			if nr_features == 0 : 
			    provider.addAttributes( { "ID" : "string" } )
			feature.addAttribute( attribute_index, QVariant( str.upper(str(row[0])) ) )
		    elif attribute_index == 1:
			feature.setGeometry( QgsGeometry.fromWkt( str(row[1]) ))
		    else :
			if nr_features == 0 :
			    provider.addAttributes( { str.upper(attribute_list[attribute_index-2]) : "string" } )	
			feature.addAttribute( attribute_index, QVariant( str(row[attribute_index]) ) )
		nr_features = nr_features + 1
		provider.addFeatures([feature])
	    return provider, nr_features
	except Exception, err:
	    raise	

    def get_geometries( self ) :
	try :
	    stmt = 'select naam, sdo_util.to_wktgeometry(geometrie) from ggm_wijken'
	    self.oracle_cursor.execute( stmt )
	    resultset = self.oracle_cursor.fetchall()
	    return resultset
	except Exception, err:
	    raise
	
    ######################################################################3
	
	
    def query_medewerkers( self, name ) :
	try:
	    stmt = 'select med.id, med.voornaam, med.achternaam from cas_medewerkers med where upper(med.achternaam) like upper(\'%' + str(name) + '%\') and med.datum_uit_dienst is null'
	    self.oracle_cursor.execute( stmt )
	    medewerker_list = self.oracle_cursor.fetchall()			    
	    return medewerker_list
	except Exception, err:
	    raise	
	
    def query_bedrijven( self, name ) :
	try:
	    stmt = 'select bdr.id, bdr.naam, bdr.vestiging from cas_bedrijven bdr where upper(bdr.naam) like upper(\'%' + str(name) + '%\')'
	    self.oracle_cursor.execute( stmt )
	    bedrijven_list = self.oracle_cursor.fetchall()			    
	    return bedrijven_list
	except Exception, err:
	    raise		

    def get_medewerkers ( self, medewerker_id ) :
	"""Query to Google API to get coordinates based on adres"""
	try :
	    fOut = open('c:/temp/adres_coordinaten_medewerker.sql', 'w')
	    insert_stmt = 'insert into adres_coordinaten ( coordinaat, adr_id ) values ( '
	    stmt = 'select adr.id, med.voornaam, med.achternaam, adr.straat, adr.huisnummer_van,adr.plaats from cas_adressen adr, cas_medewerkers med where adr.med_id = med.id and adr.straat is not null'
	    if medewerker_id :
		stmt = stmt + ' and med.id = ' + str(medewerker_id)
	    self.oracle_cursor.execute(stmt )
	    resultset = self.oracle_cursor.fetchall()
	    features_dict = {}
	    if resultset :
		for row in resultset :
		    attributes_dict = {}
		    attributes_dict['voornaam'] = str(row[1])
		    attributes_dict['achternaam'] = str(row[2])
		    attributes_dict['straat'] = str(row[3])
		    attributes_dict['huisnummer'] = str(row[4])
		    attributes_dict['plaats'] = str(row[5])
		    adres = str(attributes_dict['huisnummer']) + '+' + str(attributes_dict['straat']) + '+' + str(attributes_dict['plaats'])
		    x,y = google_api.get_coordinates_for_address(self.QgsLogger, address=adres,sensor="true")
		    if x and y :
			attributes_dict[self.geom] = QgsGeometry.fromPoint( QgsPoint( float(x), float(y) ) )
			features_dict[ str.upper(str(row[0])) ] = attributes_dict
			values = 'sdo_geometry(2001, 4326, sdo_point_type(' + str(x) + ', ' + str(y) + ', null), null, null), ' + str(row[0]) + ')'
			fOut.write(insert_stmt + values + ';\n')
	    fOut.close()
	    return features_dict
	except Exception, err:
	    raise	
	
    def get_bedrijven ( self ) :
	try :
	    fOut = open('c:/temp/adres_coordinaten_bedrijf_medewerker.sql', 'w')
	    insert_stmt = 'insert into adres_coordinaten ( coordinaat, adr_id ) values ( '
	    stmt = 'select distinct adr.id, bdr.naam, bdr.vestiging ,adr.straat, adr.huisnummer_van,adr.plaats' 
	    stmt = stmt + ' from cas_allocaties alo, cas_medewerkers med, cas_opdrachten opd, cas_bedrijven bdr, cas_adressen adr ' 
	    stmt = stmt + ' where med.id = alo.med_id and  alo.opd_id = opd.id and opd.bdr_id = bdr.id and med.datum_uit_dienst is null and bdr.id = adr.bdr_id '
	    stmt = stmt + ' and  not exists ( select 1 from geodemo_coordinaten bcn where bcn.adr_id = adr.id)'
	    self.oracle_cursor.execute(stmt )
	    resultset = self.oracle_cursor.fetchall()
	    features_dict = {}
	    if resultset :
		for row in resultset :
		    attributes_dict = {}
		    attributes_dict['naam'] = str(row[1])
		    attributes_dict['vestiging'] = str(row[2])
		    attributes_dict['straat'] = str(row[3])
		    attributes_dict['huisnummer'] = str(row[4])
		    attributes_dict['plaats'] = str(row[5])
		    adres = str(attributes_dict['huisnummer']) + '+' + str(attributes_dict['straat']) + '+' + str(attributes_dict['plaats'])
		    x,y = google_api.get_coordinates_for_address(self.QgsLogger, address=adres,sensor="true")
		    if x and y :
			attributes_dict[self.geom] = QgsGeometry.fromPoint( QgsPoint( float(x), float(y) ) )
			features_dict[ str.upper(str(row[0])) ] = attributes_dict
			values = 'sdo_geometry(2001, 4326, sdo_point_type(' + str(x) + ', ' + str(y) + ', null), null, null), ' + str(row[0]) + ')'
			fOut.write(insert_stmt + values + ';\n')
	    fOut.close()
	    return features_dict
	except Exception, err:
	    raise	

    def get_medewerker ( self, medewerker_id ) :
	try :
            attribute_list = ( 'voornaam', 'achternaam', 'straat', 'huisnummer', 'plaats' )
	    stmt = 'select med.id, sdo_util.to_wktgeometry(bcn.coordinaat), med.voornaam,  med.achternaam, adr.straat, adr.huisnummer_van, adr.plaats'
	    stmt = stmt + ' from cas_medewerkers med, cas_adressen adr, geodemo_coordinaten bcn'
	    stmt = stmt + ' where med.id  = adr.med_id and   adr.id = bcn.adr_id' 
	    stmt = stmt + ' and med.id = ' + str(medewerker_id)
	    #self.QgsLogger.logMessage(stmt, 'Casper')
	    features_dict = self.get_features_dict ( stmt, attribute_list )  
	    return features_dict 	    
	except Exception, err:
	    raise

    def get_bedrijven_van_medewerker ( self, medewerker_id ) :
	try :
            attribute_list = ( 'naam', 'straat', 'plaats', 'omschrijving', 'begindatum', 'einddatum' )
	    stmt = 'select bdr.id, sdo_util.to_wktgeometry(bcn.coordinaat),  bdr.naam, adr.straat, adr.plaats, opd.omschrijving, opd.werkelijke_begindatum, opd.werkelijke_einddatum'
	    stmt = stmt + ' from cas_allocaties alo, cas_medewerkers med, cas_opdrachten opd, cas_bedrijven bdr, cas_adressen adr, geodemo_coordinaten bcn'
	    stmt = stmt + ' where med.id = alo.med_id and  alo.opd_id = opd.id and opd.bdr_id = bdr.id and med.datum_uit_dienst is null and bdr.id = adr.bdr_id and   adr.id = bcn.adr_id' 
	    stmt = stmt + ' and med.id = ' + str(medewerker_id)
	    #self.QgsLogger.logMessage(stmt, 'Casper')
	    features_dict = self.get_features_dict ( stmt, attribute_list )  
	    return features_dict 	    
	except Exception, err:
	    raise


    def get_afstand_van_medewerker ( self, medewerker_id ) :
	try :
	    distance = 25
	    unit = 'km'
	    stmt = ' select sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*6) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\')),'
	    stmt = stmt + ' sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*5) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\')),'
	    stmt = stmt + ' sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*4) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\')),'
	    stmt = stmt + ' sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*3) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\')),'
	    stmt = stmt + ' sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*2) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\')),'
	    stmt = stmt + ' sdo_util.to_wktgeometry(sdo_geom.sdo_buffer(bcn.coordinaat, ' + str(distance*1) + ', 0.05 , \'unit=' + str(unit) + ' arc_tolerance=0.05\'))'
	    stmt = stmt + ' from cas_medewerkers med, cas_adressen adr, geodemo_coordinaten bcn'
	    stmt = stmt + ' where med.id  = adr.med_id and   adr.id = bcn.adr_id ' 
	    stmt = stmt + ' and med.id = ' + str(medewerker_id)
	    self.QgsLogger.logMessage(str(stmt), 'Casper')
	    self.oracle_cursor.execute(stmt )
	    resultset = self.oracle_cursor.fetchall()
	    features_dict = {}
	    if resultset :
		for row in resultset :
		    for i in range(0, len(row)) : 
			current_attributes_dict = {}
			current_geom = QgsGeometry.fromWkt( str(row[i]) )
			if i > 0 :
			    previous_attributes_dict = features_dict[int(i-1)]
			    previous_geom = previous_attributes_dict[self.geom]
			    previous_geom = previous_geom.symDifference( current_geom )
			    previous_attributes_dict[self.geom] = previous_geom
			    features_dict[int(i-1)] = previous_attributes_dict
			current_attributes_dict[self.geom] = current_geom 
			current_attributes_dict['Afstand'] = (int(6-i)*distance)
			features_dict[int(i)] = current_attributes_dict
	    return features_dict 	    
	except Exception, err:
	    raise
	
    def rollback_close( self ) :
        """Function to rollback and close connection"""
        self.oracle_connection.rollback()
        self.oracle_connection.close()

    def commit_close( self ) :
        """Function to commit and close connection"""
        self.oracle_connection.commit()
        self.oracle_connection.close()	