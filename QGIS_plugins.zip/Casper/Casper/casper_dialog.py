from PyQt4 import QtCore, QtGui
from PyQt4.QtCore import *
from PyQt4.QtGui import *

class TableListWidgetM(QListWidget):
    def __init__(self, OracleConnection):
	QListWidget.__init__(self)
	self.OracleConnection = OracleConnection
	#self.add_items()

    def add_items(self, achternaam):
	for medewerker in self.OracleConnection.query_medewerkers( achternaam ) :
		self.addItem(QListWidgetItem(str(medewerker[0]) + ': ' + str(medewerker[1]) + ' ' + str(medewerker[2])))
		
class TableListWidgetB(QListWidget):
    def __init__(self, OracleConnection):
	QListWidget.__init__(self)
	self.OracleConnection = OracleConnection
	#self.add_items()

    def add_items(self, bedrijf):
	for bedrijf in self.OracleConnection.query_bedrijven( achternaam ) :
		self.addItem(QListWidgetItem(str(bedrijf[0]) + ': ' + str(bedrijf[1]) + ' ' + str(bedrijf[2])))		

# create the dialog for the qwidget builder
class MedewerkerDialog(QtGui.QDialog):
    def __init__(self, OracleConnection):
        
        QtGui.QDialog.__init__(self)
	self.OracleConnection = OracleConnection
	self.TableListM = TableListWidgetM ( self.OracleConnection )
        
        self.btn = QtGui.QPushButton('Zoek Medewerker', self)
        self.btn.move(20, 20)
        self.btn.clicked.connect(self.showDialog)	
	
        self.le = QtGui.QLineEdit(self)
        self.le.move(130, 22)	
	
	layout = QVBoxLayout()
	layout.addWidget(self.TableListM)
	layout.addWidget(self.btn)
	
	self.setLayout(layout)		

    def showDialog(self):
        
        text, ok = QtGui.QInputDialog.getText(self, 'Input Dialog', 
            'Geef Medewerker naam:')
        
        if ok:
            #self.le.setText(str(text))    
	    self.TableListM.add_items(str(text))
	    
class BedrijfDialog(QtGui.QDialog):
    def __init__(self, OracleConnection):
        
        QtGui.QDialog.__init__(self)
	self.OracleConnection = OracleConnection
	self.TableListB = TableListWidgetB ( self.OracleConnection )
        
        self.btn = QtGui.QPushButton('Zoek Medewerker', self)
        self.btn.move(20, 20)
        self.btn.clicked.connect(self.showDialog)	
	
        self.le = QtGui.QLineEdit(self)
        self.le.move(130, 22)	
	
	layout = QVBoxLayout()
	layout.addWidget(self.TableListB)
	layout.addWidget(self.btn)
	
	self.setLayout(layout)		

    def showDialog(self):
        
        text, ok = QtGui.QInputDialog.getText(self, 'Input Dialog', 
            'Geef Mederwerker naam:')
        
        if ok:
            #self.le.setText(str(text))    
	    self.TableListB.add_items(str(text))