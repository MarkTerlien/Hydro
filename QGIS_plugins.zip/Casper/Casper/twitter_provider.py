# Oracle database connection
import simplejson
from qgis.core import *
from qgis.gui import *
from qgis.utils import *
import win32api
import os

GEOM = "GEOM"
TEXT = "TEXT"

# Get twitter file:
# curl -k -d @locations.txt https://stream.twitter.com/1/statuses/filter.json -x proxy.transfer-solutions.com:3128  -u markterlien:gianni1990 > tweets.json

class TwitterProvider:
    """Connection class to twitter file"""

    def __init__( self, file_name ):
        try :
            self.file_name = file_name
        except Exception, err:
            raise

    def get_features ( self ) :
        try:
	    fIn = open( self.file_name,'r')
	    features_dict = {}
	    nr_features = 0
	    for line in fIn:
		if line[0] == '{' :
		    try :
			nr_features = nr_features + 1
			attributes_dict = {}
			j = simplejson.loads(line)
			attributes_dict[GEOM] = QgsGeometry.fromPoint(QgsPoint(j['geo']['coordinates'][1],j['geo']['coordinates'][0]))
			attributes_dict[TEXT] = str(j['text']) 
			features_dict[str.upper(str(nr_features))] = attributes_dict
		    except :
			None 
	    fIn.close()
	    return features_dict			
        except Exception, err:
	    raise 

