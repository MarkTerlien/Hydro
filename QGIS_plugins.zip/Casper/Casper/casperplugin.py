# Import PyQt  libraries
from PyQt4.QtCore import *
from PyQt4.QtGui import *

# Import qgis libraries
from qgis.core import *
from qgis.gui import *
from qgis.utils import *

# Import provider libraries
from casper_provider import CasperProvider
from twitter_provider import TwitterProvider

# Import Qt dialogs
from casper_dialog import *

import google_api

# For open layers layer
import math
from openlayers_layer import OpenlayersLayer
from openlayers_plugin_layer_type import OpenlayersPluginLayerType

import win32api

# Database connection parameter values
DB_USER_SOURCE       = "Databse user"
DB_PASSWORD_SOURCE   = "Password"
DB_TNS_SOURCE        = "Connect string"
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "cas_geodemo"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "demogeo"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "172.30.0.98/TCSRLE"


# Map qgis geometry type id's 
QGIS_GEOMETRY_TYPES = {}
QGIS_GEOMETRY_TYPES[0] = 'Point'
QGIS_GEOMETRY_TYPES[1] = 'Line'
QGIS_GEOMETRY_TYPES[2] = 'Polygon'
QGIS_GEOMETRY_TYPES[3] = 'UnknownGeometry'

PLUGIN_PATH = "C:/OSGeo4W/apps/qgis/python/plugins/Casper/"


#############################################################

class OlLayerType:
    def __init__(self, plugin, name, icon, html, emitsLoadEnd = False):
	self.__plugin = plugin
	self.name = name
	self.icon = icon
	self.html = html
	self.emitsLoadEnd = emitsLoadEnd
	self.id = None
    def addLayer(self):
	self.__plugin.addLayer(self)

class OlLayerTypeRegistry:
    def __init__(self):
	self.__olLayerTypes = {}
	self.__layerTypeId = 0
    def add(self, layerType):
	layerType.id = self.__layerTypeId
	self.__olLayerTypes[self.__layerTypeId] = layerType
	self.__layerTypeId += 1
    def types(self):
	return self.__olLayerTypes.values()
    def getById(self, id):
	return self.__olLayerTypes[id]


##############################################################

class CasperPlugin:

    def __init__(self, iface):
        # Save reference to the QGIS interface
        self.iface = iface
	self.layers = []
	
	# Open DB connection
	self.OracleConnection = CasperProvider ( PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE], PARAMETER_LIST_VALUE [DB_TNS_SOURCE], QgsMessageLog )
	
	# Get pointer to map canvas	
	self.canvas = self.iface.mapCanvas()	
	self.first_layer = True

    def initGui(self):
        # Create action that will start plugin configuration (self, QIcon icon, QString text, QObject parent)
	self.action = QAction(QIcon(PLUGIN_PATH + "database.png"), "Open Casper Database...", self.iface.mainWindow())
        
        # connect the action to the run method
        QObject.connect(self.action, SIGNAL("triggered()"), self.run)

        # Add toolbar button and menu item
        self.iface.addToolBarIcon(self.action)
        self.iface.addPluginToMenu("&Casper...", self.action)

    def unload(self):
        # Remove the plugin menu item and icon
        self.iface.removePluginMenu("&Casper...",self.action)
        self.iface.removeToolBarIcon(self.action)
	
    def run(self) :
	
	QgsMessageLog.logMessage('Get features from GGM database', 'GGM')
	
	#self.plot_bedrijven_from_db () 
	#self.plot_route()
	
	# Build dialog
	self.dlg = MedewerkerDialog ( self.OracleConnection ) 
	self.dlg.TableListM.itemClicked.connect(self.plot_background_layer)
	self.first_layer = False
	self.dlg.TableListM.itemClicked.connect(self.plot_afstand_van_medewerker)
	self.dlg.TableListM.itemClicked.connect(self.plot_medewerker_from_db)
	self.dlg.TableListM.itemClicked.connect(self.plot_bedrijven_van_medewerker)
	self.plot_map()

	# show the dialog
	self.dlg.show()
	result = self.dlg.exec_()
	    
	#######################################################################

	#self.TwitterConnection = TwitterProvider(PLUGIN_PATH + "tweets.json")
	#features_dict = self.TwitterConnection.get_features ()
	#self.plot_features ( "Twitter", features_dict, 4326, "Point" )	
	
	#######################################################################

    def plot_medewerkers_from_db ( self, medewerker ) :
	try :
	    QgsMessageLog.logMessage('Plot medewerkers', 'Casper')
	    if medewerker :
		medewerker_id = str(medewerker.text()).split(':')[0]
		QgsMessageLog.logMessage('Plot medewerker ' + str(medewerker_id), 'Casper')
	    else :
		medewerker_id = None
	    features_dict = self.OracleConnection.get_medewerkers ( medewerker_id ) 
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering medewerker', 'Casper')
		geometry_type  = 'Point'
		srid = 4326
		if geometry_type :
		    self.plot_features ( "Medewerkers", features_dict, srid, geometry_type, None, None )	
	except Exception, err:
	    raise   

    def plot_medewerker_from_db ( self, medewerker ) :
	try :
	    QgsMessageLog.logMessage('Plot medewerkers', 'Casper')
	    if medewerker :
		medewerker_id = str(medewerker.text()).split(':')[0]
		QgsMessageLog.logMessage('Plot medewerker ' + str(medewerker_id), 'Casper')
	    else :
		medewerker_id = None
	    features_dict = self.OracleConnection.get_medewerker ( medewerker_id ) 
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering medewerker', 'Casper')
		geometry_type  = 'Point'
		srid = 4326
		symbol = QgsMarkerSymbolV2.createSimple( { 'color' : '0,255,0' } ) 
	        point_renderer = QgsSingleSymbolRendererV2( symbol )		
		if geometry_type :
		    self.plot_features ( str(medewerker.text()).split(':')[1], features_dict, srid, geometry_type, point_renderer, None )	
	except Exception, err:
	    raise  


    def plot_bedrijven_van_medewerker ( self, medewerker ) :
	try :
	    QgsMessageLog.logMessage('Plot medewerkers', 'Casper')
	    if medewerker :
		medewerker_id = str(medewerker.text()).split(':')[0]
		QgsMessageLog.logMessage('Plot medewerker ' + str(medewerker_id), 'Casper')
	    else :
		medewerker_id = None
	    features_dict = self.OracleConnection.get_bedrijven_van_medewerker ( medewerker_id ) 
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'Casper')
		geometry_type  = 'Point'
		srid = 4326
		symbol = QgsMarkerSymbolV2.createSimple( { 'color' : '255,0,0' } ) 
	        point_renderer = QgsSingleSymbolRendererV2( symbol )		
		if geometry_type :
		    self.plot_features ( "Bedrijven", features_dict, srid, geometry_type, point_renderer, None )	
	except Exception, err:
	    raise 
	
    def plot_afstand_van_medewerker ( self, medewerker ) :
	try :
	    QgsMessageLog.logMessage('Plot afstand medewerker', 'Casper')
	    if medewerker :
		medewerker_id = str(medewerker.text()).split(':')[0]
		QgsMessageLog.logMessage('Plot afstand van medewerker ' + str(medewerker_id), 'Casper')
	    else :
		medewerker_id = None
	    features_dict = self.OracleConnection.get_afstand_van_medewerker ( medewerker_id ) 
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'Casper')
		geometry_type  = 'Polygon'
		srid = 4326
		qml_uri = PLUGIN_PATH + "distance.qml"
		if geometry_type :
		    self.plot_features ( "Afstand", features_dict, srid, geometry_type, None, qml_uri )	
	except Exception, err:
	    raise 	

    def plot_route ( self ) :
	try :
	    QgsMessageLog.logMessage('Plot medewerkers', 'Casper')
	    features_dict = google_api.get_route_segments(QgsMessageLog, origin="75+Bramenetuin+Teteringen",destination="23+Heusdenhoutseweg+Breda",sensor="false" )  
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'Casper')
		geometry_type  = 'LineString'
		srid = 4326
		if geometry_type :
		    self.plot_features ( "Route", features_dict, srid, geometry_type, None, None )	
	except Exception, err:
	    raise  	

   
    def plot_bedrijven_from_db ( self ) :
	try :
	    QgsMessageLog.logMessage('Plot bedrijven', 'Casper')
	    nr_of_rows = 2000
	    features_dict = self.OracleConnection.get_bedrijven () 
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'Casper')
		geometry_type  = 'Point'
		srid = 4326
		if geometry_type :
		    self.plot_features ( "Bedrijven", features_dict, srid, geometry_type, None, None )	
	except Exception, err:
	    raise    
   
   
    def plot_features_from_db ( self, table_name ) :
	try :
	    
	    spatial_table = str(table_name.text())
	    
	    QgsMessageLog.logMessage('Plot features from table ' + spatial_table, 'GGM')
	    
	    # Write features from db to dictionary	
	    nr_of_rows = 2000
	    features_dict = self.OracleConnection.get_features ( spatial_table, nr_of_rows ) 
	    
	    if len(features_dict) > 0 :
		QgsMessageLog.logMessage('Start rendering features', 'GGM')
		geometry_type  = QGIS_GEOMETRY_TYPES[self.OracleConnection.get_geometry_type( spatial_table )] 
		srid = int(self.OracleConnection.get_srid( spatial_table ))
		QgsMessageLog.logMessage('Geometry type is ' + geometry_type , 'GGM')
		if geometry_type :
		    self.plot_features ( spatial_table, features_dict, srid, geometry_type )	
	
	except Exception, err:
	    raise	    		
	
    
    def plot_features ( self, layer_name, features_dict, features_crs, geometry_type, renderer, qml_uri ) :
	try :
	    
	    QgsMessageLog.logMessage('Plot layer ' + str(layer_name), 'GGM')
	    
	    # Create layer definition
	    layer = QgsVectorLayer(geometry_type, layer_name, "memory")
	    layer.startEditing()
	    crs = QgsCoordinateReferenceSystem(features_crs, QgsCoordinateReferenceSystem.PostgisCrsId)
	    layer.setCrs(crs)
	    provider = layer.dataProvider()
	    
	    # Add renderer
	    if renderer : 
		layer.setRendererV2( renderer )
	    if qml_uri :
		layer.loadNamedStyle(qml_uri) 		
    
	    # Add attributes; When first feature create first the feature definition (first add geometry then other attributes)
	    nr_features = 0
	    for feature_id, feature_dict in features_dict.iteritems() :

		# Create the feature definition
		if nr_features == 0 :
		    provider.addAttributes( { "ID" : "string" } )
		    for attribute_name, attribute_value in feature_dict.iteritems() :
			if str.upper(str(attribute_name)) <> self.OracleConnection.geom:
			    provider.addAttributes( { str.upper(attribute_name) : "string" } )
		    
		# Initiate feature
		i = 0
		feature = QgsFeature()		
		
		# Add the geometry
		feature.setGeometry( feature_dict[self.OracleConnection.geom] )
		
		# Add unique id
		feature.addAttribute( i, QVariant( feature_id ) )
		
		# Add other attributes
		for attribute_name, attribute_value in feature_dict.iteritems() :
		    if str.upper(attribute_name) <> self.OracleConnection.geom :
			i = i + 1
			feature.addAttribute( i, QVariant( str(attribute_value) ) )
		
		# Add attribute to provider
		nr_features = nr_features + 1
		provider.addFeatures([feature])
		
	    # Update extents of provider
	    layer.commitChanges()
	    layer.updateExtents()	
    
	    # Add layer to map registry
	    QgsMapLayerRegistry.instance().addMapLayer(layer)
	    
	    # Set extent to the extent of our layer (only when it is the first layer)
	    if self.first_layer :
		self.canvas.setExtent(layer.extent())
	    
	    # Add layer to layer list
	    canvas_layer = QgsMapCanvasLayer(layer) 
	    self.layers.insert(0,canvas_layer)
	    canvas_layer.setVisible(True)
	    self.canvas.setLayerSet(self.layers)
	    self.canvas.show()
	    
	    # Set up the map canvas layer set
	    #self.canvas.setLayerSet( [ QgsMapCanvasLayer(layer) ] )	
	    #self.canvas.show()
	    
	    QgsMessageLog.logMessage(str(nr_features) + ' features plotted', 'Casper')
	    
	except Exception, err:
	    raise	    
	
    #####################################################################    
    #
    # These are the classes and functions for GoogleMaps OpenLayers layer
    #
    #####################################################################   


    def plot_background_layer ( self ) :
	
	# Set layer to display as background
	result = self.__setCoordRSGoogle()
	self.olLayerTypeRegistry = OlLayerTypeRegistry()
	self.olLayerTypeRegistry.add( OlLayerType(self, 'Google Physical', 'google_icon.png', 'google_physical.html', True) )	
	
	# Register plugin layer type
	#QgsPluginLayerRegistry.instance().addPluginLayerType(OpenlayersPluginLayerType(self.iface, self.setReferenceLayer, self.__coordRSGoogle, self.olLayerTypeRegistry))	
	#self.layer = None
	
        self.addLayer( OlLayerType(self, 'Google Physical', 'google_icon.png', 'google_physical.html', True) )	

    
    def __setCoordRSGoogle(self):
	idEpsgRSGoogle = 3857
	self.__coordRSGoogle = QgsCoordinateReferenceSystem()
	if not self.__coordRSGoogle.createFromEpsg(idEpsgRSGoogle):
	    google_proj_def = "+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 "
	    google_proj_def += "+units=m +nadgrids=@null +wktext +no_defs"
	    isOk = self.__coordRSGoogle.createFromProj4(google_proj_def)
	    if isOk:
		return True
	    else:
		return False
	else:
	    return True
  
    def __setMapSrsGoogle(self):
	mapCanvas = self.iface.mapCanvas()
	# On the fly
	mapCanvas.mapRenderer().setProjectionsEnabled(True) 
	theCoodRS = mapCanvas.mapRenderer().destinationSrs()
	if theCoodRS != self.__coordRSGoogle:
	    coodTrans = QgsCoordinateTransform(theCoodRS, self.__coordRSGoogle)
	    extMap = mapCanvas.extent()
	    extMap = coodTrans.transform(extMap, QgsCoordinateTransform.ForwardTransform)
	    mapCanvas.mapRenderer().setDestinationSrs(self.__coordRSGoogle)
	    mapCanvas.freeze(False)
	    mapCanvas.setMapUnits(self.__coordRSGoogle.mapUnits())
	    mapCanvas.setExtent(extMap)    
	    
    def addLayer(self, layerType):
	self.__setMapSrsGoogle()
	layer = OpenlayersLayer(self.iface, self.__coordRSGoogle, self.olLayerTypeRegistry)
	layer.setLayerName(layerType.name)
	layer.setLayerType(layerType)
	if layer.isValid():
	    QgsMapLayerRegistry.instance().addMapLayer(layer)
	    self.setReferenceLayer(layer)
	    canvas_layer = QgsMapCanvasLayer(layer) 
	    self.layers.insert(0,canvas_layer)
	    canvas_layer.setVisible(True)
	    self.canvas.setLayerSet(self.layers)	    
	    
    def setReferenceLayer(self, layer):
	self.layer = layer
	    
	    
    #####################################################################    
    #
    # These are the classes and functions to plot the map
    #
    #####################################################################   
    
    
    def plot_map( self ) :
	mapRenderer = self.iface.mapCanvas().mapRenderer()
	c = QgsComposition(mapRenderer)
	c.setPlotStyle(QgsComposition.Print)   
	
	# Map
	x, y = 0, 0
	w, h = c.paperWidth(), c.paperHeight()
	composerMap = QgsComposerMap(c, x,y,w,h)
	c.addItem(composerMap)	
	
	# Label
	composerLabel = QgsComposerLabel(c)
	composerLabel.setText("Hello world")
	composerLabel.adjustSizeToText()
	c.addItem(composerLabel)	
	
	# Legend
	legend = QgsComposerLegend(c)
	legend.model().setLayerSet(mapRenderer.layerSet())
	c.addItem(legend)	
	
	# Scale bar
	item = QgsComposerScaleBar(c)
	item.setStyle('Numeric') # optionally modify the style
	item.setComposerMap(composerMap)
	item.applyDefaultSize()
	c.addItem(item)	
	
	# set label 1cm from the top and 2cm from the left of the page
	composerLabel.setItemPosition(20,10)
	# set both label's position and size (width 10cm, height 3cm)
	composerLabel.setItemPosition(20,10, 100, 30)	
	
	composerLabel.setFrame(False)
	
	dpi = c.printResolution()
	dpmm = dpi / 25.4
	width = int(dpmm * c.paperWidth())
	height = int(dpmm * c.paperHeight())
	
	# create output image and initialize it
	image = QImage(QSize(width, height), QImage.Format_ARGB32)
	image.setDotsPerMeterX(dpmm * 1000)
	image.setDotsPerMeterY(dpmm * 1000)
	image.fill(0)
	
	# render the composition
	imagePainter = QPainter(image)
	sourceArea = QRectF(0, 0, c.paperWidth(), c.paperHeight())
	targetArea = QRectF(0, 0, width, height)
	c.render(imagePainter, targetArea, sourceArea)
	imagePainter.end()
	
	image.save("c:/temp/out.png", "png")	