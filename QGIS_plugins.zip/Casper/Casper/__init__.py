"""
/***************************************************************************
    PluginBuilder

    Creates a QGIS plugin template for use as a starting point in plugin
    development.
                             -------------------
        begin                : 2011-01-20
        copyright            : (C) 2011 by GeoApt LLC
        email                : gsherman@geoapt.com
 ***************************************************************************/

/***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************/
 This script initializes the plugin, making it known to QGIS.
"""
def name():
    return "Casper Plugin"
def description():
    return "Plugin to access Casper"
def version():
    return "Version 1.8.3"
def icon():
    return 'database.png'
def qgisMinimumVersion():
    return "1.8"
def authorName():
    return "Mark T. J. Terlien"
def classFactory(iface):
    # load plugin class from file GgmPlugin
    from casperplugin import CasperPlugin
    return CasperPlugin(iface)
