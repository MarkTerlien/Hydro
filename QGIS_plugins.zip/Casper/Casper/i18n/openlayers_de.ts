<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS><TS version="1.1" language="de">
<context>
    <name>Form</name>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="72"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="73"/>
        <source>Enable map</source>
        <translation>Karte anzeigen</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="74"/>
        <source>Add map</source>
        <translation>Zur Karte hinzufügen</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="75"/>
        <source>Hide cross in map</source>
        <translation>Kreuz nicht in Karte anzeigen</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="76"/>
        <source>Refresh map</source>
        <translation>Karte neu laden</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="77"/>
        <source>Save this image</source>
        <translation>Als Bild speichern</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidgetbase.py" line="78"/>
        <source>Copy rectangle (KML) of map to clipboard</source>
        <translation>Ausdehnung als KML in Zwischenablage kopieren</translation>
    </message>
</context>
<context>
    <name>OpenLayersOverviewWidget</name>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Save image</source>
        <translation>Bild speichern</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="235"/>
        <source>Image(*.jpg)</source>
        <translation>Bild(*.jpg)</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>OpenLayers Overview</source>
        <translation>OpenLayers Übersicht</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="158"/>
        <source>At least one layer in map canvas required</source>
        <translation>Mindestens ein Layer in der Karte benötigt</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="248"/>
        <source>Error loading page!</source>
        <translation>Fehler beim Laden der Seite!</translation>
    </message>
    <message>
        <location filename="openlayers_ovwidget.py" line="258"/>
        <source>Loading %1...</source>
        <translation>Lade %1...</translation>
    </message>
</context>
<context>
    <name>OpenlayersPlugin</name>
    <message>
        <location filename="openlayers_plugin.py" line="144"/>
        <source>OpenLayers Overview</source>
        <translation>OpenLayers Übersicht</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="154"/>
        <source>Add %1 layer</source>
        <translation>%1 hinzufügen</translation>
    </message>
    <message>
        <location filename="openlayers_plugin.py" line="161"/>
        <source>Could not set Google projection!</source>
        <translation>Konnte Google Projektion nicht setzen!</translation>
    </message>
</context>
</TS>
