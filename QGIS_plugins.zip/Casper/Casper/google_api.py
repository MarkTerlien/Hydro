import urllib
import time
from xml.dom import minidom
from elementtree import ElementTree
from owslib.wms import WebMapService
from qgis.core import *


GEOCODE_BASE_URL_XML = 'http://maps.googleapis.com/maps/api/geocode/xml'
DIRECTIONS_BASE_URL_XML = 'http://maps.google.com/maps/api/directions/xml'
USE_PROXY = True
PROXY = 'http://172.29.10.10:3128'

# De volgende URL geeft XML output: 
# http://maps.googleapis.com/maps/api/geocode/xml


def decode_line(encoded):

    """Decodes a polyline that was encoded using the Google Maps method.
    
    from: http://seewah.blogspot.nl/2009/11/gpolyline-decoding-in-python.html

    See http://code.google.com/apis/maps/documentation/polylinealgorithm.html
    
    This is a straightforward Python port of Mark McClure's JavaScript polyline decoder
    (http://facstaff.unca.edu/mcmcclur/GoogleMaps/EncodePolyline/decode.js)
    and Peter Chng's PHP polyline decode
    (http://unitstep.net/blog/2008/08/02/decoding-google-maps-encoded-polylines-using-php/)
    """

    encoded_len = len(encoded)
    index = 0
    array = []
    lat = 0
    lng = 0

    while index < encoded_len:

        b = 0
        shift = 0
        result = 0

        while True:
            b = ord(encoded[index]) - 63
            index = index + 1
            result |= (b & 0x1f) << shift
            shift += 5
            if b < 0x20:
                break

        dlat = ~(result >> 1) if result & 1 else result >> 1
        lat += dlat

        shift = 0
        result = 0

        while True:
            b = ord(encoded[index]) - 63
            index = index + 1
            result |= (b & 0x1f) << shift
            shift += 5
            if b < 0x20:
                break

        dlng = ~(result >> 1) if result & 1 else result >> 1
        lng += dlng

        array.append((lat * 1e-5, lng * 1e-5))

    return array


def get_route_segments(QgsLogger, origin, destination, sensor, **geo_args ) :
    
    # Set html request parameters
    geo_args.update({
        'origin': origin,
        'destination': destination,
        'sensor': sensor
    })
    
    # Build URL
    url = DIRECTIONS_BASE_URL_XML + '?' + urllib.urlencode(geo_args)   
    
    # Get response
    if USE_PROXY == True :
	response = minidom.parse(urllib.urlopen(url, proxies = {'http': PROXY}))
    else :
	response = minidom.parse(urllib.urlopen(url))
    status = str(response.getElementsByTagName('status')[0].childNodes[0].nodeValue)
    
    # Process resonse  
    dresponse = response.getElementsByTagName('DirectionsResponse')[0]
    status = dresponse.getElementsByTagName('status')[0].childNodes[0].nodeValue
    QgsLogger.logMessage('Status routing ' + str(status) , 'Casper')

    if status == 'OK' :    
	route = dresponse.getElementsByTagName('route')[0]
	features_dict = {}
	nr_segments = 0
	for leg in dresponse.getElementsByTagName('leg') :
	    for step in leg.getElementsByTagName('step') :
		html_instructions = step.getElementsByTagName('html_instructions')[0].childNodes[0].nodeValue
		duration = step.getElementsByTagName('duration')[0].getElementsByTagName('text')[0].childNodes[0].nodeValue 
		distance = step.getElementsByTagName('distance')[0].getElementsByTagName('text')[0].childNodes[0].nodeValue 
		points = step.getElementsByTagName('polyline')[0].getElementsByTagName('points')[0].childNodes[0].nodeValue 
		point_list = []
		for point in decode_line(points) :
			QgsLogger.logMessage(str(point), 'Casper')
			y = float(point[0])
			x = float(point[1])
			point_list.append(QgsPoint(x,y))
		qLine = QgsGeometry.fromPolyline( point_list )
		attributes_dict = {}
		attributes_dict['duration'] = str(duration)
		attributes_dict['distance'] = str(distance)
		attributes_dict['GEOM'] = qLine
		nr_segments = nr_segments + 1
		features_dict[ str.upper(str(nr_segments)) ] = attributes_dict
    return features_dict
		
		
		
		


def get_coordinates_for_address(QgsLogger, address,sensor, **geo_args):
    
    try : 
        # Set html request parameters
        geo_args.update({
            'address': address,
            'sensor': sensor  
        })
        
        # Build URL
        url = GEOCODE_BASE_URL_XML + '?' + urllib.urlencode(geo_args)   
        
        # Get response
	if USE_PROXY == True :
	    response = minidom.parse(urllib.urlopen(url, proxies = {'http': PROXY}))
	else :
	    response = minidom.parse(urllib.urlopen(url))
	status = str(response.getElementsByTagName('status')[0].childNodes[0].nodeValue)
        
        # Process resonse
	# If zero results, requery on street/town only
	x = None
	y = None	
	if status == 'OK' :
	    location = response.getElementsByTagName('result')[0].getElementsByTagName('geometry')[0].getElementsByTagName('location')[0]
	    x = location.getElementsByTagName('lng')[0].childNodes[0].nodeValue
	    y = location.getElementsByTagName('lat')[0].childNodes[0].nodeValue
	elif status == 'ZERO_RESULTS' :
	    adres = address.split('+', 1) 
	    if len(adres) > 1 : 
		QgsLogger.logMessage('Requery voor adres ' + str(address.split('+', 1)[1]) , 'Casper')
		nieuw_adres = str(adres[1])
		x,y = get_coordinates_for_address(QgsLogger, address=nieuw_adres, sensor="true")
	    else :
		QgsLogger.logMessage('Adres ' + str(address) + ' niet gevonden; Reden ' + str(status), 'Casper')
	elif status == 'OVER_QUERY_LIMIT' :
	    QgsLogger.logMessage('Wacht 1 seconde en resubmit adres ' + str(address), 'Casper')
	    time.sleep(1)
	    x,y = get_coordinates_for_address(QgsLogger, address=address, sensor="true")
	else :
	    QgsLogger.logMessage('Adres ' + str(address) + ' niet gevonden; reden ' + str(status), 'Casper')
	
        return x, y

    except Exception, err:
	raise
    

            

    

    
    
#if __name__ == '__main__':
#    get_coordinates_for_address(address="75+Bramenetuin+Teteringen",sensor="true")
#    get_route(origin="75+Bramenetuin+Teteringen",destination="56+koninginneweg+kortenhoef",sensor="false")    