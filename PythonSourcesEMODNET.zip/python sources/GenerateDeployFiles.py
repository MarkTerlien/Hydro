#! /usr/bin/python

""" Template function """

# standard library imports
import sys
import os
import shutil
import logging
import datetime
import re
import xml.dom.minidom
from htmlentitydefs import name2codepoint

# related third party imports
import cx_Oracle
try :
    from easygui import *
except :
    None

# local application/library specific imports

__author__="Terlien"
__date__ ="$9-okt-2009 11:50:05$"
__copyright__ = "Copyright 2009, ATLIS"


MODULE_NAME = "GenerateDeployFiles"

DATABASE_COMPONENT = "Database"

SENS_VERSION = int(2)

#SENS_PASSWORD = "senso"

# File names
VERSION_FILE     = "version"
DDL_SCRIPT       = "ddl_script.sql"

# Default datafile path
DATAFILE_PATH  = "<DATAFILE_PATH>"

# Database parameters
SRID                = 8307
MIN_ID_SCHEMA_OWNER = 1000000

# Table object class ID
OBJ_CLASS_CLASS_ID  = int(238)
ATTRIBUTE_CLASS_ID  = int(318)
ATTR_VIEW_CLASS_ID  = int(672)
VIEW_CLASS_ID       = int(671)
BL_CLASS_ID         = int(673)
BL_DML_CLASS_ID     = int(674)
BL_CHK_CLASS_ID     = int(675)
ATTR_PARAM_CLASS_ID = int(583)
PARAM_DEP_CLASS_ID  = int(584)

# Parameters
SVN_TRUNK_HOME            = "SVN_TRUNK_HOME"
ORACLE_HOME               = "ORACLE_HOME"
DEPLOY_FILE_DIR           = "DEPLOY_FILE_DIR"
UPGRD_INSTALL_GENERATION  = "UPGRD_INSTALL_GENERATION"
CLEAN_INSTALL_GENERATION  = "CLEAN_INSTALL_GENERATION"
UPDATE_DB_VERSION         = "UPDATE_DB_VERSION"
BATHY_CLIENT_VERSION      = "BATHY_CLIENT_VERSION"
DB_USER_SOURCE            = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE        = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE             = "DB_TNS_SOURCE"
TABLESPACE_PATH_TARGET    = "TABLESPACE_PATH_TARGET"
OBJECT_CLASS_ID           = "OBJECT_CLASS_ID"
WRAP_IN_DB                = "WRAP_IN_DB"

# Parameter default values
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ SVN_TRUNK_HOME ]            = 'D:/SVNQarto/QartoFunc/trunk/QartoFunc'
PARAMETER_LIST_VALUE [ ORACLE_HOME ]               = 'D:/app/terlien/product/11.2.0/client_2'
PARAMETER_LIST_VALUE [ DEPLOY_FILE_DIR ]           = 'C:/temp/deploy'
PARAMETER_LIST_VALUE [ UPGRD_INSTALL_GENERATION ]  = "T"
PARAMETER_LIST_VALUE [ CLEAN_INSTALL_GENERATION ]  = "T"
PARAMETER_LIST_VALUE [ UPDATE_DB_VERSION ]         = "F"
PARAMETER_LIST_VALUE [ OBJECT_CLASS_ID ]           = "0"
PARAMETER_LIST_VALUE [ BATHY_CLIENT_VERSION ]      = "1500"
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]            = "sens"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ]        = "senso"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]             = "10.20.0.49/sens11"
PARAMETER_LIST_VALUE [ TABLESPACE_PATH_TARGET ]    = DATAFILE_PATH
PARAMETER_LIST_VALUE [ WRAP_IN_DB ]                = True

# Scripts
SC_SYS_GRANTS           = "0_SYS_grant_privileges"
SC_MDSYS_GRANTS         = "0_MDSYS_grant_privileges"
SC_CREATE_TABLESPACES   = "0_SYSTEM_create_tablespaces"
SC_CREATE_USERS         = "1_SYSTEM_create_users_and_roles"
SC_SENS_GRANTS          = "1_SYSTEM_grants_to_sens_users_and_roles"
SC_CREATE_TYPES         = "2_SENS_tp_install"
SC_DDL_STATEMENTS       = "3_SENS_ddl_install"
SC_CREATE_SPATIAL_INDEX = "4_SENS_create_spatial_index"
SC_CREATE_PACKAGES      = "5_SENS_install_plsql_packages"
SC_CREATE_VIEWS         = "6_SENS_vw_install"
SC_DML_STATEMENTS       = "7_SENS_dml_install"
SC_CREATE_FKS           = "8_SENS_fk_install"
SC_ROLE_GRANTS          = "9_SENS_grants_to_sens_role"
SC_CREATE_SYNONYMS      = "10_SENS_create_public_synonyms"
SC_CREATE_DEFAULT_USERS = "11_SENS_create_default_users"

# Rowset tag
ROWSET                  = "ROWSET"

def htmlentitydecode(s):
    return re.sub('&(%s);' % '|'.join(name2codepoint),
            lambda m: unichr(name2codepoint[m.group(1)]), s)

def xmlspecialcharsdecode(text):
        text_unescaped = text.replace(u"&amp;", u"&")\
               .replace(u"&lt;", u"<")\
               .replace(u"&gt;", u">" )\
               .replace(u"&apos;", u"'")\
               .replace(u"&quot;", u'"')
        return htmlentitydecode( text_unescaped )

def parse_insert_object ( fIn, DbConnection, dml_obj_class_id, dml_statement ) :
    """Function to generate insert statement"""
    oracle_cursor  = DbConnection.cursor()
    l_table_name   = oracle_cursor.callfunc("sdb_interface_pck.getTableName", str, [ dml_obj_class_id ])
    l_xml          = xml.dom.minidom.parseString( dml_statement )
    l_id_elem_list = l_xml.getElementsByTagName( 'ID' )
    for l_id_elem in l_id_elem_list :
        l_obj_inst_id  = str(l_id_elem.childNodes[0].nodeValue)
    l_where_clause = ' id = ' + l_obj_inst_id
    write_table_dml ( DbConnection, fIn, l_table_name, False, l_where_clause )

def parse_set_object ( fIn, dml_obj_class_id, dml_iud, dml_statement ) :
    "Function to plsql  block for setObject"

    # Add function to replace ' in dml statement by '' (for Oracle)
    dml_statement_parsed = xmlspecialcharsdecode(dml_statement)
    dml_statement_new    = str.replace( str(dml_statement_parsed), "'", "''")

    # If XML then use setOject function else dml is a wkt geometry and use setGeom
    if ROWSET in str(dml_statement_new) :
        fIn.write ( "-- PLSQL block --" + "\n""")
        fIn.write ( "declare " + "\n""")
        fIn.write ( "pi_mut_xml clob := " + "\'" + dml_statement_new + "\'" + " ; " + "\n" )
        fIn.write ( "l_result number(15) ;" + "\n" )
        fIn.write ( "begin" + "\n" )
        fIn.write ( "l_result := sdb_object_iud_pck.setobject( pi_object_class_id => " + str(dml_obj_class_id) + "\n" )
        fIn.write ( "                                        , pi_mut_code => \'" + str(dml_iud) + "\'" + "\n" )
        fIn.write ( "                                        , pi_mut_xml => pi_mut_xml" + "\n" )
        fIn.write ( "                                        , pi_system_value => \'T\');" + "\n" )
        fIn.write ( "end;" + "\n" )
        fIn.write ( "/" + "\n" )
    else :
        dml_object_instance_id = dml_statement_new.rstrip().split("|")[0]
        dml_geom_wkt           = dml_statement_new.rstrip().split("|")[1]
        fIn.write ( "-- PLSQL block --" + "\n""")
        fIn.write ( "declare " + "\n""")
        fIn.write ( "pi_geom_xml clob := " + "\'" + dml_geom_wkt + "\'" + " ; " + "\n" )
        fIn.write ( "begin" + "\n" )
        fIn.write ( "sdb_interface_pck.setgeom( pi_object_class_id   => " + str(dml_obj_class_id) + "\n" )
        fIn.write ( "                         , pi_object_instance_id => " + str(dml_object_instance_id) + "\n" )
        fIn.write ( "                         , pi_tag_name => null" + "\n" )
        fIn.write ( "                         , pi_mut_geom => pi_geom_xml" + "\n" )
        fIn.write ( "                         , pi_epsg_code => null" + "\n" )
        fIn.write ( "                         , pi_system_value => \'T\'" + "\n" )
        fIn.write ( "                         );" + "\n" )
        fIn.write ( "end;" + "\n" )
        fIn.write ( "/" + "\n" )

def add_copyright ( fIn ) :
    now = datetime.datetime.now()
    fIn.write ("\n" )
    fIn.write ("----------------------------------------------------" + "\n" )
    fIn.write ("--" + "\n" )
    fIn.write ("-- Copyright (c) ATLIS " + str(now.year) + ". All Rights Reserved. --" + "\n" )
    fIn.write ("--" + "\n" )
    fIn.write ("----------------------------------------------------" + "\n" )
    fIn.write ("\n" )

def add_write_count ( fIn, index ) :
    "Function to add statement index to file"
    line = 'Running statement ' + str(index) + '.....'
    fIn.write("\n")
    fIn.write("------ " + str(line) + " --------" + "\n" )
    fIn.write("\n")
    fIn.write("select \'" + str(line) + "\' from dual;" + "\n" )
    fIn.write("\n")

def write_table_dml ( DbConnection, fIn, table_name, is_link_table, where_clause ) :
    "Function to write insert DML for table"
    # Init statements
    oracle_cursor = DbConnection.cursor()
    column_stmt = 'select column_name, data_type from user_tab_columns where table_name =\'' + str(table_name) + '\''
    select_stmt = 'select '
    insert_stmt = 'insert into ' + str(table_name) + '('
    log_select  = 'select \'' + str(table_name) + '\' from dual;'
    fIn.write(log_select + '\n')

    # Get columns and build insert and select statement
    columnset = oracle_cursor.execute(column_stmt)
    index = 1
    column_data_type_dict = {}
    for column in columnset :
        column_name = str(column[0])
        data_type   = str(column[1])
        insert_stmt = insert_stmt + column_name + ', '
        column_data_type_dict[index] = data_type
        index = index + 1
        if str(column_name) == str("TECH_START_DATE") :
            column_name = "sysdate"
        if str(column_name) == str("TECH_DATE_LAST_MUTATION") :
            column_name = "sysdate"
        if str(column_name) == str("TECH_SESS_LAST_MUTATION") :
            column_name = "\'sys_context(\'\'userenv\'\',\'\'sessionid\'\')\'"
        if str(data_type) == str("DATE") :
            column_name = "to_char(" + str(column_name) + ",adm_alg_pck.get_date_format)"
        if str(data_type) == str("SDO_GEOMETRY") :
            column_name = "tab." + str(column_name) + ".get_wkt()"
        select_stmt = select_stmt + str(column_name) + ', '
    insert_stmt = insert_stmt[:-2] + ')'
    select_stmt = select_stmt[:-2] + ' from ' + str(table_name) + ' tab '
    if not is_link_table :
        if SENS_VERSION == int(1) :
            logger.info("Build query to select all system ids from table")
            # Build query to select all system ids from table
            id_list_qry = 'select distinct t6.id from (  select t1.id from ' + str(table_name) + ' t1 , sdb_session t2 where t1.tech_sess_last_mutation = t2.session_id and   t2.sessionuser = \'SENS\' '
            id_list_qry = id_list_qry + ' union  select t3.id from ' + str(table_name) + '_HIST t3 , sdb_session t4 where t3.tech_sess_last_mutation = t4.session_id and t4.sessionuser = \'SENS\' '
            id_list_qry = id_list_qry + ' union  select t5.id  from '+ str(table_name) + ' t5 where t5.tech_sess_last_mutation is null '
            id_list_qry = id_list_qry + ' ) t6 '
            select_stmt = select_stmt + ' where tab.id in ( ' + str(id_list_qry) + ')'
            if where_clause :
                # Add user-defined where clause
                select_stmt = select_stmt + ' and tab.' + str(where_clause)
            else :
                # Exclude IDs inserted by USER (larger than 1000000)
                select_stmt = select_stmt  + ' and tab.id < ' + str(MIN_ID_SCHEMA_OWNER)
        if SENS_VERSION == int(2) :
            # Select SYSTEM records based on attribute IS_SYSTEM_RECORD
            select_stmt = select_stmt + " where tab.is_system_record = \'T\' "
    if is_link_table :
        if SENS_VERSION == int(1) :
            logger.info("Build query to select rows that link two system records")
            # Build query to select rows that link two system records
            tab_nr = 0
            table_stmt = 'select pk.table_name, cc.column_name from user_constraints fk, user_constraints pk, user_cons_columns cc '
            table_stmt = table_stmt + ' where fk.table_name = \'' + str(table_name) + '\' and   fk.constraint_type = \'R\' '
            table_stmt = table_stmt + ' and   fk.r_constraint_name = pk.constraint_name  and fk.constraint_name = cc.constraint_name'
            tableset = oracle_cursor.execute(table_stmt)
            for table in tableset :
                tab_nr = tab_nr + 1
                if int(tab_nr) == int(1) :
                    select_stmt = select_stmt + ' where '
                elif int(tab_nr) > int(1) :
                    select_stmt = select_stmt + ' and '
                select_stmt = select_stmt + ' exists ( select 1 from ' + str(table[0]) + '_hist t' + str(tab_nr) + ', sdb_session s where t' + str(tab_nr) + '.id = ' + str(table[1])
                select_stmt = select_stmt + ' and t' + str(tab_nr) + '.tech_sess_last_mutation = s.session_id and s.sessionuser = \'SENS\' )'
        if SENS_VERSION == int(2) :
            # Select SYSTEM records based on attribute IS_SYSTEM_RECORD
            tab_nr = 0
            table_stmt = 'select pk.table_name, cc.column_name from user_constraints fk, user_constraints pk, user_cons_columns cc '
            table_stmt = table_stmt + ' where fk.table_name = \'' + str(table_name) + '\' and   fk.constraint_type = \'R\' '
            table_stmt = table_stmt + ' and   fk.r_constraint_name = pk.constraint_name  and fk.constraint_name = cc.constraint_name'
            tableset = oracle_cursor.execute(table_stmt)
            for table in tableset :
                tab_nr = tab_nr + 1
                if int(tab_nr) == int(1) :
                    select_stmt = select_stmt + ' where '
                elif int(tab_nr) > int(1) :
                    select_stmt = select_stmt + ' and '
                select_stmt = select_stmt + ' exists ( select 1 from ' + str(table[0]) + ' t' + str(tab_nr) + ' where t' + str(tab_nr) + '.id = ' + str(table[1])
                select_stmt = select_stmt + ' and t' + str(tab_nr) + '.is_system_record = \'T\' )'

    # Get id's and build insert statements
    logger.info(select_stmt)
    valueset = oracle_cursor.execute(select_stmt)
    row_num = 0
    for value in valueset :
        row_num = row_num + 1
        nr_of_values = len(value)
        value_index = 0
        values_list = ' values ('
        while int(value_index) < int(nr_of_values) :
            logger.debug("value = " + str(value[value_index]) )
            if value[value_index] <> None  :
                data_type = column_data_type_dict[value_index+1]
                if str(data_type) == "VARCHAR2" or str(data_type) == "CLOB" :
                    value_1   = str(value[value_index])
                    value_2   = htmlentitydecode(value_1)
                    value_3   = str.replace( str(value_2),"&apos;","'")
                    value_4   = str.replace( str(value_3), "'", "''")
                    value_ins = '\'' + str(value_4) + '\''
                elif str(data_type) == "DATE" :
                    value_ins = 'to_date(' + str(value[value_index]) + ',adm_alg_pck.get_date_format)'
                elif str(data_type) == str("SDO_GEOMETRY") :
                    value_ins = 'sdo_geometry(\'' + str(value[value_index]) + '\',' + str(SRID) + ')'
                elif str(data_type) == str("BLOB") :
                    value_ins = 'NULL'
                else :
                    value_ins = str(value[value_index])
            else :
                value_ins = "NULL"
            logger.debug("value ins = " + str(value_ins) )
            values_list = values_list  + str(value_ins) + ', '
            value_index = value_index + 1
        insert_stmt_final = insert_stmt + values_list[:-2] + ');' + '\n'
        fIn.write(insert_stmt_final)

def get_xml ( DbConnection, object_class_id, object_instance_id ) :
    resultset_cursor = DbConnection.cursor()
    l_query_xml  = "<Filter><And><PropertyIsEqualTo><PropertyName>ID</PropertyName><Literal>" + str(object_instance_id) + "</Literal></PropertyIsEqualTo></And></Filter>"
    l_result_xml = resultset_cursor.callfunc("sdb_interface_pck.getObject", cx_Oracle.CLOB, [object_class_id, l_query_xml ])
    return l_result_xml

def wrap_sources_on_db ( DbConnection, output_dir, db_version ) :

    # First get the list of sources and wrap
    oracle_cursor = DbConnection.cursor()

    try :
        logger.info("Generate wrapped sources on database")
        oracle_cursor.callproc( "sdb_interface_pck.wrapPackages" )
    except Exception, err:
        logger.info ( "Generation wrapped sources failed: ERROR: %s\n" % str(err) )

    try :
        # Now read wrapped specs and bodies from table and write to file
        logger.info("Read wrapped sources from database and write to file")
        stmt = 'select type, name, wrapped_source from sdb_wrapped_source where db_version = ' + str(db_version) + ' order by name ,type '
        package_list = oracle_cursor.execute(stmt)
        for package in package_list :
            package_type   = str(package[0])
            package_name   = str(package[1])
            wrapped_source = str(package[2])
            if package_type == 'PACKAGE' :
                file_write_option = 'w'
            if package_type == 'PACKAGE BODY' :
                file_write_option = 'a'
            file_out = output_dir + '/' + str(package_name) + str(".pck.wrap")
            fOut = open ( file_out, file_write_option )
            fOut.write(wrapped_source)
            fOut.write("/" + "\n")
            fOut.write("\n")
            fOut.close()
    except Exception, err:
        logger.info ( "Writing wrapped sources to file failed: ERROR: %s\n" % str(err) )

def write_package_version_info ( DbConnection, output_dir, db_version ) :

    # First get the list of oracle cursor
    oracle_cursor_p = DbConnection.cursor()
    oracle_cursor_s = DbConnection.cursor()

    try :
        logger.info("Write version PLSQL packages to file")
        file_out = output_dir + '/plsql_versions_' + str(db_version) + '.txt'
        fOut = open ( file_out, 'w' )
        stmt = 'select name from user_source where ( name like \'SDB_%\' or name like \'NDB_%\' or name like \'QARTO_%\' or name like \'ADM_%\' ) and type = \'PACKAGE BODY\' and line = 1'
        package_list = oracle_cursor_p.execute(stmt)
        for package in package_list :
            version_stmt = 'select ' + str(package[0]) + '.get_svn_id from dual'
            version_list = oracle_cursor_s.execute(version_stmt)
            for version in version_list :
                fOut.write(str(package[0]) + ': ' + str(version[0]) + "\n" )
        fOut.close()
        oracle_cursor_p.close()
        oracle_cursor_s.close()
    except Exception, err:
        logger.info ( "Write version PLSQL packages to file: ERROR: %s\n" % str(err) )

def get_create_partitioned_table_stmt ( DbConnection, table_name, tablespace, partitioning_type ) :
    "Function to get create table statement for partitioned table"
    try:
        logger.info("Get partitioned table statement for table " + str(table_name))
        columnset_cursor    = DbConnection.cursor()
        parameterset_cursor = DbConnection.cursor()

        # Add columns for partitioned table
        create_stmt = "create table " + table_name + "\n"
        create_stmt = create_stmt + " ( " + "\n"
        column_nr = 0
        stmt = 'select t.column_name, t.data_type, t.data_length, t.nullable, t.data_precision from user_tab_columns t where t.table_name = \'' + str(table_name) + '\' order by t.column_id '
        columnset = columnset_cursor.execute(stmt)
        for column_def in columnset :
            column_nr = column_nr + 1
            if column_nr == 1 :
                column = str(column_def[0]) + " "
            else :
                column = "," + str(column_def[0]) + " "
            if str(column_def[1]) == str("SDO_GEOMETRY") or str(column_def[1]) == str("BLOB") :
                column = column + str(column_def[1])
            elif str(column_def[1]) == str("NUMBER") :
                if column_def[4] :
                    column = column + str(column_def[1]) + "(" + str(column_def[4]) +  ")"
                else :
                    column = column + str(column_def[1])
            else :
                column = column + str(column_def[1]) + "(" + str(column_def[2]) + ")"
            if str(column_def[3]) == str("N") :
                column = column + " NOT NULL "
            create_stmt = create_stmt + column + "\n"
        create_stmt = create_stmt + " ) " + "\n"

        # Now find create partition parameters and build partitioning clause
        stmt = "select partition_name, high_value, column_name  from ( "
        stmt = stmt + " select o.subobject_name partition_name, u.high_value high_value, p.column_name column_name "
        stmt = stmt + " from user_part_key_columns p, user_tab_partitions u, user_objects o "
        stmt = stmt + " where p.name = u.table_name and p.name = o.object_name and p.name = \'" + table_name + "\' and o.object_type = 'TABLE PARTITION' and u.partition_name = o.subobject_name "
        stmt = stmt + " order by length(o.subobject_name), o.subobject_name ) where rownum =1 "
        parameterset = parameterset_cursor.execute(stmt)
        for parameter in parameterset :
            partition_name   = str(parameter[0])
            partition_value  = str(parameter[1])
            partition_column = str(parameter[2])
        partitioning_clause = " partition by " + partitioning_type + " ( " + partition_column + " ) " + "\n"
        if partitioning_type == "LIST" :
            partitioning_clause = partitioning_clause + " ( partition " + partition_name + " values ( " + partition_value + " )  tablespace " + tablespace + " ) " + "\n"
        if partitioning_type == "RANGE" : 
            partitioning_clause = partitioning_clause + " ( partition " + partition_name + " values less than ( " + partition_value + " )  tablespace " + tablespace + " ) " + "\n"

        create_stmt = create_stmt + partitioning_clause 
        return create_stmt

    except Exception, err:
        logger.info ( "Get partitioned table statement failed: ERROR: %s\n" % str(err) )
        sys.exit(1)


def get_dml_for_object_class ( DbConnection, fIn, object_class_id, index ) :
    "Function to write object class defintion dml"

    # Open cursor
    oracle_cursor = DbConnection.cursor()

    # Object class definition
    add_write_count  ( fIn, index )
    parse_set_object ( fIn, OBJ_CLASS_CLASS_ID, "I", str(get_xml( DbConnection, OBJ_CLASS_CLASS_ID, object_class_id )) )
    index = index + 1

    # Attributes
    stmt    = 'select id from sdb_object_class_attr where object_class_id =' + str(object_class_id) + ' order by id desc'
    attrset = oracle_cursor.execute(stmt)
    for attr in attrset :
        attribute_id = attr[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, ATTRIBUTE_CLASS_ID, "I", str(get_xml( DbConnection, ATTRIBUTE_CLASS_ID, attribute_id )) )
        index = index + 1

    # View definitions
    stmt    = 'select distinct t2.obj_view_id from sdb_object_class_attr t1, sdb_object_attribute_view t2 '
    stmt    = stmt + ' where t1.object_class_id =' + str(object_class_id) + ' and t1.attribute_name =\'ID\' '
    stmt    = stmt + ' and   t1.id = t2.attribute_id '
    viewset = oracle_cursor.execute(stmt)
    for view in viewset :
        view_id = view[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, VIEW_CLASS_ID, "I", str(get_xml( DbConnection, VIEW_CLASS_ID, view_id )) )
        index = index + 1

    # Attribute view definitions
    stmt    = 'select t2.id from sdb_object_class_attr t1, sdb_object_attribute_view t2 '
    stmt    = stmt + ' where t1.object_class_id = ' + str(object_class_id)
    stmt    = stmt + ' and   t1.id = t2.attribute_id order by t2.obj_view_id '
    atvwset = oracle_cursor.execute(stmt)
    for atvw in atvwset :
        attr_view_id = atvw[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, ATTR_VIEW_CLASS_ID, "I", str(get_xml( DbConnection, ATTR_VIEW_CLASS_ID, attr_view_id )) )
        index = index + 1

    # Business rules
    stmt    = 'select t1.id from sdb_business_logic t1 '
    stmt    = stmt + ' where t1.trigger_object_class_id = ' + str(object_class_id)
    blset = oracle_cursor.execute(stmt)
    for bl in blset :
        bl_id = bl[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, BL_CLASS_ID, "I", str(get_xml( DbConnection, BL_CLASS_ID, bl_id )) )
        index = index + 1

    # Business rules dml
    stmt     = 'select t2.id from sdb_business_logic t1, sdb_business_logic_dml t2 '
    stmt     = stmt + ' where t1.trigger_object_class_id = ' + str(object_class_id)
    stmt     = stmt + ' and t1.id  = t2.bl_id order by t2.bl_id'
    bldmlset = oracle_cursor.execute(stmt)
    for bldml in bldmlset :
        bldml_id = bldml[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, BL_DML_CLASS_ID, "I", str(get_xml( DbConnection, BL_DML_CLASS_ID, bldml_id )) )
        index = index + 1

    # Business rules chk
    stmt     = 'select t3.id from sdb_business_logic t1, sdb_business_logic_dml t2, sdb_business_logic_chk t3 '
    stmt     = stmt + ' where t1.trigger_object_class_id = ' + str(object_class_id)
    stmt     = stmt + ' and t1.id  = t2.bl_id '
    stmt     = stmt + ' and t2.id  = t3.bl_dml_id order by t3.bl_dml_id '
    blchkset = oracle_cursor.execute(stmt)
    for blchk in blchkset :
        blchk_id = blchk[0]
        add_write_count  ( fIn, index )
        parse_set_object ( fIn, BL_CHK_CLASS_ID, "I", str(get_xml( DbConnection, BL_CHK_CLASS_ID, blchk_id )) )
        index = index + 1

    # Parameter dependecies
    stmt    = 'select t1.id from SDB_OBJECTATTRPARAM t1, sdb_object_class_attr t2 '
    stmt    = stmt + ' where t1.attributeid = t2.id and t2.object_class_id = '  + str(object_class_id)
    pmidset  = oracle_cursor.execute(stmt)
    for pmid in pmidset :
        pmid_id = pmid[0]
        parse_set_object ( fIn, ATTR_PARAM_CLASS_ID, "I", str(get_xml( DbConnection, ATTR_PARAM_CLASS_ID, pmid_id )) )
        index = index + 1
    stmt    = 'select t0.id from SDB_OBJECTPARAMDEP t0, SDB_OBJECTATTRPARAM t1, sdb_object_class_attr t2 '
    stmt    = stmt + ' where t0.parameterid = t1.id and t1.attributeid = t2.id and t2.object_class_id = '  + str(object_class_id)
    dpidset = oracle_cursor.execute(stmt)
    for dpid in dpidset :
        dpid_id = dpid[0]
        parse_set_object ( fIn, PARAM_DEP_CLASS_ID, "I", str(get_xml( DbConnection, PARAM_DEP_CLASS_ID, dpid_id )) )
        index = index + 1

def create_tablespace ( fIn, tablespace_name, nr_of_datafiles, path, extent_size, block_size) :
    "Function to build create tablespace statement"
    init_size        = "100M"
    max_file_size    = "20480M"
    stmt_create_tablespace = "CREATE TABLESPACE " + str(tablespace_name) + " DATAFILE " + "\n"
    i = 1
    while i <= int(nr_of_datafiles) :
        if int(i) < 10 :
            file_nr = "0" + str(i)
        else :
            file_nr = str(i)
        if file_nr == "01" :
            stmt_create_tablespace = stmt_create_tablespace + "\'" + str(path) + "/" + str(tablespace_name) + str(file_nr) + ".dbf\'"
        else :
            stmt_create_tablespace = stmt_create_tablespace + ", \'" + str(path) + "/" + str(tablespace_name) + str(file_nr) + ".dbf\'"
        stmt_create_tablespace = stmt_create_tablespace + " SIZE " + str(init_size) + " AUTOEXTEND ON NEXT " + str(init_size) + " MAXSIZE  " + str(max_file_size) + "\n"
        i = i + 1
    stmt_create_tablespace = stmt_create_tablespace + " LOGGING ONLINE PERMANENT EXTENT MANAGEMENT LOCAL UNIFORM SIZE " + str(extent_size) + " BLOCKSIZE " + str(block_size) + "\n"
    stmt_create_tablespace = stmt_create_tablespace +" SEGMENT SPACE MANAGEMENT AUTO FLASHBACK ON;" + "\n"
    fIn.write(stmt_create_tablespace)

def drop_user_defined_columns( DbConnection ) :
    "Function to drop user-defined columns before generation of clean install, drop columns as SENS_PORTAL user!!"
    oracle_cursor = DbConnection.cursor()
    drop_cursor   = DbConnection.cursor()
    attribute_stmt = 'select t1.id from sdb_object_class_attr t1, sdb_object_class t2 where t1.system = \'F\' and t1.object_class_id = t2.id and t2.user_managed = \'T\' and t2.user_created = \'F\''
    attributeset = oracle_cursor.execute(attribute_stmt)
    for attribute in attributeset :
        attribute_id = int(attribute[0])
        logger.info ( "Drop user-defined column "  + str(attribute_id) )
        drop_cursor.execute("""
                                begin
                                    sdb_object_iud_pck.delObjectAttrDef(:1, :2 = 1, :3 = 1);
                                end;""", [attribute_id, int(True), int(False)]
                              )
        logger.info ( "Column dropped" )

def gui_parameter_import () :
    
    # Build gui for input
    while True :

        # Build GUI with parameters
        choices = []
        msg = ""
        for parameter in PARAMETER_LIST_VALUE :
            choices.append( str(parameter) )
            msg = msg + str(parameter) + ": " + str(PARAMETER_LIST_VALUE[parameter]) + "\n"
        reply=choicebox(msg,None,choices=choices)
        logger.info ( "Reply: " + str(reply) )

        # Set gui element for parameters
        diropenparameters  = ( SVN_TRUNK_HOME, ORACLE_HOME, DEPLOY_FILE_DIR )
        booleanparameters  = ( UPGRD_INSTALL_GENERATION, CLEAN_INSTALL_GENERATION, UPDATE_DB_VERSION )
        sensoparameters    = ( DB_USER_SOURCE, DB_TNS_SOURCE, DB_PASSWORD_SOURCE )
        enterboxparameters = ( BATHY_CLIENT_VERSION  )

        # Check on gui element and open correct gui element
        if str(reply) in diropenparameters :
            title = 'Parameter selection'
            msg = 'Select ' + str(reply)
            dir = diropenbox(msg, title, str(PARAMETER_LIST_VALUE[reply]) )
            PARAMETER_LIST_VALUE[reply] = str(dir)
        elif str(reply) in booleanparameters :
            title = 'Parameter selection'
            msg = str(reply)
            return_value = boolbox(msg,title, choices=('Yes', 'No'), image=None)
            if int(return_value) == 1 :
                PARAMETER_LIST_VALUE[reply] = "T"
            else :
                PARAMETER_LIST_VALUE[reply] = "F"
        elif str(reply) in enterboxparameters :
            title = 'Parameter selection'
            msg = "Enter value for " + str(reply)
            return_value = enterbox(msg,title,PARAMETER_LIST_VALUE[reply] )
            PARAMETER_LIST_VALUE[reply] = str(return_value)
        elif str(reply) in sensoparameters :
            title = 'Parameter selection'
            msg = "Enter value for " + str(reply)
            field_names   = [ DB_TNS_SOURCE, DB_USER_SOURCE, DB_PASSWORD_SOURCE ]
            return_values = [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE[DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ]
            return_values = multpasswordbox(msg,title, field_names, return_values)
            if return_values :
                PARAMETER_LIST_VALUE [DB_TNS_SOURCE]      = return_values[0]
                PARAMETER_LIST_VALUE [DB_USER_SOURCE]     = return_values[1]
                PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE] = return_values[2]
        else :
            break

def gui_show_parameters () :

    txt = ""
    for parameter in PARAMETER_LIST_VALUE :
        txt = txt + str(parameter) + ": " + str(PARAMETER_LIST_VALUE[parameter]) + "\n"
    title = "Parameters"
    msg  = "Parameter values"
    textbox(msg, title, txt, None)

def gui_db_connection () :
    title = 'Database connection parameters'
    msg   = "Give database connection parameters development database"
    field_names   = [ DB_TNS_SOURCE, DB_USER_SOURCE, DB_PASSWORD_SOURCE ]
    return_values = [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE[DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ]
    return_values = multpasswordbox(msg,title, field_names, return_values)
    if return_values :
        PARAMETER_LIST_VALUE [DB_TNS_SOURCE]      = return_values[0]
        PARAMETER_LIST_VALUE [DB_USER_SOURCE]     = return_values[1]
        PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE] = return_values[2]

def gui_single_table_export () :
    gui_db_connection ()
    table_name = "SDB_PRIMEMERIDIAN"
    DbConnection = cx_Oracle.connect( "sens", "senso", "10.20.0.49/sens11")
    dir = diropenbox("Directory", "Give directory", "C:/temp" )
    table_file  = dir + "/" + table_name + ".sql"
    fOut = open( table_file , 'w')
    write_table_dml ( DbConnection, fOut, table_name, False, None )
    fOut.close()
    DbConnection.close()
 
def gui_client_version () :
    title = 'Client version'
    msg   = "Give new client version"
    return_value = enterbox(msg,title,PARAMETER_LIST_VALUE[ BATHY_CLIENT_VERSION ] )
    PARAMETER_LIST_VALUE[ BATHY_CLIENT_VERSION ] = str(return_value)

def gui_update_database_version () :
    title = 'Database version'
    msg   = "Update database version"
    return_value = boolbox(msg,title, choices=('Yes', 'No'), image=None)
    if int(return_value) == 1 :
        PARAMETER_LIST_VALUE[ UPDATE_DB_VERSION ] = "T"
    else :
        PARAMETER_LIST_VALUE[ UPDATE_DB_VERSION ] = "F"

def gui_svn_trunk_dir () :
    title = 'Directory selection'
    msg = 'Select directory for SVN trunk PLSQL functions '
    dir = diropenbox(msg, title, str(PARAMETER_LIST_VALUE [ SVN_TRUNK_HOME ]) )
    PARAMETER_LIST_VALUE [ SVN_TRUNK_HOME ] = str(dir)

def gui_oracle_home_dir () :
    title = 'Directory selection'
    msg = 'Select ORACLE_HOME directory '
    dir = diropenbox(msg, title, str(PARAMETER_LIST_VALUE [ ORACLE_HOME ]) )
    PARAMETER_LIST_VALUE [ ORACLE_HOME ] = str(dir)

def gui_scripts_dir () :
    title = 'Directory selection'
    msg = 'Select directory for generated upgrade scripts '
    dir = diropenbox(msg, title, str(PARAMETER_LIST_VALUE[ DEPLOY_FILE_DIR ]) )
    PARAMETER_LIST_VALUE[ DEPLOY_FILE_DIR ] = str(dir)

def gui_import () :
    
    while True :
        title = "SENS Database upgrade scripts generator"
        msg   = "What do you want?"
        #options = ["Generate DB upgrade scripts","Show parameters","Update parameters","Expert mode","Exit"]
        options = ["Generate DB upgrade scripts","Exit"]
        reply=buttonbox(msg,title,options,image='DbUpgrade.gif')

        if reply == "Show parameters" :
            logger.info("Show parameters")
            gui_show_parameters ()
        elif reply == "Single table export" :
            gui_single_table_export ()
        elif reply == "Update parameters" :
            gui_parameter_import ()
        elif reply == "Expert mode" :
            db_version_id_new, db_client_id = run ( PARAMETER_LIST_VALUE )
            message = "Database upgraded to version " + str(db_version_id_new)
            msgbox(message, ok_button="Good job!")
            message = "Generated files in " + str(PARAMETER_LIST_VALUE [ DEPLOY_FILE_DIR ] ) + "/" + str(db_client_id)
            msgbox(message, ok_button="OK")
        elif reply == "Generate DB upgrade scripts" :
            db_version_id_new, db_client_id = gui_run ( PARAMETER_LIST_VALUE )
            message = "Database upgraded to version " + str(db_version_id_new)
            msgbox(message, ok_button="Good job!")
            message = "Generated files in " + str(PARAMETER_LIST_VALUE [ DEPLOY_FILE_DIR ] ) + "/" + str(db_client_id)
            msgbox(message, ok_button="OK")
        elif reply == "Exit" :
            break

def parse_parameter_file ( parameter_file ) :
    "Function to parse parameter file"

    # Initialize parameter value list
    parameter_list = {}

    # Open file and extract parameter, value cobinations
    fIn = open(parameter_file,'r')
    for line in fIn:
        if "=" in line:
            parameter_list [  str(line.split('=')[0].strip())  ] = line.split('=')[1].strip()
    fIn.close()
    return parameter_list

def gui_run ( parameter_file_list ) :
    logger.info( "Open gui for parameters")
    gui_oracle_home_dir ()
    gui_db_connection()
    gui_svn_trunk_dir ()
    gui_client_version()
    gui_scripts_dir()
    #gui_update_database_version()
    msg   = "Do you want to continue?"
    title = "Please Confirm"
    if ccbox(msg, title):     # show a Continue/Cancel dialog
    	pass  # user chose Continue
    else:  # user chose Cancel
    	sys.exit(0)
    db_version_id_new, db_client_id = run ( parameter_file_list )
    return db_version_id_new, db_client_id

def run ( parameter_file_list ) :

    # Get current build from database
    logger.info ("Generate script for SENS version " + str(SENS_VERSION) )
    logger.info( "Get version for database " + parameter_file_list[ "DB_TNS_SOURCE" ] )
    DbConnection = cx_Oracle.connect( parameter_file_list[ "DB_USER_SOURCE" ], parameter_file_list[ "DB_PASSWORD_SOURCE" ], parameter_file_list[ "DB_TNS_SOURCE" ])
    DbCursor = DbConnection.cursor()
    db_version_id = DbCursor.callfunc("sdb_interface_pck.getDbVersionId", cx_Oracle.STRING )
    db_client_id  = DbCursor.callfunc("sdb_interface_pck.getDbClientVersion", cx_Oracle.STRING )
    client_id_new = str(parameter_file_list [ BATHY_CLIENT_VERSION ])
    logger.info ( "Version ID database = " + str(db_version_id) )
    logger.info ( "Client ID database  = " + str(db_client_id)  )
    logger.info ( "New Client ID       = " + str(client_id_new) )

    # Make deploy directory
    DeployFileDir = parameter_file_list [ "DEPLOY_FILE_DIR" ]
    if not os.path.isdir( DeployFileDir ) :
        os.mkdir( DeployFileDir )
        #os.chmod( DeployFileDir, stat.S_IWUSR)
    DeployFileDir = DeployFileDir + "/" + db_client_id
    if os.path.isdir( DeployFileDir ) :
        shutil.rmtree( DeployFileDir )
    os.mkdir( DeployFileDir )
#    os.chmod( DeployFileDir, stat.S_IWUSR)

    ###################################
    #      Write version file         #
    ###################################

    # Write current build number to file (encripted)
    logger.info ( "Write version database to file" )
    DbVersionNew = parameter_file_list [ "BATHY_CLIENT_VERSION" ]
    buildnr_file  = DeployFileDir + "/" + VERSION_FILE + ".txt"
    fOpen = open( buildnr_file , 'w')
    fOpen.write( "Current client ID database  : " + str(db_client_id)  + "\n" )
    fOpen.write( "Current version ID database : " + str(db_version_id) + "\n" )
    fOpen.write( "Next client ID database     : " + str(DbVersionNew)  + "\n" )
    fOpen.close()

    ###########################################
    #      Generate scripts for object_class  #
    ###########################################

    if int(parameter_file_list [ "OBJECT_CLASS_ID" ]) > int(0) :

        # Open Oracle cursor
        resultset_cursor = DbConnection.cursor()
        index = 1

        # Drop user-defined columns
        logger.info ( "Drop user-defined columns" )
        drop_user_defined_columns( DbConnection )

        ###################################
        #      Generate DDL script        #
        ###################################

        object_class_id = int(parameter_file_list [ "OBJECT_CLASS_ID" ])

        logger.info ( "Generate script for object class " + str(object_class_id) )

        # Define DDL file
        file_name = DeployFileDir + "/"  + "object_class_id_" + str(object_class_id) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + "object_class_id_" + str(object_class_id) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- Statements for object class ID  " + str(object_class_id) + "\n" )
        fExp.write( "\n" )

        # Add DDL statements
        logger.info ( "Add DDL statements" )
        resultset = resultset_cursor.callfunc("sdb_interface_pck.getDDLForObjectClass", cx_Oracle.CURSOR , [object_class_id])
        for row in resultset :
            add_write_count ( fExp, index )
            ddl_statement = str(row[0])
            fExp.write( ddl_statement + ";" + "\n")
            fExp.write( "\n")
            index = index + 1

        # Add DML statements
        logger.info ( "Add DML statements" )
        get_dml_for_object_class ( DbConnection, fExp, object_class_id, index )

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()


    ###################################
    #      Generate upgrade scripts   #
    ###################################

    if parameter_file_list [ "UPGRD_INSTALL_GENERATION" ] == "T" :

        # Open Oracle cursor
        resultset_cursor = DbConnection.cursor()
        index = 1

        # Drop user-defined columns
        logger.info ( "Drop user-defined columns" )
        drop_user_defined_columns( DbConnection )

        ###################################
        #      Generate DDL script        #
        ###################################

        logger.info ( "Generate DDL scripts for DB upgrade" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + "ddl_script.sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + "ddl_script.log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for new objects from metadata structure for DB version " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add DDL statements generated by metadata structure to file
        resultset = resultset_cursor.callfunc("sdb_interface_pck.getDeployDDL", cx_Oracle.CURSOR , [db_version_id])
        for row in resultset :
            add_write_count ( fExp, index )
            ddl_statement = str(row[0])
            fExp.write( ddl_statement + ";" + "\n")
            fExp.write( "\n")
            index = index + 1

        # Now extract DDL for objects not create through metadata structure
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for new objects NOT from metadata structure for DB version " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add DDL statements not generated by metadata structure to file
        resultset = resultset_cursor.callfunc("sdb_interface_pck.getNewDDL", cx_Oracle.CURSOR )
        for row in resultset :
            add_write_count ( fExp, index )
            ddl_statement = str(row[0]).strip()
            fExp.write( ddl_statement + ";" + "\n")
            if "CREATE OR REPLACE TYPE" in ddl_statement :
                fExp.write( "/" + "\n")
            fExp.write( "\n")
            index = index + 1

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ###################################
        #      Update DB version          #
        ###################################

        logger.info ( "Upgrade DB version" )

        # Now update DB version ID so that it will be included in DML script
        if parameter_file_list[ "UPDATE_DB_VERSION" ] == "T" :
            DbCursor = DbConnection.cursor()
            DbCursor.callproc("sdb_interface_pck.setDbClientVersion", [DbVersionNew] )
            #DbConnection.commit()

        # Get new DB version and append to version file
        stmt   = 'select max(id) from sdb_componentbuilds b where b.name = \'Database\''
        rowset = DbCursor.execute(stmt)
        for row in rowset :
            db_version_id_new = row[0]
        fOpen = open( buildnr_file , 'a')
        fOpen.write( "Next version ID database    : " + str(db_version_id_new) + "\n" )
        fOpen.close()

        ###################################
        #      Generate DML script        #
        ###################################

        logger.info ( "Generate DML scripts for DB upgrade" )

        # Define DML file
        file_name = DeployFileDir + "/"  + "dml_script.sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + "dml_script.log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DML statements for DB version " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add DML statements to file
        resultset = resultset_cursor.callfunc("sdb_interface_pck.getDeployDML", cx_Oracle.CURSOR , [db_version_id])
        for row in resultset :
            if row[0] :
                add_write_count ( fExp, index )
                dml_obj_class_id = str(row[0])
                dml_iud          = str(row[1])
                dml_statement    = str(row[2])
                logger.info("DML " + str(dml_iud) +  " for oject class " + str(dml_obj_class_id) )
                parse_set_object ( fExp, dml_obj_class_id, dml_iud, dml_statement )
                index = index + 1
            else :
                logger.info("SQL statement")
                add_write_count ( fExp, index )
                dml_statement    = str(row[2])
                fExp.write( dml_statement + ";" + "\n" )
                index = index + 1

        # Execute the data migration from previous version to current version
        add_write_count ( fExp, index )
        fExp.write( "\n" )
        fExp.write( "-- Execute the data migration from previous version to current version" + "\n" )
        fExp.write("\n")
        line = "Execute the data migration from previous version to current version"
        fExp.write("select \'" + str(line) + "\' from dual;" + "\n" )
        fExp.write("\n")
        fExp.write( "declare" + "\n")
        fExp.write( "begin" + "\n")
        fExp.write( "adm_util_pck.upgrade_data_migration;" + "\n")
        fExp.write( "end;" + "\n")
        fExp.write( "/" + "\n")
        index = index + 1

        # Recreate history views
        add_write_count ( fExp, index )
        fExp.write( "\n" )
        fExp.write( "-- Recreate history views" + "\n" )
        fExp.write("\n")
        line = "Recreate history views"
        fExp.write("select \'" + str(line) + "\' from dual;" + "\n" )
        fExp.write("\n")
        fExp.write( "declare" + "\n")
        fExp.write( "begin" + "\n")
        fExp.write( "sdb_interface_pck.recreate_history_views;" + "\n")
        fExp.write( "end;" + "\n")
        fExp.write( "/" + "\n")
        index = index + 1

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

    ###################################
    #  Generate clean install scripts #
    ###################################

    if parameter_file_list [ "CLEAN_INSTALL_GENERATION" ] == "T" :

        # Open Oracle cursor
        resultset_cursor = DbConnection.cursor()
        index = 1

        # Drop user-defined columns
        logger.info ( "Drop user-defined columns" )
        drop_user_defined_columns( DbConnection )

        ##############################################################
        #      Statements to run as SYS                              #
        ##############################################################

        logger.info ( "Generate script to grant SYS privileges" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_SYS_GRANTS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_SYS_GRANTS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for grants " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        stmt = 'select privilege, table_name from user_tab_privs  where owner in (\'SYS\') and privilege = \'EXECUTE\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
                add_write_count ( fExp, index )
                fExp.write( "grant " + str(row[0]) + " on " + str(row[1]) + " to SENS;" + "\n")
                index = index + 1

        # Close file
        fExp.write( "\n" )
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Statements to run as MDSYS                              #
        ##############################################################

        logger.info ( "Generate script to grant MDSYS privileges" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_MDSYS_GRANTS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_MDSYS_GRANTS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for grants " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        stmt = 'select privilege, table_name from user_tab_privs  where owner in (\'MDSYS\') and privilege = \'EXECUTE\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
                add_write_count ( fExp, index )
                fExp.write( "grant " + str(row[0]) + " on " + str(row[1]) + " to SENS;" + "\n")
                index = index + 1

        # Close file
        fExp.write( "\n" )
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Generate script to create SENS tablespaces            #
        ##############################################################

        logger.info ( "Generate script to create SENS tablespaces" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_CREATE_TABLESPACES) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_CREATE_TABLESPACES) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for tablespaces " + str(db_version_id) + "\n" )
        fExp.write( "\n" )
        fExp.write( "alter system set deferred_segment_creation = FALSE;")
        fExp.write( "\n" )

        # Add tablespace to file
        DataDirTarget = parameter_file_list[ "TABLESPACE_PATH_TARGET" ]
        stmt = "select tablespace_name, initial_extent, block_size from user_tablespaces where tablespace_name like \'TS_SENS_%\' and status = \'ONLINE\' "
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            create_tablespace ( fExp, str(row[0]), 1, DataDirTarget, str(row[1]), str(row[2]) )
            index = index + 1

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Generate script to create SENS users and roles        #
        ##############################################################

        logger.info ( "Generate script to create SENS users and roles" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_CREATE_USERS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_CREATE_USERS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for users and roles " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Create user SENS
        add_write_count ( fExp, index )
        fExp.write( "alter profile default limit failed_login_attempts unlimited password_life_time unlimited;" + "\n" )
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write( "create user SENS identified by " + parameter_file_list[ "DB_PASSWORD_SOURCE" ] + " default tablespace TS_SENS_DM temporary tablespace TEMP profile DEFAULT;" + "\n" )
        index = index + 1

        # Add SENS privileges
        stmt = 'select privilege, admin_option from user_sys_privs'
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            if str(row[1]) == "YES" :
                fExp.write( "grant " + str(row[0]) + " to SENS with admin option;" + "\n")
            else :
                fExp.write( "grant " + str(row[0]) + " to SENS;" + "\n")
            index = index + 1

        # Create role SENS
        add_write_count ( fExp, index )
        fExp.write( "create role SENS_ROLE;" + "\n" )
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write( "grant create session to sens_role;" + "\n" )
        index = index + 1

        # Create user  and SENS_PRODUCTCONTROLLER
        add_write_count ( fExp, index )
        fExp.write("create user SENS_PORTAL identified by SENS_PORTAL default tablespace USERS temporary tablespace TEMP profile DEFAULT;" + "\n")
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write("grant sens_role to SENS_PORTAL;" + "\n")
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write("create user SENS_PRODUCTCONTROLLER identified by SENS_PRODUCTCONTROLLER	default tablespace USERS temporary tablespace TEMP profile DEFAULT;" + "\n")
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write("grant sens_role to SENS_PRODUCTCONTROLLER;" + "\n")
        index = index + 1

        # Add privileges to SENS_PRODUCTCONTROLLER
        stmt = 'select privilege, admin_option from dba_sys_privs where grantee = \'SENS_PRODUCTCONTROLLER\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            if str(row[1]) == "YES" :
                fExp.write( "grant " + str(row[0]) + " to SENS_PRODUCTCONTROLLER with admin option;" + "\n")
            else :
                fExp.write( "grant " + str(row[0]) + " to SENS_PRODUCTCONTROLLER;" + "\n")
            index = index + 1

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Generate script to with SENS grants only              #
        ##############################################################

        logger.info ( "Generate script to grants to SENS users and roles" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_SENS_GRANTS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_SENS_GRANTS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for grants to SENS users and roles " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add SENS privileges
        stmt = 'select privilege, admin_option from user_sys_privs'
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            if str(row[1]) == "YES" :
                fExp.write( "grant " + str(row[0]) + " to SENS with admin option;" + "\n")
            else :
                fExp.write( "grant " + str(row[0]) + " to SENS;" + "\n")
            index = index + 1

        # Grant create session to SENS role
        add_write_count ( fExp, index )
        fExp.write( "grant create session to sens_role;" + "\n" )
        index = index + 1

        # Grant SENS role to SENS_PRODUCTCONTROLLER and SENS_PORTAL
        add_write_count ( fExp, index )
        fExp.write("grant sens_role to SENS_PORTAL;" + "\n")
        index = index + 1
        add_write_count ( fExp, index )
        fExp.write("grant sens_role to SENS_PRODUCTCONTROLLER;" + "\n")
        index = index + 1

        # Add privileges to SENS_PRODUCTCONTROLLER
        stmt = 'select privilege, admin_option from dba_sys_privs where grantee = \'SENS_PRODUCTCONTROLLER\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            if str(row[1]) == "YES" :
                fExp.write( "grant " + str(row[0]) + " to SENS_PRODUCTCONTROLLER with admin option;" + "\n")
            else :
                fExp.write( "grant " + str(row[0]) + " to SENS_PRODUCTCONTROLLER;" + "\n")
            index = index + 1

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ###################################
        #      Generate DDL script        #
        ###################################

        logger.info ( "Generate DDL scripts for clean install DB" )

        # Define DDL file
        file_name     = DeployFileDir + "/"  + str(SC_DDL_STATEMENTS) + ".sql"
        file_name_fks = DeployFileDir + "/"  + str(SC_CREATE_FKS)     + ".sql"
        file_name_vws = DeployFileDir + "/"  + str(SC_CREATE_VIEWS)   + ".sql"
        file_name_tpe = DeployFileDir + "/"  + str(SC_CREATE_TYPES)   + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fFks  = open(file_name_fks,'w')
        add_copyright ( fFks )
        fVws = open(file_name_vws,'w')
        add_copyright ( fVws )
        fTpe  = open(file_name_tpe,'w')
        add_copyright ( fTpe )
        fExp.write("spool " + str(SC_DDL_STATEMENTS) +  ".log" + "\n" )
        fFks.write("spool " + str(SC_CREATE_FKS)     +  ".log" + "\n" )
        fVws.write("spool " + str(SC_CREATE_VIEWS)   +  ".log" + "\n" )
        fTpe.write("spool " + str(SC_CREATE_TYPES)   +  ".log" + "\n" )
        fExp.write( "\n" )
        fFks.write( "\n" )
        fVws.write( "\n" )
        fTpe.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fFks.write("set heading off" + "\n" )
        fFks.write( "\n" )
        fVws.write("set heading off" + "\n" )
        fVws.write( "\n" )
        fTpe.write("set heading off" + "\n" )
        fTpe.write( "\n" )
        fExp.write( "-- DDL statements for new objects for DB version " + str(db_version_id) + "\n" )
        fFks.write( "-- DDL statements for foreign keys for DB version " + str(db_version_id) + "\n" )
        fVws.write( "-- DDL statements for views for DB version " + str(db_version_id) + "\n" )
        fTpe.write( "-- DDL statements for types keys for DB version " + str(db_version_id) + "\n" )
        fExp.write( "\n" )
        fFks.write( "\n" )
        fVws.write( "\n" )
        fTpe.write( "\n" )

        # Add DDL statements generated by metadata structure to file
        nr_of_objects = 0
        resultset = resultset_cursor.callfunc("sdb_interface_pck.getCleanInstallDDL", cx_Oracle.CURSOR )
        for row in resultset :
            add_write_count ( fExp, index )
            nr_of_objects = nr_of_objects + 1
            ddl_statement = str(row[0])
            if "FOREIGN KEY" in ddl_statement :
                fFks.write( ddl_statement  + "\n")
                fFks.write( "\n")
            elif "CREATE OR REPLACE FORCE VIEW" in ddl_statement :
                fVws.write( ddl_statement  + "\n")
                fVws.write( "\n")
            elif "CREATE OR REPLACE TYPE" in ddl_statement :
                fTpe.write( ddl_statement  + "\n")
                fTpe.write( "\n")
            else :
                fExp.write( ddl_statement  + "\n")
                fExp.write( "\n")
            index = index + 1

        ###################################
        # Partitioned tables
        ###################################

        # Init two cursors
        tableset_cursor    = DbConnection.cursor()
        indexset_cursor    = DbConnection.cursor()

        # Get list of partitioned tables
        logger.info("Partitioned tables")
        stmt = 'select table_name, def_tablespace_name, partitioning_type from user_part_tables where table_name like \'SDB_%\' '
        tableset = tableset_cursor.execute(stmt)
        for row in tableset :
            ddl_statement = get_create_partitioned_table_stmt ( DbConnection, str(row[0]), str(row[1]), str(row[2]) )
            nr_of_objects = nr_of_objects + 1
            add_write_count ( fExp, index )
            fExp.write( ddl_statement + ";" + "\n")
            index = index + 1
            
            # Get list of local indexes on partitioned tables
            logger.info("Partitioned indexes for " + str(row[0]) )
            stmt = "select \'create index \'||i.index_name||\' on \'||t.table_name||\'(\'||c.column_name||\') local tablespace \'||i.def_tablespace_name "
            stmt = stmt + " from   user_part_tables t, user_part_indexes i, user_part_key_columns k, user_ind_columns c  "
            stmt = stmt + " where i.table_name = t.table_name and   i.index_name = k.name and  i.def_tablespace_name is not null and c.index_name = i.index_name "
            stmt = stmt + " and   i.table_name = \'" + str(row[0]) + "\' "
            indexset = indexset_cursor.execute(stmt)
            for partitioned_index in indexset :
                ddl_statement = str(partitioned_index[0])
                nr_of_objects = nr_of_objects + 1
                add_write_count ( fExp, index )
                fExp.write( ddl_statement + ";" + "\n")
                index = index + 1

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )
        fFks.write( "\n" )
        fFks.write( "-- Commit and exit" + "\n" )
        fFks.write( "\n" )
        fFks.write( "commit;" + "\n" )
        fFks.write( "\n" )
        fVws.write( "\n" )
        fVws.write( "-- Commit and exit" + "\n" )
        fVws.write( "\n" )
        fVws.write( "commit;" + "\n" )
        fVws.write( "\n" )
        fTpe.write( "\n" )
        fTpe.write( "-- Commit and exit" + "\n" )
        fTpe.write( "\n" )
        fTpe.write( "commit;" + "\n" )
        fTpe.write( "\n" )

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()
        fFks.write( "spool off" + "\n" )
        fFks.write( "\n" )
        fFks.write( "exit;" + "\n" )
        fFks.close()
        fVws.write( "spool off" + "\n" )
        fVws.write( "\n" )
        fVws.write( "exit;" + "\n" )
        fVws.close()
        fTpe.write( "spool off" + "\n" )
        fTpe.write( "\n" )
        fTpe.write( "exit;" + "\n" )
        fTpe.close()

        logger.info ( str(nr_of_objects) + " objects generated " )

        ############################################
        #      Generate spatial indexes script     #
        ############################################

        logger.info ( "Generate spatial indexes script" )

        # Define and open files
        file_name_dis = DeployFileDir + "/"  + str(SC_CREATE_SPATIAL_INDEX) + ".sql"
        fExp = open(file_name_dis,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_CREATE_SPATIAL_INDEX) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- Create spatial index " + "\n" )
        fExp.write( "\n" )

        # Get spatial indexes and metadata
        stmt = 'select t.index_name, t.table_name, t.column_name from user_sdo_index_info t where t.table_name <> \'SDB_HOOGTE_DIEPTE\' and table_name not like \'SDB_IMP_IM_%\' '
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            insert_metadata = "Insert into user_sdo_geom_metadata (TABLE_NAME,COLUMN_NAME,DIMINFO,SRID)" +  " values " + "(\'" + str(row[1]) + "\',\'" + str(row[2]) + "\',MDSYS.SDO_DIM_ARRAY(MDSYS.SDO_DIM_ELEMENT(\'X\',-180,180,0.05),MDSYS.SDO_DIM_ELEMENT(\'Y\',-90,90,0.05)),8307); "
            fExp.write( insert_metadata + "\n"  )
            index = index + 1
            add_write_count ( fExp, index )
            fExp.write( "create index " + str(row[0]) + " on " + str(row[1]) + "(" + str(row[2]) + ")" + " INDEXTYPE IS MDSYS.SPATIAL_INDEX PARAMETERS ( \'TABLESPACE=TS_SENS_SPATIAL_IM\'); " + "\n" )
            index = index + 1

        # Get spatial indexes for SDB_HOOGTE-DIEPTE table (spatial partitioned index)
        stmt = 'select t.index_name, t.table_name, t.column_name from user_sdo_index_info t where t.table_name = \'SDB_HOOGTE_DIEPTE\' and rownum =1'
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            insert_metadata = "Insert into user_sdo_geom_metadata (TABLE_NAME,COLUMN_NAME,DIMINFO,SRID)" +  " values " + "(\'" + str(row[1]) + "\',\'" + str(row[2]) + "\',MDSYS.SDO_DIM_ARRAY(MDSYS.SDO_DIM_ELEMENT(\'X\',-180,180,0.05),MDSYS.SDO_DIM_ELEMENT(\'Y\',-90,90,0.05)),8307); "
            fExp.write( insert_metadata + "\n"  )
            index = index + 1
            add_write_count ( fExp, index )
            fExp.write( "create index " + str(row[0]) + " on " + str(row[1]) + "(" + str(row[2]) + ")" + " INDEXTYPE IS MDSYS.SPATIAL_INDEX LOCAL PARAMETERS (\'SDO_COMMIT_INTERVAL=1000 LAYER_GTYPE=POINT TABLESPACE=TS_SENS_SPATIAL_IM\'); " + "\n" )
            index = index + 1

        # Get spatial imetadata for views
        stmt = 'select t.table_name, t.column_name from user_sdo_geom_metadata t where t.table_name like \'SDB_V_%\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            insert_metadata = "Insert into user_sdo_geom_metadata (TABLE_NAME,COLUMN_NAME,DIMINFO,SRID)" +  " values " + "(\'" + str(row[0]) + "\',\'" + str(row[1]) + "\',MDSYS.SDO_DIM_ARRAY(MDSYS.SDO_DIM_ELEMENT(\'X\',-180,180,0.05),MDSYS.SDO_DIM_ELEMENT(\'Y\',-90,90,0.05)),8307); "
            fExp.write( insert_metadata + "\n"  )
            index = index + 1

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )

        # Close files
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ###################################
        #      Generate DML script        #
        ###################################

        logger.info ( "Generate DML scripts for clean install DB" )

        # Define DML file
        file_name = DeployFileDir + "/"  + str(SC_DML_STATEMENTS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_DML_STATEMENTS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DML statements for DB version " + str(db_version_id) + "\n" )
        fExp.write( "\n" )
        store_session_stmt = "Insert Into sdb_session(session_id, osuser, sessionuser, host, client, time_stamp) Values("
        store_session_stmt = store_session_stmt + "sys_context(\'userenv\',\'sessionid\'),sys_context(\'userenv\',\'os_user\'),sys_context(\'userenv\',\'session_user\'),sys_context(\'userenv\',\'host\'),sys_context(\'userenv\',\'terminal\'),Sysdate);"
        fExp.write( store_session_stmt + "\n" )

        # Get system tables
        link_table = False
        stmt = 'select object_class_table from sdb_object_class where system_data = \'T\' and object_class_table in ( select table_name from user_tables )'
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            system_table = row[0]
            logger.info ( "Processing table " + str(system_table) )
            write_table_dml ( DbConnection, fExp, system_table, link_table, False )
            index = index + 1

        # Get data from link tables between system tables
        link_table = True
        stmt = 'select fk.table_name from user_constraints fk, user_constraints pk, sdb_object_class oc '
        stmt = stmt + ' where fk.table_name like \'%LINK\' and fk.constraint_type = \'R\' and fk.r_constraint_name = pk.constraint_name '
        stmt = stmt + ' and pk.table_name = oc.object_class_table and oc.system_data = \'T\' group by fk.table_name having count(1) = 2'
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            system_table = row[0]
            logger.info ( "Processing table " + str(system_table) )
            write_table_dml ( DbConnection, fExp, system_table, link_table, False )
            index = index + 1

        if SENS_VERSION == int(1) :
            # Now handle the user-defined records that are not selected as part of the generic structure
            write_table_dml ( DbConnection, fExp, "SDB_SEPARATIONMODEL"     , False, "SYS005 = \'T\'" )
            write_table_dml ( DbConnection, fExp, "SDB_SEPARATIONMODEL"     , False, "ID = 70554" )
            write_table_dml ( DbConnection, fExp, "SDB_SEPARATIONMODELFILE" , False, "SYS014 IS NOT NULL" )

            # Attribute groups inserted as non system group that are system groups
            write_table_dml ( DbConnection, fExp, "SDB_ATTRIBUTEGROUP"      , False, "ID = 1022836" )
            write_table_dml ( DbConnection, fExp, "SDB_ATTRIBUTEGROUP"      , False, "ID = 1022835" )
            write_table_dml ( DbConnection, fExp, "SDB_ATTRIBUTEGROUP"      , False, "ID = 1021610" )

            # Import file types inserted as non system file types that are system file types
            write_table_dml ( DbConnection, fExp, "SDB_IMPORTFILETYPES"     , False, "ID = 500070439" )
            write_table_dml ( DbConnection, fExp, "SDB_IMPORTFILETYPES"     , False, "ID = 500070441" )
            write_table_dml ( DbConnection, fExp, "SDB_IMPORTFILETYPES"     , False, "ID = 500070440" )
            write_table_dml ( DbConnection, fExp, "SDB_IMPORTFILETYPES"     , False, "ID = 500070442" )

            # User group inserted as non system user groups that are user groups
            write_table_dml ( DbConnection, fExp, "SDB_GROUP"     , False, "ID = 500176345" )

        # Commit and exit
        fExp.write( "\n" )
        fExp.write( "-- Commit and exit" + "\n" )
        fExp.write( "\n" )
        fExp.write( "commit;" + "\n" )
        fExp.write( "\n" )

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Generate script to grant privileges to SENS role      #
        ##############################################################

        logger.info ( "Generate script to grant privileges to SENS role" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_ROLE_GRANTS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_ROLE_GRANTS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements for grants to SENS_ROLE " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add grants to role
        stmt = 'select t1.privilege, t1.table_name from user_tab_privs t1, sdb_object_class t2 where t1.grantee = \'SENS_ROLE\' and t1.owner = \'SENS\' and t1.table_name = t2.object_class_table and t2.user_created =\'F\' and t2.disabled is not null'
        stmt = stmt + ' and substr(t1.table_name,1,7) <> \'SDB_VH_\''
        stmt = stmt + ' union '
        stmt = stmt + ' select t3.privilege, t3.table_name from user_tab_privs t3 where t3.grantee = \'SENS_ROLE\' and t3.owner = \'SENS\''
        stmt = stmt + ' and ( t3.table_name like \'SDB_%\' or t3.table_name like \'NDB_%\' or t3.table_name like \'ADM_%\' )' 
        stmt = stmt + ' and t3.table_name not in ( select c.object_class_table from sdb_object_class      c where c.user_created = \'T\' )'
        stmt = stmt + ' and t3.table_name not in ( select c.object_class_table from sdb_object_class_hist c where c.user_created = \'T\' )'
        stmt = stmt + ' and substr(t3.table_name,length(t3.table_name)-3,length(t3.table_name)) <> \'HIST\' '
        stmt = stmt + ' and substr(t3.table_name,1,7)  <> \'SDB_VH_\''
        stmt = stmt + ' and substr(t3.table_name,1,11) <> \'SDB_IMP_IM_\''
        stmt = stmt + ' and substr(t3.table_name,1,7)  <> \'SDB_SP_\''
        stmt = stmt + ' and substr(t3.table_name,1,7)  <> \'SDB_PS_\''
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            fExp.write( "grant " + str(row[0]) + " on \"" + str(row[1]) + "\" to sens_role;" + "\n")
            index = index + 1

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #      Generate script to create public synonyms             #
        ##############################################################

        logger.info ( "Generate script to create public synonyms" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_CREATE_SYNONYMS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_CREATE_SYNONYMS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements to create public synonyms " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Add grants to role
        stmt = 'select synonym_name from all_synonyms where table_owner = \'SENS\' and owner = \'PUBLIC\' '
        stmt = stmt + ' and ( table_name like \'SDB_%\' or table_name like \'NDB_%\' or table_name like \'ADM_%\' )' 
        stmt = stmt + ' and table_name not in ( select c.object_class_table from sdb_object_class c where c.user_created = \'T\' )'
        stmt = stmt + ' and substr(table_name,length(table_name)-3,length(table_name)) <> \'HIST\' '
        stmt = stmt + ' and table_name not like \'SDB_VH_%\' '
        stmt = stmt + ' and table_name not like \'SDB_SP_%\' '
        stmt = stmt + ' and table_name not like \'SDB_PS_%\' '
        resultset = resultset_cursor.execute(stmt)
        for row in resultset :
            add_write_count ( fExp, index )
            fExp.write( "create or replace public synonym " + str(row[0]) + " for " + str(row[0]) + ";" + "\n")
            index = index + 1

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

        ##############################################################
        #  Generate script to create default users                   #
        ##############################################################

        logger.info ( "Generate script to create default users" )

        # Define DDL file
        file_name = DeployFileDir + "/"  + str(SC_CREATE_DEFAULT_USERS) + ".sql"
        fExp = open(file_name,'w')
        add_copyright ( fExp )
        fExp.write("spool " + str(SC_CREATE_DEFAULT_USERS) + ".log" + "\n" )
        fExp.write( "\n" )
        fExp.write("set heading off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "-- DDL statements to default users " + str(db_version_id) + "\n" )
        fExp.write( "\n" )

        # Write PLSQL procedure to file
        fExp.write( "\n" )
        fExp.write( "-- Create default users" + "\n" )
        fExp.write( "\n" )
        add_write_count ( fExp, index )
        fExp.write( "declare" + "\n")
        fExp.write( "begin" + "\n")
        fExp.write( "adm_util_pck.create_default_users;" + "\n")
        fExp.write( "end;" + "\n")
        fExp.write( "/" + "\n")
        index = index + 1

        # Recreate history views
        fExp.write( "\n" )
        fExp.write( "-- Recreate history views" + "\n" )
        fExp.write( "\n" )
        add_write_count ( fExp, index )
        fExp.write( "declare" + "\n")
        fExp.write( "begin" + "\n")
        fExp.write( "sdb_interface_pck.recreate_history_views;" + "\n")
        fExp.write( "end;" + "\n")
        fExp.write( "/" + "\n")
        index = index + 1

        # Now create FK to history view
        stmt = 'ALTER TABLE "SENS"."SDB_OBJECT_CLASS" ADD CONSTRAINT "TAB046_TAB046_FK4" FOREIGN KEY ("HISTOBJCLASSID")'
        stmt = stmt + ' REFERENCES "SENS"."SDB_OBJECT_CLASS" ("ID") ENABLE;'
        fExp.write( "\n" )
        fExp.write( "-- Create FK to history view" + "\n" )
        fExp.write( "\n" )
        add_write_count ( fExp, index )
        fExp.write ( stmt + "\n"  )
        fExp.write( "\n")

        # Close file
        fExp.write( "spool off" + "\n" )
        fExp.write( "\n" )
        fExp.write( "exit;" + "\n" )
        fExp.close()

    ###################################
    #      Wrap PSQL sources          #
    ###################################

    # Wrap sources

    logger.info ( "Generate script to install PLSQL packages" )
    logger.info ( "Wrap sources" )

    # Open file
    file_name = DeployFileDir + "/"  + str(SC_CREATE_PACKAGES) + ".sql"
    fExp = open(file_name,'w')
    add_copyright ( fExp )
    fExp.write("spool " + str(SC_CREATE_PACKAGES) + ".log" + "\n" )
    fExp.write( "\n" )
    fExp.write("set heading off" + "\n" )
    fExp.write( "\n" )
    fExp.write( "-- PLSQL packages for DB version " + str(db_version_id) + "\n" )
    fExp.write( "\n" )

    # First install new ADM packages to run upgrade DDL function
    resultset_cursor = DbConnection.cursor()
    resultset = resultset_cursor.callfunc("sdb_interface_pck.getPackages", cx_Oracle.CURSOR)
    for row in resultset :
        package = str(row[0])
        if "ADM_" in package :
            file     = package + ".pck"
            fExp.write( "@" + str(file) + ".wrap" + "\n" )
            index = index + 1

    # Execute the data definition upgrade from previous version to current version
    if SENS_VERSION == int(2) :
        #fExp.write( "\n" )
        #fExp.write( "-- Execute the data definition upgrade from previous version to current version" + "\n" )
        #fExp.write( "\n" )
        #add_write_count ( fExp, index )
        #fExp.write("\n")
        #line = "Execute the data definition upgrade from previous version to current version"
        #fExp.write("select \'" + str(line) + "\' from dual;" + "\n" )
        #fExp.write("\n")
        #fExp.write( "declare" + "\n")
        #fExp.write( "begin" + "\n")
        #fExp.write( "adm_util_pck.upgrade_data_definition;" + "\n")
        #fExp.write( "end;" + "\n")
        #fExp.write( "/" + "\n")
        #index = index + 1

        # Add plsql procedure to recomplie SENS schema
        fExp.write( "\n" )
        add_write_count ( fExp, index )
        fExp.write( "\n" )
        fExp.write( "select \'Compile schema SENS\' from dual ;")
        fExp.write( "\n" )
        fExp.write( "begin" + "\n" )
        fExp.write( "DBMS_UTILITY.compile_schema(schema => \'SENS\');" + "\n" )
        fExp.write( "end;" + "\n" )
        fExp.write( "/" + "\n" )
        fExp.write( "\n" )
        index = index + 1

        # Add plsql procedure to reset SENS packages
        fExp.write( "\n" )
        add_write_count ( fExp, index )
        fExp.write( "\n" )
        fExp.write( "select \'Reset SENS packages\' from dual ;")
        fExp.write( "\n" )
        fExp.write( "begin" + "\n" )
        fExp.write( "DBMS_SESSION.RESET_PACKAGE;" + "\n" )
        fExp.write( "end;" + "\n" )
        fExp.write( "/" + "\n" )
        fExp.write( "\n" )
        index = index + 1

    # Finally install other packages to run upgrade DDL function
    resultset_cursor = DbConnection.cursor()
    resultset = resultset_cursor.callfunc("sdb_interface_pck.getPackages", cx_Oracle.CURSOR)
    for row in resultset :
        package = str(row[0])
        if "ADM_" not in package :
            file     = package + ".pck"
            fExp.write( "@" + str(file) + ".wrap" + "\n" )
            index = index + 1

    # Wrap packages on database
    wrap_sources_on_db ( DbConnection, DeployFileDir, db_version_id )

    # Add plsql procedure to recomplie SENS schema
    fExp.write( "\n" )
    fExp.write( "select \'Compile schema SENS\' from dual ;")
    fExp.write( "\n" )
    fExp.write( "begin" + "\n" )
    fExp.write( "DBMS_UTILITY.compile_schema(schema => \'SENS\');" + "\n" )
    fExp.write( "end;" + "\n" )
    fExp.write( "/" + "\n" )
    fExp.write( "\n" )

    # Close file
    fExp.write( "\n" )
    fExp.write( "spool off" + "\n" )
    fExp.write( "\n" )
    fExp.write( "exit;" + "\n" )
    fExp.close()

    # Get new dbversion
    db_version_id_new = DbCursor.callfunc("sdb_interface_pck.getDbVersionId", cx_Oracle.STRING )

    # Write the versions of the PLSQL versions of this version to file
    write_package_version_info ( DbConnection, DeployFileDir, db_version_id_new )

    # Commit and close database connection
    DbConnection.commit()
    DbConnection.close()

    # Script is completed, commit and close DB connection
    logger.info("Generated scripts are in " + str(DeployFileDir))
    logger.info("New dbversion ID is " + str(db_version_id_new))

    return db_version_id_new, db_client_id

def initLogger():
    # Initialize logger
    logger = logging.getLogger(MODULE_NAME)
    logger.setLevel(logging.INFO)
    stream_hdlr = logging.StreamHandler()
    formatter   = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_hdlr.setFormatter(formatter)
    logger.addHandler(stream_hdlr)

    return logger

if __name__ == "__main__":

    try:

        try :
            # Read input parameters
            argc = len(sys.argv)
            if argc != 2:
                show_gui = True
            else :
                show_gui = False
                parameter_file_list = parse_parameter_file( sys.argv[1] )

            logger = initLogger()
            
            # Build gui for input
            if show_gui :
                # Popup GUI for parameter input
                gui_import ( )
            else :
                # Run with command line parameter file import
                run ( parameter_file_list )

        except Exception, err:
            logger.info ( "Generation parameterfiles failed: ERROR: %s\n" % str(err) )

    except Exception, err:
        print "Generation parameterfiles failed: ERROR: %s\n" % str(err)
        sys.exit(1)
    else:
        sys.exit(0)
