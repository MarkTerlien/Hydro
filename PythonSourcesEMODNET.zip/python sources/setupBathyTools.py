from cx_Freeze import setup, Executable

import datetime
import shutil
import os
import glob
import cx_Oracle

# DB connect Parameters
DB_USER_SOURCE        = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE    = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE         = "DB_TNS_SOURCE"

# Database connection parameter values
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "sens"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "senso"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "192.168.1.20/EMODNET"

# Get the current version from database
DbConnection = cx_Oracle.connect( PARAMETER_LIST_VALUE [ DB_USER_SOURCE ], PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ], PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ] )
DbCursor     = DbConnection.cursor()
version_id   = DbCursor.callfunc("sdb_interface_pck.getdbversionid", int )
DbConnection.close()

# Update version in file
l_date        = datetime.datetime.now()
file_handle   = open ("C:\\EMODNET\\8_python\\BathyTools\\src\\etc\\version.txt", "r+")
line_list     = file_handle.readlines()
last_line     = line_list[-1]
line_items    = last_line.split(";")
l_build_items = line_items[1]
l_build_item  = l_build_items.split(":")
l_build_nr    = int(l_build_item[1])
# Increase build number 
l_build_nr    = l_build_nr + 1
file_handle.close()
file_handle = open ("C:\\EMODNET\\8_python\\BathyTools\\src\\etc\\version.txt", "w")
file_handle.writelines(line_list)
file_handle.write("Version: " + str(version_id) + " ; Build: " + str(l_build_nr) + " ; Date: " + str(l_date) + " ;" + "\n" )
file_handle.close()

# Copy file from v2 to build directory
print "Copy V2 files to build directory"
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyTools.py", "C:\\EMODNET\\8_python\\BathyTools\\src\\BathyTools.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyExecutablesLib.py", "C:\\EMODNET\\8_python\\BathyTools\\src\\BathyExecutablesLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyToolsLib.py", "C:\\EMODNET\\8_python\\BathyTools\\src\\BathyToolsLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyDbLib.py", "C:\\EMODNET\\8_python\\BathyTools\\src\\BathyDbLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyProcessesLib.py", "C:\\EMODNET\\8_python\\BathyTools\\src\\BathyProcessesLib.py" )

includeFiles = [
("C:\EMODNET\8_python\BathyTools\src\etc\shapely\geos.dll", "geos.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\shapely\libgeos-3-0-4.dll", "libgeos-3-0-4.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\Microsoft.VC90.CRT.manifest", "Microsoft.VC90.CRT.manifest"),
("C:\EMODNET\8_python\BathyTools\src\GenerateDeployFiles.par","GenerateDeployFiles.par"),
("C:\EMODNET\8_python\BathyTools\src\etc\proj.dll","proj.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\coordinate_axis.csv", "coordinate_axis.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\ellipsoid.csv", "ellipsoid.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\gcs.csv", "gcs.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\gcs.override.csv", "gcs.override.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\gdal_datum.csv", "gdal_datum.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\gt_datum.csv", "gt_datum.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\gt_ellips.csv", "gt_ellips.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\pcs.csv", "pcs.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\pcs.override.csv", "pcs.override.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\prime_meridian.csv", "prime_meridian.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv"),
("C:\EMODNET\8_python\BathyTools\src\etc\\version.txt", "version.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\license_cx_Freeze.txt", "license_cx_Freeze.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\license_cx_Oracle.txt", "license_cx_Oracle.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\license_gdal_ogr.txt", "license_gdal_ogr.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\license_Python24.txt", "license_Python24.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\GeoConv.exe", "GeoConv.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\Y2c.dat", "Y2c.dat"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\X2c.dat", "X2c.dat"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\nlGeo04.dat", "nlGeo04.dat"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\RD_ETRS_DLL.dll", "RD_ETRS_DLL.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\SENSMakeGrid.exe", "SENSMakeGrid.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\geotiff.dll", "geotiff.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\libtiff.dll", "libtiff.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\Readme.txt", "Readme.txt"),
("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\digipol.exe", "digipol.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\SENSMakeGridEMOD.exe", "SENSMakeGridEMOD.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\vdatumgrid.dat", "vdatumgrid.dat"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\libgcc_s_dw2-1.dll", "libgcc_s_dw2-1.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\mingwm10.dll", "mingwm10.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\QtXml4.dll", "QtXml4.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\QtCore4.dll", "QtCore4.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\QtGui4.dll", "QtGui4.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\QtNetwork4.dll", "QtNetwork4.dll"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\AsciiImportParser.exe", "AsciiImportParser.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\BagImporter.exe", "BagImporter.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\IsoXmlImporter.exe", "IsoXmlImporter.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\CsvImporter.exe", "CsvImporter.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\DonarImporter.exe", "DonarImporter.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\h5dump.exe", "h5dump.exe"),
#("C:\EMODNET\8_python\BathyTools\src\etc\\SensImporter\\szlibdll.dll", "szlibdll.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\aggregate_22.con", "aggregate_22.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\conv2meter.con", "conv2meter.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\line_27cb.con", "line_27cb.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\point_27cb.con", "point_27cb.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\tile_23_23_STAT_meter.ctl", "tile_23_23_STAT_meter.ctl"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\xyz.ctl", "xyz.ctl"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sdsoverplot.exe", "sdsoverplot.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sdssort.exe", "sdssort.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2sds.exe", "sds2sds.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\asc2sds.exe", "asc2sds.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sdsline27cb.exe", "sdsline27cb.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sdspoint27cb.exe", "sdspoint27cb.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sdscontour.exe", "sdscontour.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\hhaggregate.exe", "hhaggregate.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2contAsc.exe", "sds2contAsc.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2asc_overplot.con","sds2asc_overplot.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2asc_overplot_shoals.con","sds2asc_overplot_shoals.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2asc_overplot_deeps.con","sds2asc_overplot_deeps.con"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\sds2asc.exe","sds2asc.exe"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\libcsds.dll","libcsds.dll"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\MSVCP60D.DLL", "MSVCP60D.DLL"),
("C:\EMODNET\8_python\BathyTools\src\etc\\sds\\msvcrtd.dll", "msvcrtd.dll"),
#("C:\Python24\Lib\site-packages\Scientific\win32\\Scientific_netcdf.pyd","Scientific_netcdf.pyd" ),
#("C:\EMODNET\8_python\BathyTools\src\etc\\netcdf\\netcdf.dll","netcdf.dll" ),
#("C:\EMODNET\8_python\BathyTools\src\etc\\netcdf\\netcdf.exp","netcdf.exp" ),
#("C:\EMODNET\8_python\BathyTools\src\etc\\netcdf\\netcdf.lib","netcdf.lib" )
#("C:\EMODNET\8_python\BathyTools\src\etc\\netcdf\\netcdf.lib","netcdf.lib" )
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\colorsinterp.cmap","colorsinterp.cmap" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\emodnet.cmap","emodnet.cmap" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\glut32.dll","glut32.dll" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\gmtglobe.cmap","gmtglobe.cmap" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\jpeg62.dll","jpeg62.dll" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\libimage.dll","libimage.dll" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\libpng13.dll","libpng13.dll" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\librle3.dll","librle3.dll" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\MakeEMODNet.exe","MakeEMODNet.exe" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\MakeEsriGrid.exe","MakeEsriGrid.exe" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\MakeGeoTIFF.exe","MakeGeoTIFF.exe" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\MakeHull.exe","MakeHull.exe" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\PLINK.EXE","PLINK.EXE" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\PSCP.EXE","PSCP.EXE" ),
("C:\EMODNET\8_python\BathyTools\src\etc\\Emodnet\\zlib1.dll","zlib1.dll" )
]


options = dict(
include_files = includeFiles)

setup(
        name = "BathyTools",
        version = '2.0',
        description = "Executables to run third party executables",
        options = dict(build_exe = options),
        executables = [ Executable("C:/EMODNET/8_python/BathyTools/src/BathyTools.py"),Executable("C:/EMODNET/8_python/BathyTools/src/BathyToolsLib.py"), Executable("C:/EMODNET/8_python/BathyTools/src/BathyProcessesLib.py"), Executable("C:/EMODNET/8_python/BathyTools/src/BathyExecutablesLib.py"),Executable("C:/EMODNET/8_python/BathyTools/src/BathyDbLib.py")])

# Copy vdatum grids
#shutil.copyfile ( "C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\vdatgrid\\lat_etrs.grd","C:\\Program Files\\SENS\\bin\\vdatgrid\\lat_etrs.grd" )
#shutil.copyfile ( "C:\EMODNET\8_python\BathyTools\src\etc\\geoconv\\vdatgrid\\kpgt_etrs.grd","C:\\Program Files\\SENS\\bin\\vdatgrid\\kpgt_etrs.grd" )

# Copy bin directory
print "Copy bin directory for testing"
#shutil.rmtree( "C:\\Program Files\\SENS\\bin" )
#shutil.copytree( "C:\\EMODNET\\8_python\\BathyTools\\src\\buildBathyTools\\exe.win32-2.4", "C:\\Program Files\\SENS\\bin" )
source_dir      = "C:\\EMODNET\\8_python\\BathyTools\\src\\buildBathyTools\\exe.win32-2.6"
destination_dir = "C:\\Program Files\\SENS\\bin"
os.chdir(source_dir)
for file in glob.glob("*"):
     shutil.copy(file, destination_dir)

# Copy to version directory
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyTools.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\BathyTools.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyExecutablesLib.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\BathyExecutablesLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyToolsLib.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\BathyToolsLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyDbLib.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\BathyDbLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyToolsV2\\src\\BathyProcessesLib.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\BathyProcessesLib.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\ProcessCm.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\ProcessCm.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\AddTracklineToIm.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\AddTracklineToIm.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\MakeGridOracleInterface.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\MakeGridOracleInterface.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\MakeGridInterface.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\MakeGridInterface.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\ImportTracklineSurvey.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\ImportTracklineSurvey.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\Template.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\Template.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\ExportCm.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\ExportCm.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\GenerateSdFile.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\GenerateSdFile.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\GenerateHull.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\GenerateHull.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\ImportSurvey.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\ImportSurvey.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\UnloadBathyspace.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\UnloadBathyspace.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\createBathyspace.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\createBathyspace.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\ExportSurveyData.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\ExportSurveyData.py" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\etc\\version.txt", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\version.txt" )
shutil.copyfile ( "C:\\EMODNET\\8_python\\BathyTools\\src\\setupBathyTools.py", "C:\\EMODNET\\8_python\\BathyTools\\current_version\\setupBathyTools.py" )


