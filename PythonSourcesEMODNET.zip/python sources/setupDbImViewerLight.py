from cx_Freeze import setup, Executable
import matplotlib

includeFiles = [
("D:\SensSVN\BathyTools\src\etc\Microsoft.VC90.CRT.manifest", "Microsoft.VC90.CRT.manifest"),
("D:\SensSVN\BathyTools\src\etc\proj.dll","proj.dll"),
("D:\SensSVN\BathyTools\src\etc\coordinate_axis.csv", "coordinate_axis.csv"),
("D:\SensSVN\BathyTools\src\etc\ellipsoid.csv", "ellipsoid.csv"),
("D:\SensSVN\BathyTools\src\etc\gcs.csv", "gcs.csv"),
("D:\SensSVN\BathyTools\src\etc\gcs.override.csv", "gcs.override.csv"),
("D:\SensSVN\BathyTools\src\etc\gdal_datum.csv", "gdal_datum.csv"),
("D:\SensSVN\BathyTools\src\etc\gt_datum.csv", "gt_datum.csv"),
("D:\SensSVN\BathyTools\src\etc\gt_ellips.csv", "gt_ellips.csv"),
("D:\SensSVN\BathyTools\src\etc\pcs.csv", "pcs.csv"),
("D:\SensSVN\BathyTools\src\etc\pcs.override.csv", "pcs.override.csv"),
("D:\SensSVN\BathyTools\src\etc\prime_meridian.csv", "prime_meridian.csv"),
("D:\SensSVN\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv"),
("D:\SensSVN\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv"),
("D:\SensSVN\BathyTools\src\etc\projop_wparm.csv", "projop_wparm.csv")
]

#print matplotlib.get_data_path() # C:\Python24\Lib\site-packages\matplotlib\mpl-data

options = dict(
include_files = includeFiles)

setup(
        name = "Db ImViewer Light",
        version = "0.1",
        description = "View models and geomtries on database",
        #options = dict(build_exe = options),
        options = {"build_exe": {"include_files": [(matplotlib.get_data_path(),'mpl-data')]}},
        executables = [Executable("D:\SensSVN\BathyToolsV2\src\DbImViewerLight.py")])


