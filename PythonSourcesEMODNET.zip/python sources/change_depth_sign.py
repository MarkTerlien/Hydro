import os
import glob

directory = 'C:/EMODNET/13_testdata_Zeeland'
os.chdir(directory)
for file_in in glob.glob("*"):
    filepath, filename = os.path.split(file_in)
    shortname = os.path.splitext(filename)[0]
    file_ext  = os.path.splitext(filename)[1]   
    file_out = directory + "/" + shortname + "_i" + file_ext
    print file_in
    print file_out
    fIn = open(file_in,'r')
    fOut = open (file_out, 'w')
    for line in fIn :
        row =line.rstrip().split()
        x = str(row[0])
        y = str(row[1])
        z = str(-1*float(row[2]))
        fOut.write( x + ' ' + y + ' ' + z + '\n')
    fIn.close()
    fOut.close()