#! /usr/bin/python

""" Template function """

# Soure of example: http://sebsauvage.net/python/gui

# standard library imports
try:
    import wx
except ImportError:
    raise ImportError,"The wxPython module is required to run this program."

__author__="Terlien"
__date__ ="$9-okt-2009 11:50:05$"
__copyright__ = "Copyright 2009, ATLIS"


class Simpleapp_wx(wx.Frame):
    def __init__(self,parent,id,title):
        wx.Frame.__init__(self,parent,id,title)
        self.initialize()

    def initialize(self):

        # Get the grid layout Manager
        sizer = wx.GridBagSizer()
        
        # Create text control and add text control to GUI
        self.entry = wx.TextCtrl(self,-1,value=u"Enter text here.")
        sizer.Add(self.entry,(0,0),(1,1),wx.EXPAND)

        # Add event handler to text box
        self.Bind(wx.EVT_TEXT_ENTER, self.onPressEnter, self.entry)

        # Add a button to grid layout
        button = wx.Button(self,-1,label="Click me !")
        sizer.Add(button, (0,1))

        # Add event handler to button
        self.Bind(wx.EVT_BUTTON, self.onButtonClick, button)

        # Add label to grid layout
        self.label = wx.StaticText(self,-1,label=u'Hello !')
        self.label.SetBackgroundColour(wx.BLUE)
        self.label.SetForegroundColour(wx.WHITE)
        sizer.Add( self.label, (1,0),(1,2), wx.EXPAND )

        # Only resize the first column
        sizer.AddGrowableCol(0)

        # Use sizer 
        self.SetSizerAndFit(sizer)

        # prevent resizing vertically
        self.SetSizeHints(-1,self.GetSize().y,-1,self.GetSize().y )

        # Set focus on text control
        self.entry.SetFocus()
        self.entry.SetSelection(-1,-1)

        # Show window
        self.Show(True)

    def onButtonClick(self,event):
        self.label.SetLabel( self.entry.GetValue() + " (You clicked the button)" )
        self.entry.SetFocus()
        self.entry.SetSelection(-1,-1)

    def onPressEnter(self,event):
        self.label.SetLabel( self.entry.GetValue() + " (You pressed ENTER)" )
        self.entry.SetFocus()
        self.entry.SetSelection(-1,-1)

if __name__ == "__main__":
    app = wx.App()
    frame = Simpleapp_wx(None,-1,'my application')
    app.MainLoop()