#! /usr/bin/python

""" Template function """

# standard library imports
import cx_Oracle
from osgeo import ogr

__author__="Terlien"
__date__ ="$9-okt-2009 11:50:05$"
__copyright__ = "Copyright 2009, ATLIS"

if __name__ == "__main__":

	print "Start"