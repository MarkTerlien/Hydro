#! /usr/bin/python

""" Function to import survey into database
"""

# Standard library imports
import sys
import time
import logging
import xml.dom.minidom

# Related third party imports
import cx_Oracle
import pylab
from easygui import *
from osgeo import ogr

# Module name
MODULE_NAME = "dKartPlugin"

# DB connect Parameters
DB_USER_SOURCE       = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE   = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE        = "DB_TNS_SOURCE"

# Database connection parameter values
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "sens"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "senso"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "10.20.0.49/sens11"

# Product types
CONTOURS       = "Contours (DEPCNT and DEPARE)"
SPOT_SOUNDINGS = "Spot soundings (SOUNDG)"

# Product type list
PRODUCT_TYPE_LIST = {}
PRODUCT_TYPE_LIST [ CONTOURS ]       = 811
PRODUCT_TYPE_LIST [ SPOT_SOUNDINGS ] = 812

# Menu options
DEFINE_PRODUCT      = "Define product"
SHOW_PRODUCT_SERIES = "Show product series"
DEFINE_COVERAGE     = "Define coverage"
SUBMIT_ORDER        = "Submit order"
GET_PRODUCT_FILE    = "Get product file"
DELETE_PRODUCT_S    = "Delete product series"
COMMIT              = "Commit"
ROLLBACK            = "Rollback"
EXIT                = "Exit"

# Menu options dictionary
MENU_OPTIONS = {}
MENU_OPTIONS [ DEFINE_PRODUCT ]      = "Define product series"
MENU_OPTIONS [ SHOW_PRODUCT_SERIES ] = "Show product series"
MENU_OPTIONS [ DEFINE_COVERAGE ]     = "Define coverage tiles"
MENU_OPTIONS [ SUBMIT_ORDER ]        = "Submit order"
MENU_OPTIONS [ GET_PRODUCT_FILE ]    = "Get product file"
MENU_OPTIONS [ DELETE_PRODUCT_S ]    = "Delete product series"
MENU_OPTIONS [ COMMIT ]              = "Commit"
MENU_OPTIONS [ ROLLBACK ]            = "Rollback"
MENU_OPTIONS [ EXIT ]                = "Exit"

# Logging levels
LOG_LEVEL = 'info'
LOGLEVELS = {'debug'   : logging.DEBUG,
             'info'    : logging.INFO,
             'warning' : logging.WARNING,
             'error'   : logging.ERROR,
             'critical': logging.CRITICAL}

# Object class ID
IM_CLASS_ID             = 236
CM_CLASS_ID             = 263
PRODUCT_SERIES_CLASS_ID = 321
PRODUCT_CLASS_ID        = 322
PROD_EDITION_CLASS_ID   = 324
PRODUCT_ORDER_CLASS_ID  = 325
PROD_DOWNLOAD_CLASS_ID  = 569
CM_SOURCE_CLASS_ID      = 806
IM_SOURCE_CLASS_ID      = 807
EXPORT_PARAM_CLASS_ID   = 808
CONTOURS_CLASS_ID       = 811
SPOTS_CLASS_ID          = 812
SHAPE_CLASS_ID          = 813

# Attributes
ID   = "Id"
NAME = "Name"

# Output file format
SHAPE = 814

# Product type export
PRODUCT_TYPE = 267731 # Export products (808)

# Product series sources
IM = "Individual model"
IM_SOURCE_TABLE = "SDB_INDIVIDUALMODEL"
IM_SOURCE_GEOM  = "SYS_GEOM001"
IM_SELECT_ID    = "ID"
CM = "Continuous model"
CM_SOURCE_TABLE = "SDB_COOKIE"
CM_SOURCE_GEOM  = "SYS_GEOM501"
CM_SELECT_ID    = "SYS502"
 
# Tile/coverage para,eters
TILE_NAME  = "Tile name"
LL_X       = "Lower left X (decimal degrees)"
LL_Y       = "Lower left Y (decimal degrees)"
TILE_SIZE  = "Tile size (degrees)"

# File column product order to store file
FILE_COL = "SYS012"

#########################################
# GUI functions
#########################################

def gui_start ( DbConnection ) :
    """Function to build gui"""
    logger.info("Build main GUI")
    while True :
        title = "dKartPlugin"
        msg   = "Make your choice"
        options = [ MENU_OPTIONS [ DEFINE_PRODUCT ], MENU_OPTIONS [ SHOW_PRODUCT_SERIES ], MENU_OPTIONS [ DEFINE_COVERAGE ], MENU_OPTIONS [ SUBMIT_ORDER ], MENU_OPTIONS [ GET_PRODUCT_FILE ], MENU_OPTIONS [ DELETE_PRODUCT_S ], MENU_OPTIONS [ COMMIT ] , MENU_OPTIONS [ ROLLBACK ], MENU_OPTIONS [ EXIT ]  ]
        #reply=buttonbox(msg,title,options,image='PSV.gif')
        reply=buttonbox(msg,title,options)
        if reply == MENU_OPTIONS [ DEFINE_PRODUCT ] :
            gui_product_series_definition ( DbConnection )
        if reply == MENU_OPTIONS [ SHOW_PRODUCT_SERIES ] :
            gui_show_product_series ( DbConnection )
        if reply == MENU_OPTIONS [ DEFINE_COVERAGE ] :
            gui_store_coverage( DbConnection )
        if reply == MENU_OPTIONS [ SUBMIT_ORDER ] :
            gui_submit_order( DbConnection )
        if reply == MENU_OPTIONS [ GET_PRODUCT_FILE ] :
            gui_get_generated_product( DbConnection )
        if reply == MENU_OPTIONS [ DELETE_PRODUCT_S ] :
            gui_delete_product_series( DbConnection )
        if reply == MENU_OPTIONS [ COMMIT ]  :
            logger.info("Commit and close database connection")
            DbConnection.commit()
        if reply == MENU_OPTIONS [ ROLLBACK ]  :
            logger.info("Rollback and close database connection")
            DbConnection.rollback()
        if reply == MENU_OPTIONS [ EXIT ] :
            DbConnection.close()
            break

def gui_product_series_definition ( DbConnection ) :
    """Function to sore product series definition"""
    try :
        logger.info("Start product generation GUI")
        logger.info("Select CM source")

        # Select product type
        msg             = "Select product type"
        title           = "Product type selection"
        product_type_id = int(PRODUCT_TYPE_LIST [ choicebox(msg, title, [ CONTOURS, SPOT_SOUNDINGS ]) ])
        print product_type_id

        # Input product series name
        msg                 = "Give name of product series"
        title               = "Product series name"
        product_series_name = str(enterbox(msg, title, default='', strip=True, image=None, root=None))
        logger.info( "Product series name: " + product_series_name )

        # Popupsto select product series source
        msg     = "Select product series source"
        title   = "Product series source selection"
        choices = [IM, CM]
        source  = choicebox(msg, title, choices)
        logger.info( "Product series source: " +  str(source) )
        if source == CM :
            msg     = "Select continuous model"
            title   = "Continuous model selection"
            source_name         = CM
            instance_id         = int(DbConnection.get_cm_id ( choicebox(msg, title, DbConnection.get_cm_list() ) ))
            object_class_source = CM_SOURCE_CLASS_ID
            logger.info( "Continuous model ID: " +  str(instance_id) )
        if source == IM :
            msg     = "Select individual model"
            title   = "Individual model selection"
            source_name         = IM
            instance_id         = int(DbConnection.get_im_id ( choicebox(msg, title, DbConnection.get_im_list() ) ))
            object_class_source = IM_SOURCE_CLASS_ID
            logger.info( "Individual model ID: " +  str(instance_id) )

        # Input product type parameters
        msg       = "Give map scale"
        title     = "Map scale selection"
        map_scale = int(integerbox(msg, title, default=10000, lowerbound=1, upperbound=1000000000))
        search_distance = int(float(0.0005) * map_scale)
        buffer_distance = int(float(0.0002) * map_scale)
        logger.info( "Map scale: " +  str(map_scale) )
        logger.info( "Search distance: " +  str(search_distance) )
        logger.info( "Buffer distance: " +  str(buffer_distance) )

        # Store source
        attribute_list = {}
        attribute_list [ "NAME" ]   =  source_name + " source product series " + product_series_name
        attribute_list [ "SYS001" ] =  instance_id
        object_source_id = int(DbConnection.set_obj_attributes (object_class_source, attribute_list ))
        logger.info( "Source ID: " +   str(object_source_id) )

        # Store Product type parameters
        if product_type_id == CONTOURS_CLASS_ID :
            product_parameter_class_id = CONTOURS_CLASS_ID
            attribute_list = {}
            attribute_list [ "NAME" ]   =  "Parameter values for product series " + product_series_name
            attribute_list [ "MAPSCALE" ]        = map_scale
            attribute_list [ "CONTOURINTERVAL" ] = 86025
            attribute_list [ "SEARCHDISTANCE" ]  = search_distance
            attribute_list [ "DEPTHPRECISION" ]  = 2
            attribute_list [ "SAMPLINGMETHOD" ]  = 14526
            attribute_list [ "DEEPAREA" ]        = 25
            attribute_list [ "SHALLOWAREA" ]     = 25
            attribute_list [ "BUFFERDISTANCE" ]  =  buffer_distance
            attribute_list [ "BUFFERRATIO" ]     =  0.95
        if product_type_id == SPOTS_CLASS_ID :
            product_parameter_class_id = SPOTS_CLASS_ID
            attribute_list = {}
            attribute_list [ "NAME" ]   =  "Parameter values for product series " + product_series_name
            attribute_list [ "MAPSCALE" ]        = map_scale
            attribute_list [ "DEPTHPRECISION" ]  = 2
        product_parameter_values_id = int(DbConnection.set_obj_attributes ( product_parameter_class_id, attribute_list ))
        logger.info( "Product parameter values ID: " +  str(product_parameter_values_id) )

        # Store  Output file parameters
        attribute_list = {}
        attribute_list [ "NAME" ]   =  "Output parameters product series " + product_series_name
        output_parameter_values_id = int(DbConnection.set_obj_attributes ( SHAPE_CLASS_ID, attribute_list ))
        logger.info( "Output parameters values ID: " + str(output_parameter_values_id) )

        # Store export product parameters
        attribute_list = {}
        attribute_list [ "NAME" ]   = "Export parameters product series " + product_series_name
        attribute_list [ "SYS001" ] = object_class_source
        attribute_list [ "SYS002" ] = object_source_id
        attribute_list [ "SYS003" ] = product_parameter_class_id
        attribute_list [ "SYS004" ] = product_parameter_values_id
        attribute_list [ "SYS005" ] = SHAPE_CLASS_ID
        attribute_list [ "SYS006" ] = output_parameter_values_id
        attribute_list [ "SYS007" ] = 105044 # EPSG code WGS84 (4326)
        attribute_list [ "SYS009" ] = 93     # Vertical datum MSL
        attribute_list [ "SYS010" ] = -1     # Multiplication factor
        attribute_list [ "SYS011" ] = 0      # Offset
        export_parameter_values_id = int(DbConnection.set_obj_attributes ( EXPORT_PARAM_CLASS_ID, attribute_list ))
        logger.info( "Export parameters values ID: " + str(export_parameter_values_id) )

        # Store product series
        attribute_list = {}
        attribute_list [ "NAME" ]   = product_series_name
        attribute_list [ "SYS001" ] = PRODUCT_TYPE
        attribute_list [ "SYS003" ] = export_parameter_values_id
        product_series_id = int(DbConnection.set_obj_attributes ( PRODUCT_SERIES_CLASS_ID, attribute_list ))
        logger.info( "Product series ID: " + str(product_series_id) )

        logger.info("Storing product series definition finished")

    except Exception, err:
        logger.critical("Product series definition failed: ERROR: " + str(err))
        sys.exit("Execution stopped")

def gui_show_product_series ( DbConnection ) :
    """Function to show source and tile/coverage"""

    try :

        # Select product series
        msg     = "Select product series"
        title   = "Product series selection"
        product_series_id = DbConnection.select_from_dropdown_list ( PRODUCT_SERIES_CLASS_ID, msg, title  )
        attributes = [ "SYS003"  ]
        values     = DbConnection.get_obj_attributes ( PRODUCT_SERIES_CLASS_ID, product_series_id, attributes )
        export_parameters_id  = int(values[0])

        # Get source object class and instance
        attributes = [ "SYS001", "SYS002"  ]
        values     = DbConnection.get_obj_attributes ( EXPORT_PARAM_CLASS_ID, export_parameters_id, attributes )
        p_source_class_id     = int(values[0])
        p_source_instance_id  = int(values[1])
        attributes  = [ "SYS001" ]
        values      = DbConnection.get_obj_attributes ( p_source_class_id, p_source_instance_id, attributes )
        if values[0] <> None :
            source_instance_id = int(values[0])
            if p_source_class_id == CM_SOURCE_CLASS_ID :
                source_table    = CM_SOURCE_TABLE
                source_geom_col = CM_SOURCE_GEOM
                source_id_col   = CM_SELECT_ID
            if p_source_class_id == IM_SOURCE_CLASS_ID :
                source_table    = IM_SOURCE_TABLE
                source_geom_col = IM_SOURCE_GEOM
                source_id_col   = IM_SELECT_ID

            # Get source geometries from database and plot
            source_geometry_list = DbConnection.get_geometries ( source_table, source_geom_col, source_id_col, source_instance_id )
            print len(source_geometry_list)
            if len(source_geometry_list) > 0 :
                for geom in source_geometry_list :
                    plot_geometry ( ogr.CreateGeometryFromWkt( str(geom[0]) ), 'r', 'r' )

            # Get tile geometries from database and plot
            tile_geometry_list = DbConnection.get_geometries ( 'SDB_PRODUCT', 'SYS_GEOM001', 'SYS001', product_series_id )
            if len(tile_geometry_list) :
                for geom in tile_geometry_list :
                    plot_geometry ( ogr.CreateGeometryFromWkt( str(geom[0]) ), 'b', 'b' )

            # Show plot
            show_plot()
        else :
            logger.info ("Source is deleted")

    except Exception, err:
        logger.critical("Show source and coverage failed: ERROR: " + str(err))
        sys.exit("Execution stopped")


def gui_store_coverage( DbConnection ) :
    """Function to store product tile/coverage"""
    try:

        # Select product series
        msg     = "Select product series"
        title   = "Product series selection"
        product_series_id = DbConnection.select_from_dropdown_list ( PRODUCT_SERIES_CLASS_ID, msg, title  )
        attributes = [ "NAME"  ]
        values     = DbConnection.get_obj_attributes ( PRODUCT_SERIES_CLASS_ID, product_series_id, attributes )
        product_series_name  = values[0]

        logger.info("Store coverage for product series: " + str(product_series_name) + "( " + str(product_series_id) + " )" )

        # Input product tile/coverage
        msg    = "Give product coverage definition"
        title  = "Product coverage definition"
        tile_parameters = [TILE_NAME, LL_X, LL_Y, TILE_SIZE]
        tile_values     = []
        tile_values     = multenterbox(msg,title, tile_parameters)
        tile_name       = str(tile_values[0])
        logger.info("Tile/coverage definition " + str(tile_values) )

        # Convert tile to wkt geometry and store tile
        ll_x = float(tile_values[1])
        ll_y = float(tile_values[2])
        size = float(tile_values[3])
        polygon = ogr.Geometry(ogr.wkbPolygon)
        ring    = ogr.Geometry(ogr.wkbLinearRing)
        ring.AddPoint(ll_x,ll_y)                # ll
        ring.AddPoint(ll_x + size, ll_y)        # lr
        ring.AddPoint(ll_x + size, ll_y + size) # ur
        ring.AddPoint(ll_x,ll_y + size)         # ul
        ring.CloseRings()
        polygon.AddGeometry(ring)
        polygon.FlattenTo2D()
        tile_wkt = str(polygon.ExportToWkt())
        DbConnection.store_tile ( product_series_id, tile_name, tile_wkt )

    except Exception, err:
        logger.critical("Store coverage failed: ERROR: " + str(err))
        sys.exit("Execution stopped")

def gui_submit_order( DbConnection ) :
    """Function to submit a product order for execution"""
    try:

        # Tile/product selection
        msg     = "Select tile to produce"
        title   = "Tile selection"
        tile_id = int(DbConnection.get_id ( PRODUCT_CLASS_ID, choicebox(msg, title, DbConnection.get_flagged_tile_list() ) ))
        logger.info("Tile to produce: " + str(tile_id) )

        # Submit order
        product_order_id = DbConnection.submit_order_for_new_edition ( tile_id )
        logger.info("Product order submitted with ID: " + str(product_order_id) )

        # Commit
        DbConnection.commit()

        # Monitor execution
        while True :
            order_status = DbConnection.get_order_status ( product_order_id )
            if order_status in ( "Failed" , "Cancelled", "Finished" ) :
                break
            else :
                logger.info("Product order status is " + str(order_status) )
            time.sleep( 1 )
        logger.info( "Product order status is " + str(DbConnection.get_order_status ( product_order_id )) )

    except Exception, err:
        logger.critical("Submit order failed: ERROR: " + str(err))
        sys.exit("Execution stopped")

#def gui_show_task_progress()

def gui_get_generated_product( DbConnection ) :
    """Function to download generated product from database"""
    try:

        # Tile/product selection
        msg     = "Select tile to download"
        title   = "Download tile selection"
        tile_id = int(DbConnection.get_id ( PRODUCT_CLASS_ID, choicebox(msg, title, DbConnection.get_product_with_editions_list() ) ))
        logger.info("Tile to download: " + str(tile_id) )

        # Get product file
        msg     = "Select file name and directory"
        title   = "Save file"
        l_blob_file = filesavebox(msg, title, default=None)
        if '.zip' not in l_blob_file :
            l_blob_file = l_blob_file + '.zip'
        DbConnection.get_product_file (  tile_id, l_blob_file )
        logger.info("Product file saved to: " + str(l_blob_file) )

    except Exception, err:
        logger.critical("Get generated product failed: ERROR: " + str(err))
        sys.exit("Execution stopped")

def gui_delete_product_series ( DbConnection ) :
    """Function delete product series"""
    try :

        # Select product series
        msg     = "Select product series"
        title   = "Product series selection"
        product_series_id = DbConnection.select_from_dropdown_list ( PRODUCT_SERIES_CLASS_ID, msg, title  )
        logger.info("Delete product series: " + str(product_series_id) )

        # Delete product series
        DbConnection.delete_product_series ( product_series_id )

    except Exception, err:
        logger.critical("Delete product series failed: ERROR: " + str(err))
        sys.exit("Execution stopped")

def gui_db_connection_input () :
    logger.info("GUI database connection parameters")
    title = 'Database connection parameters'
    msg   = "Enter database connection parameters"
    field_names   = [ DB_TNS_SOURCE, DB_USER_SOURCE , DB_PASSWORD_SOURCE ]
    return_values = [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ]
    return_values = multpasswordbox(msg,title, field_names, return_values)
    if return_values :
        PARAMETER_LIST_VALUE [DB_TNS_SOURCE]      = return_values[0]
        PARAMETER_LIST_VALUE [DB_USER_SOURCE]     = return_values[1]
        PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE] = return_values[2]

#########################################
#  GIS Functions
#########################################

def plot_geometry ( ogr_geom_in, exterior_color, interior_color ) :
    """Function to plot geometry"""
    if ogr_geom_in.GetGeometryName() == 'MULTIPOINT' or ogr_geom_in.GetGeometryName() == 'MULTILINESTRING' or ogr_geom_in.GetGeometryName() == 'MULTIPOLYGON' :
        for i in range(ogr_geom_in.GetGeometryCount()):
            plot_geometry ( ogr_geom_in.GetGeometryRef( i ), exterior_color, interior_color )
    if ogr_geom_in.GetGeometryName() == 'POINT' :
        x = []
        y = []
        x.append(ogr_geom_in.GetX())
        y.append(ogr_geom_in.GetY())
        pylab.plot(x,y,'o',color='y')
    if ogr_geom_in.GetGeometryName() == 'LINESTRING' :
        x = []
        y = []
        for i in range(ogr_geom_in.GetPointCount()) :
            x.append(ogr_geom_in.GetX(i))
            y.append(ogr_geom_in.GetY(i))
        pylab.plot(x,y,'-',color='g')
    if ogr_geom_in.GetGeometryName() == 'POLYGON' :
        polygon      = ogr_geom_in
        ring_index   = 0
        for nr_ring in range ( polygon.GetGeometryCount() ):
            ring        = polygon.GetGeometryRef( nr_ring )
            x =[ring.GetX(i) for i in range(ring.GetPointCount()) ]
            y =[ring.GetY(i) for i in range(ring.GetPointCount()) ]
            if ring_index == 0 :
                pylab.plot(x,y,'-',color=str(exterior_color), linewidth=2.0, hold=True)
            else :
                pylab.plot(x,y,'-',color=str(interior_color), linewidth=2.0, hold=True)
            ring_index = ring_index + 1

def show_plot() :
    """Function to show plot"""
    logger.info("Show plot")
    pylab.axis('equal')
    pylab.xlabel("Longitud")
    pylab.ylabel("Latitud")
    pylab.grid(True)
    pylab.title("Product tiles and product source")
    pylab.show()

##########################################
#  Database Class
##########################################

class DbConnection:
    """Connection class to Oracle database"""

    def __init__(self, DbUser, DbPass, DbConnect):
        try :
            self.logger = logging.getLogger( 'DbConnection' )
            self.logger.info("Setup database connection")
            self.oracle_connection = cx_Oracle.connect(DbUser, DbPass, DbConnect)
            self.oracle_cursor = self.oracle_connection.cursor()
            self.oracle_cursor.execute("select 'established' from dual")
        except Exception, err:
            self.logger.critical("Setup database connection failed: ERROR: " + str(err))
            sys.exit("Execution stopped")

    def get_obj_attributes ( self, object_class_id, object_instance_id, attribute_list ) :
        """Function to get value of attribute for object instance"""
        try :
            self.logger.info("Query on database")
            l_query_xml = "<Filter><And><PropertyIsEqualTo><PropertyName>ID</PropertyName><Literal>" + str(object_instance_id) + "</Literal></PropertyIsEqualTo></And></Filter>"
            l_result_xml = self.oracle_cursor.callfunc("sdb_interface_pck.getObject", cx_Oracle.CLOB, [object_class_id, l_query_xml ])
            l_result_dom = xml.dom.minidom.parseString(str(l_result_xml))
            values = []
            for attribute in attribute_list :
                l_domain_value_tag = l_result_dom.getElementsByTagName(attribute)[0]
                # If attribute has no value catch exception and set value to None
                try :
                    l_value = l_domain_value_tag.childNodes[0].nodeValue
                except :
                    l_value = None
                values.append(l_value)
            return values
        except Exception, err:
            self.logger.critical("Query on database failed: ERROR: " + str(err))
            sys.exit("Execution stopped")

    def set_obj_attributes ( self, object_class_id, attribute_list ) :
        """Function to set value of attribute for object instance"""
        try :
            self.logger.info( "Insert attributes in database" )
            l_mut_xml = "<ROWSET><ROW>"
            l_attribute_keys = attribute_list.keys()
            for l_attribute_key in l_attribute_keys :
                l_mut_xml = l_mut_xml + "<" + l_attribute_key + ">" + str(attribute_list[l_attribute_key]) + "</" + l_attribute_key + ">"
            l_mut_xml = l_mut_xml + "</ROW></ROWSET>"
            # Insert attributes
            l_obj_id = self.oracle_cursor.callfunc("sdb_interface_pck.setObject", cx_Oracle.NUMBER, [object_class_id, 'I', l_mut_xml ])
            return l_obj_id
        except Exception, err:
            self.logger.critical( "Insert attributes in database failed:ERROR: %s\n" % str(err))
            raise

    def get_geometries ( self, object_class_table, spatial_column, select_column, select_id ) :
        """Function to get geometries from database"""
        stmt = 'select sdo_util.to_wktgeometry(' + str(spatial_column) + ') from ' + str(object_class_table) + ' where ' + str(select_column) + ' = ' + str(select_id)
        self.oracle_cursor.execute( stmt )
        resultset = self.oracle_cursor.fetchall()
        return resultset

    def del_obj_instance ( self, object_class_id, object_instance_id ) :
        """Function to set value of attribute for object instance"""

        # Build DOM
        doc = xml.dom.minidom.Document()
        rowset = doc.createElement("ROWSET")
        doc.appendChild(rowset)
        row = doc.createElement("ROW")
        rowset.appendChild(row)

        # Add ID attribute
        attribute = doc.createElement("ID")
        row.appendChild(attribute)
        value = doc.createTextNode(str(object_instance_id))
        attribute.appendChild(value)

        # Get XML as string
        l_mut_xml = doc.toxml()

        # Delete instance
        l_obj_id = self.oracle_cursor.callfunc("sdb_interface_pck.setObject", cx_Oracle.NUMBER, [object_class_id, 'D', l_mut_xml ])
        l_obj_id = l_obj_id


    def store_tile ( self, product_series_id, tile_name, wkt_geom ) :
        attribute_list = {}
        attribute_list [ "NAME" ]   =  "Tile " + str(tile_name) +  " product series " + str(product_series_id)
        attribute_list [ "SYS001" ] = product_series_id # Product series ID
        attribute_list [ "SYS006" ] = 'F'               # Auto publish
        attribute_list [ "SYS007" ] = 'F'               # Auto generate
        l_tile_id = int(DbConnection.set_obj_attributes ( PRODUCT_CLASS_ID, attribute_list ))
        l_geom = self.oracle_cursor.var(cx_Oracle.CLOB)
        l_geom.setvalue(0, wkt_geom)
        l_geom_col = 'SYS_GEOM001'
        self.oracle_cursor.callproc("sdb_interface_pck.setGeom",[PRODUCT_CLASS_ID, l_tile_id, l_geom_col, l_geom])
        logger.info( "Tile with ID " +  str(l_tile_id) + " sucessfully stored" )

    def get_flagged_tile_list ( self ) :
        """Function to get list of flagged tiles"""
        tile_list = []
        stmt = "select name from sdb_product where sys003 =\'T\'"
        self.oracle_cursor.arraysize = 100000
        self.oracle_cursor.execute(stmt)
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                tile_list.append(str(row[0]))
        return tile_list

    def get_product_with_editions_list ( self ) :
        """Function to get list of tiles with editions"""
        tile_list = []
        stmt = "select p.name from sdb_productedition e, sdb_product p where e.sys003 = 4319 and e.sys001 = p.id"
        self.oracle_cursor.arraysize = 100000
        self.oracle_cursor.execute(stmt)
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                tile_list.append(str(row[0]))
        return tile_list

    def get_cm_list ( self ) :
        """Function to get list of activated CM's"""
        cm_name_list = []
        stmt = "select name from sdb_continuousmodel where sys002 =\'T\'"
        self.oracle_cursor.arraysize = 100000
        self.oracle_cursor.execute(stmt)
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                cm_name_list.append(str(row[0]))
        return cm_name_list

    def get_cm_id ( self, cm_name ) :
        stmt  = "select id from sdb_continuousmodel where name = :NAME"
        self.oracle_cursor.execute(stmt, NAME = cm_name )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                cm_id = int(row[0])
        return cm_id

    def get_im_list ( self ) :
        """Function to get list of activated CM's"""
        im_name_list = []
        stmt = "select name from sdb_individualmodel where sys004 in (9,10)"
        self.oracle_cursor.arraysize = 100000
        self.oracle_cursor.execute(stmt)
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                im_name_list.append(str(row[0]))
        return im_name_list

    def get_im_id ( self, im_name ) :
        stmt  = "select id from sdb_individualmodel where name = :NAME"
        self.oracle_cursor.execute(stmt, NAME = im_name )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                im_id = int(row[0])
        return im_id

    def get_list ( self, object_class_id ) :
        """Function to get list"""
        name_list = []
        stmt = "select name from " + self.get_table_name ( object_class_id )
        self.oracle_cursor.arraysize = 100000
        self.oracle_cursor.execute(stmt)
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                name_list.append(str(row[0]))
        return name_list

    def get_id ( self, object_class_id, object_class_name ) :
        stmt  = "select id from " + self.get_table_name ( object_class_id ) + " where name = :NAME"
        self.oracle_cursor.execute(stmt, NAME = object_class_name )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                id = int(row[0])
        return id

    def get_table_name ( self, object_class_id ) :
        stmt  = "select object_class_table from sdb_object_class where id = :ID"
        self.oracle_cursor.execute(stmt, ID = object_class_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                object_class_name = str(row[0])
        return object_class_name

    def select_from_dropdown_list ( self, object_class_id, msg, title ) :
        return int(self.get_id ( object_class_id, choicebox(msg, title, self.get_list( object_class_id ) ) ) )

    def submit_order_for_new_edition ( self, product_tile_id ) :
        return self.oracle_cursor.callfunc("sdb_object_bl_pck.submitOrderForNewEdition", cx_Oracle.NUMBER, [ product_tile_id  ])

    def get_product_file ( self, tile_id, blob_file ) :

        # Get product edition id
        stmt  = "select e.id from sdb_productedition e where e.sys001 = :ID and e.id = ( select max(t.id) from sdb_productedition t where t.sys001 = :ID )"
        self.oracle_cursor.execute(stmt, ID = tile_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                product_edition_id = str(row[0])

        # Get order id from database
        stmt  = "select id from sdb_productorder where sys017 = 324 and sys018 = :PRODUCT_EDITION_ID"
        self.oracle_cursor.execute(stmt, PRODUCT_EDITION_ID  = product_edition_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                product_order_id = str(row[0])

        # Get BLOB: First open file, then get blob from database and then write to file
        fBlob  = open(blob_file, 'wb')
        blob = self.oracle_cursor.callfunc("sdb_interface_pck.getBlob", cx_Oracle.BLOB, [ PRODUCT_ORDER_CLASS_ID, product_order_id, FILE_COL ])
        blob_data = blob.read()
        fBlob.write( blob_data )
        fBlob.close()

    def delete_product_series ( self, product_series_id ) :
        """Function to delete product series"""

        # Delete product downloads
        stmt = "select o.id from sdb_productdownload o,  sdb_productedition e, sdb_product p, sdb_productserie s where o.sys001 = e.id and e.sys001 = p.id and p.sys001 = s.id and s.id = :ID"
        self.oracle_cursor.execute(stmt, ID = product_series_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                self.del_obj_instance ( PROD_DOWNLOAD_CLASS_ID, int(row[0]) )

        # Delete product editions
        stmt = "select e.id from sdb_productedition e, sdb_product p, sdb_productserie s where e.sys001 = p.id and p.sys001 = s.id and s.id = :ID"
        self.oracle_cursor.execute(stmt, ID = product_series_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                self.del_obj_instance ( PROD_EDITION_CLASS_ID, int(row[0]) )

        # Delete products
        stmt = "select p.id from sdb_product p, sdb_productserie s where p.sys001 = s.id and s.id = :ID"
        self.oracle_cursor.execute(stmt, ID = product_series_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                self.del_obj_instance ( PRODUCT_CLASS_ID, int(row[0]) )

        # Get product parameter ID of product series
        stmt = "select s.sys003 from sdb_productserie s where s.id = :ID"
        self.oracle_cursor.execute(stmt, ID = product_series_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                export_parameters_id = int(row[0])

        # Delete product series
        self.del_obj_instance ( PRODUCT_SERIES_CLASS_ID, product_series_id )

        # Get export parameter values
        stmt = "select s.sys001, s.sys002, s.sys003, s.sys004, s.sys005, s.sys006 from sdb_exportparameters s where s.id = :ID"
        self.oracle_cursor.execute(stmt, ID = export_parameters_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                source_class_id = int(row[0])
                source_inst_id  = int(row[1])
                prod_class_id   = int(row[2])
                prod_inst_id    = int(row[3])
                output_class_id = int(row[4])
                output_inst_id  = int(row[5])

        print output_class_id
        print output_inst_id

        # Delete export parameters
        self.del_obj_instance ( source_class_id, source_inst_id )
        self.del_obj_instance ( prod_class_id, prod_inst_id   )
        self.del_obj_instance ( output_class_id, output_inst_id )
        self.del_obj_instance ( EXPORT_PARAM_CLASS_ID, export_parameters_id )

    def get_order_status ( self, order_id ) :
        # Get order status
        stmt = "select s.name from sdb_productorder o, sdb_productorderstatus s where o.sys004 = s.id and o.id = :ID"
        self.oracle_cursor.execute(stmt, ID = order_id )
        resultset = self.oracle_cursor.fetchmany()
        if resultset :
            for row in resultset :
                order_status = str(row[0])
        return order_status

    def commit( self ) :
        """Function to commit and close connection"""
        self.oracle_connection.commit()

    def rollback ( self ) :
        self.oracle_connection.rollback()

    def close ( self ) :
        self.oracle_connection.close()

####################################
# Start main program
####################################

if __name__ == "__main__":

    # Initialize logger
    logger      = logging.getLogger(MODULE_NAME)
    level       = LOGLEVELS.get(LOG_LEVEL, logging.NOTSET)
    logger.setLevel( level )
    stream_hdlr = logging.StreamHandler()
    formatter   = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_hdlr.setFormatter(formatter)
    logger.addHandler(stream_hdlr)

    ############################
    # Database connection
    ############################

    # Ask for database connection parameters
    gui_db_connection_input ()

    logger.info( "Build database connection to " + str(PARAMETER_LIST_VALUE[ DB_USER_SOURCE ]) )
    DbConnection = DbConnection( PARAMETER_LIST_VALUE[ DB_USER_SOURCE ], PARAMETER_LIST_VALUE[ DB_PASSWORD_SOURCE ], PARAMETER_LIST_VALUE[ DB_TNS_SOURCE ])

    # Start gui
    try :
        gui_start ( DbConnection )
    except Exception, err:
        try :
            DbConnection.rollback_close()
        except Exception, err:
            null
        logger.critical( "Execution failed:ERROR: %s\n" % str(err))
        raise

