#! /usr/bin/python

""" Function to import survey into database
"""

# Standard library imports
import os
import sys
import time
import struct
import logging
import xml.dom.minidom

# Related third party imports
import cx_Oracle
from easygui import *

# Pylab imports
import pylab

# GDAL/OGR imports
from osgeo import ogr
from osgeo import osr

# Module name
MODULE_NAME = "DbImViewerLight"

# DB connect Parameters
DB_USER_SOURCE       = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE   = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE        = "DB_TNS_SOURCE"
OBJECT_CLASS_ID      = "OBJECT_CLASS_ID"
OBJECT_INSTANCE_ID   = "OBJECT_INSTANCE_ID"
GEOM_COL             = "GEOM_COL"

# Database connection parameter values
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "sens"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "senso"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "10.20.0.49/sens11"
PARAMETER_LIST_VALUE [ OBJECT_CLASS_ID ]    = 236
PARAMETER_LIST_VALUE [ OBJECT_INSTANCE_ID ] = 86154
PARAMETER_LIST_VALUE [ GEOM_COL ]           = "SYS_GEOM001"

# Menu options
PLOT_GEOMETRY_DB  = "Plot geometry DB"
PLOT_IM           = "Plot IM"
DUMP_IM           = "Dump IM"
DUMP_PS           = "Dump PS"
PLOT_CM           = "Plot CM"
PLOT_SDO          = "Plot SDO"
EXIT              = "Exit"

# Menu options dictionary
MENU_OPTIONS = {}
MENU_OPTIONS [ PLOT_GEOMETRY_DB ]  = "Plot geometry from DB"
MENU_OPTIONS [ PLOT_IM ]           = "Plot individual model"
MENU_OPTIONS [ DUMP_IM ]           = "Dump IM to file"
MENU_OPTIONS [ DUMP_PS ]           = "Dump pointstore to file"
MENU_OPTIONS [ PLOT_CM ]           = "Plot CM segments"
MENU_OPTIONS [ PLOT_SDO ]          = "Plot SDO_GEOMETRY"
MENU_OPTIONS [ EXIT ]              = "Exit"

# Plotting parameters
PLOT_GEOMETRY    = True
SHOW_IMAGE       = False

# Logging levels
LOG_LEVEL = 'info'
LOGLEVELS = {'debug'   : logging.DEBUG,
             'info'    : logging.INFO,
             'warning' : logging.WARNING,
             'error'   : logging.ERROR,
             'critical': logging.CRITICAL}

# Scalars
DEPTH     = "Depth"
AVG_DEPTH = "Average depth"
NR_DEPTHS = "Number of depths"
SCALARS   = [DEPTH, AVG_DEPTH, NR_DEPTHS]

# DB attributes of IM
NR_OF_POINTS     = "SYS012"
DEEPEST_POINT    = "SYS021"
SHALLOWEST_POINT = "SYS022"

# Pointstore info
PS_INFO_CLASS_ID  = 771
PS_MIN_DEPTH      = "MAXZ"
PS_MAX_DEPTH      = "MINZ"
PS_NR_POINTS      = "NROFPOINTS"
PS_INSTANCE_ID    = "INSTANCEID"

#Plot info
MAX_NR_POINTS = 100000

# Convert Oracle element types
ELEMENT_TYPES = {}
ELEMENT_TYPES [ 1003 ] = 2
ELEMENT_TYPES [ 2003 ] = 1

# Class IDs
CM_CLASS_ID = 263

# Parsing ps points on database or client
DB_SELECT = False

#########################################
# GUI functions
#########################################

def gui_start ( DbConnection ) :
    while True :

        ############################
        # Show menu
        ############################

        title = "SENS PointStore Viewer"
        msg   = "Make your choice"
        options = [ MENU_OPTIONS [ PLOT_IM ], MENU_OPTIONS [ PLOT_GEOMETRY_DB ], MENU_OPTIONS [ DUMP_IM ], MENU_OPTIONS [ DUMP_PS ], MENU_OPTIONS [ PLOT_CM ], MENU_OPTIONS [ PLOT_SDO ], MENU_OPTIONS [ EXIT ] ]
        #reply=buttonbox(msg,title,options,image='PSV.gif')
        reply=buttonbox(msg,title,options)
        if reply == MENU_OPTIONS [ PLOT_IM ] :
            plot_im ( DbConnection )
        if reply == MENU_OPTIONS [ PLOT_GEOMETRY_DB ] :
            plot_geometry_db ( DbConnection )
        if reply == MENU_OPTIONS [ DUMP_IM ] :
            dump_im_to_file ( DbConnection )
        if reply == MENU_OPTIONS [ DUMP_PS ] :
            dump_ps_to_file ( DbConnection )
        if reply == MENU_OPTIONS [ PLOT_CM ] :
            plot_cm ( DbConnection )
        if reply == MENU_OPTIONS [ PLOT_SDO ] :
            plot_sdo ( DbConnection )
        elif reply == MENU_OPTIONS [ EXIT ] :
            # Close DB connection
            logger.info("Close database connection")
            DbConnection.close()
            break

##########################################
#  Database functions and classes
##########################################

def db_connection_input () :
    """DB connection input"""

    title = 'Database connection parameters'
    msg   = "Enter database connection parameters"
    field_names   = [ DB_TNS_SOURCE, DB_USER_SOURCE , DB_PASSWORD_SOURCE ]
    return_values = [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ]
    return_values = multpasswordbox(msg,title, field_names, return_values)
    if return_values :
        PARAMETER_LIST_VALUE [DB_TNS_SOURCE]      = return_values[0]
        PARAMETER_LIST_VALUE [DB_USER_SOURCE]     = return_values[1]
        PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE] = return_values[2]

class DbConnectionClass:
    """Connection class to Oracle database"""

    def __init__(self, DbUser, DbPass, DbConnect, parent_module):
        try :
            self.logger = logging.getLogger( parent_module + '.DbConnection')
            self.logger.info("Setup database connection")
            self.oracle_connection = cx_Oracle.connect(DbUser, DbPass, DbConnect)
            self.oracle_cursor = self.oracle_connection.cursor()
            self.oracle_cursor.execute("select 'established' from dual")
        except Exception, err:
            self.logger.critical("Setup database connection failed: ERROR: " + str(err))
            sys.exit("Execution stopped")

    def get_obj_attributes ( self, object_class_id, object_instance_id, attribute_list ) :
        """Function to get value of attribute for object instance"""
        try :
            self.logger.info("Query on database")
            l_query_xml = "<Filter><And><PropertyIsEqualTo><PropertyName>ID</PropertyName><Literal>" + str(object_instance_id) + "</Literal></PropertyIsEqualTo></And></Filter>"
            l_result_xml = self.oracle_cursor.callfunc("sdb_interface_pck.getObject", cx_Oracle.CLOB, [object_class_id, l_query_xml ])
            l_result_dom = xml.dom.minidom.parseString(str(l_result_xml))
            values = []
            for attribute in attribute_list :
                l_domain_value_tag = l_result_dom.getElementsByTagName(attribute)[0]
                # If attribute has no value catch exception and set value to None
                try :
                    l_value = l_domain_value_tag.childNodes[0].nodeValue
                except :
                    l_value = None
                values.append(l_value)
            return values
        except Exception, err:
            self.logger.critical("Query on database failed: ERROR: " + str(err))
            sys.exit("Execution stopped")

    def get_pointstore_info_id ( self, instance_id ) :
        # Get ID of pointstore info
        l_query_xml = "<Filter><And><PropertyIsEqualTo><PropertyName>" + str(PS_INSTANCE_ID) + "</PropertyName><Literal>" + str(instance_id) + "</Literal></PropertyIsEqualTo></And></Filter>"
        l_result_xml = self.oracle_cursor.callfunc("sdb_interface_pck.getObject", cx_Oracle.CLOB, [ PS_INFO_CLASS_ID, l_query_xml ])
        l_result_dom = xml.dom.minidom.parseString(str(l_result_xml))
        l_id_tag   = l_result_dom.getElementsByTagName( "ID" )[0]
        l_id       = int(l_id_tag.childNodes[0].nodeValue)
        return l_id

    def commit_close( self ) :
	"""Function to commit and close connection"""
        self.oracle_connection.commit()
        self.oracle_connection.close()


#########################################
#  GIS Functions
#########################################

def plot_geometry ( ogr_geom_in, exterior_color, interior_color ) :
    """Function to plot geometry"""
    if ogr_geom_in.GetGeometryName() == 'MULTIPOINT' or ogr_geom_in.GetGeometryName() == 'MULTILINESTRING' or ogr_geom_in.GetGeometryName() == 'MULTIPOLYGON' :
        for i in range(ogr_geom_in.GetGeometryCount()):
            plot_geometry ( ogr_geom_in.GetGeometryRef( i ), exterior_color, interior_color )
    if ogr_geom_in.GetGeometryName() == 'POINT' :
        x = []
        y = []
        x.append(ogr_geom_in.GetX())
        y.append(ogr_geom_in.GetY())
        pylab.plot(x,y,'o',color='y')
    if ogr_geom_in.GetGeometryName() == 'LINESTRING' :
        x = []
        y = []
        for i in range(ogr_geom_in.GetPointCount()) :
            x.append(ogr_geom_in.GetX(i))
            y.append(ogr_geom_in.GetY(i))
        pylab.plot(x,y,'-',color='g')
    if ogr_geom_in.GetGeometryName() == 'POLYGON' :
        polygon      = ogr_geom_in
        ring_index   = 0
        for nr_ring in range ( polygon.GetGeometryCount() ):
            ring        = polygon.GetGeometryRef( nr_ring )
            x =[ring.GetX(i) for i in range(ring.GetPointCount()) ]
            y =[ring.GetY(i) for i in range(ring.GetPointCount()) ]
            if ring_index == 0 :
                pylab.plot(x,y,'-',color=str(exterior_color), linewidth=2.0, hold=True)
            else :
                pylab.plot(x,y,'-',color=str(interior_color), linewidth=2.0, hold=True)
            ring_index = ring_index + 1

###################################
# Plot functions
###################################

def plot_sdo ( DbConnection ) :
    """Function to plot sdo_geometry object from database"""

    logger.info( "Plot sdo_geometry object from database" )

    DbCursor        = DbConnection.cursor()

    # Add to wkt function to geometry column
    stmt          = enterbox(msg='Enter query (add sdo_util.to_wktgeometry)', title='Plot spatial query result', default='select sdo_util.to_wktgeometry(', strip=True)
    logger.info ( "Select query is: " + str(stmt) )
    DbCursor.execute( stmt )
    resultset = DbCursor.fetchall()
    nr_geom   = 0
    if resultset :
        for geom in resultset :
            plot_geometry ( ogr.CreateGeometryFromWkt( str(geom[0]) ), 'r', 'b' )
            nr_geom = nr_geom + 1
    logger.info ( str(nr_geom) + " geometries plotted")
    show_plot ( stmt )


def plot_cm ( DbConnection ) :
    """Function to plot CM and write shape file"""

    logger.info( "Plot CM and write shapefile" )

    DbCursor        = DbConnection.cursor()
    object_class_id = CM_CLASS_ID
    msg             = 'Select CM from list'
    title           = 'CM selection'
    where_clause    = 'where sys002 =\'T\''
    cm_id           = select_from_dropdown_list ( DbCursor, object_class_id, msg, title, where_clause )

    logger.info( "Selected CM: " + str(cm_id) )

    # Get query window
    msg   = "Enter query windows in x and y"
    title = "Query window definition"
    minx  = -157
    maxx  = -154
    miny  = 18
    maxy  = 20
    bound_params = ["Minimum X","Maximum X","Minimum Y","Maximum Y"]
    bound_values = [ minx, maxx, miny, maxy ]  # we start with default values
    bound_values = multenterbox(msg,title, bound_params, bound_values)
    minx = float(bound_values[0])
    maxx = float(bound_values[1])
    miny = float(bound_values[2])
    maxy = float(bound_values[3])

    # Initialize shapefile
    shape_file  = filesavebox(msg='Select file', title='File save dialog', default='c://temp//') + str(".shp")
    driver      = ogr.GetDriverByName('ESRI Shapefile')
    if os.path.exists(shape_file) :
        driver.DeleteDataSource(str(shape_file))
    shapeData   = driver.CreateDataSource(str(shape_file))
    target_srs  = osr.SpatialReference()
    target_srs.ImportFromEPSG(4326)
    layer       = shapeData.CreateLayer("CMSegment", target_srs, ogr.wkbPolygon)
    fieldDefn   = ogr.FieldDefn('id', ogr.OFTInteger)
    layer.CreateField(fieldDefn)
    featureDefn = layer.GetLayerDefn()

    # Convert to wkt
    ring    = ogr.Geometry(ogr.wkbLinearRing)
    ring.AddPoint_2D(minx,miny)
    ring.AddPoint_2D(maxx,miny)
    ring.AddPoint_2D(maxx,maxy)
    ring.AddPoint_2D(minx,maxy)
    ring.CloseRings()
    polygon = ogr.Geometry(ogr.wkbPolygon)
    polygon.AddGeometry(ring)
    polygon_1 = DbCursor.var(cx_Oracle.CLOB)
    polygon_1.setvalue(0, polygon.ExportToWkt())
    print polygon.ExportToWkt()
    polygon_2 = DbCursor.var(cx_Oracle.CLOB)
    polygon_2.setvalue(0, polygon.ExportToWkt())
    stmt = 'select id, sdo_util.to_wktgeometry(sdo_geom.sdo_intersection( sys_geom501, sdo_geometry( :p1, 8307 ) , 0.05)) from sdb_cookie '
    stmt = stmt + ' where sys502 = :id and sdo_anyinteract ( sys_geom501, sdo_geometry( :p2, 8307) ) = \'TRUE\' '
    print stmt
    DbCursor.execute(stmt, p1 = polygon_1, id = cm_id, p2 = polygon_2 )
    DbCursor.arraysize = 100000
    DbCursor.execute(stmt)
    resultset = DbCursor.fetchmany()
    i = 0
    if resultset :
        for geom in resultset :
            i = i + 1
            logger.info("CM Segment " + str(i))
            cm_segment_geom = ogr.CreateGeometryFromWkt( str(geom[1]) )
            cm_seg_id       = str(geom[0])
            # Plot on screen
            plot_geometry ( cm_segment_geom, 'r', 'b' )
            # Write to shapefile
            shape_feature = ogr.Feature(featureDefn)
            shape_feature.SetGeometry(cm_segment_geom)
            shape_feature.SetField('id', cm_seg_id)
            layer.CreateFeature(shape_feature)
    shapeData.Destroy()
    show_plot ( stmt )
    logger.info ( str(i) + " CM segments plotted" )

def plot_geometry_db ( DbConnection ) :
    """Function to plot geometry from database"""

    logger.info( "Plot geometry from database" )

    DbCursor     = DbConnection.cursor()

    # Build list of tables with geometry column
    # Get list of IDs from database
    im_name_list = []
    stmt  = "select table_name from user_sdo_geom_metadata"
    DbCursor.arraysize = 100000
    DbCursor.execute(stmt)
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            im_name_list.append(str(row[0]))

    # Popup select box
    msg     = "Select spatial table"
    title   = "Spatial tables"
    table_name = choicebox(msg, title, im_name_list)

    # Get spatial column
    stmt  = "select column_name from user_sdo_geom_metadata where table_name = :NAME"
    DbCursor.execute(stmt, NAME = table_name )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            spatial_column = str(row[0])

    # Ask for where clause
    where_clause  = enterbox(msg='Enter where clause', title='Where clause definition', default='where id = 217870', strip=True)
    stmt          = 'select sdo_util.to_wktgeometry(' + spatial_column + ') from ' + str(table_name) + ' ' + str(where_clause)
    logger.info ( "Select query is: " + str(stmt) )
    DbCursor.execute( stmt )
    resultset = DbCursor.fetchall()
    nr_geom   = 0
    if resultset :
        for geom in resultset :
            plot_geometry ( ogr.CreateGeometryFromWkt( str(geom[0]) ), 'r', 'b' )
            nr_geom = nr_geom + 1

    show_plot ( stmt )

    logger.info ( str(nr_geom) + " plotted" )

def dump_im_to_file ( DbConnection ) :
    """Function to plot points of individual model"""

    logger.info( "Dump coordinates of IM to file" )
    DbCursor     = DbConnection.cursor()

    # Get im to plot
    im_name = get_im_to_plot ( DbCursor )

    # Get geometry from database
    stmt      = "select sys_geom001 from sdb_individualmodel where id = :ID"
    resultset = DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE [ OBJECT_INSTANCE_ID ])
    geom_obj  = resultset.fetchone()[0]
    gtype     = geom_obj.SDO_GTYPE
    elem_info = geom_obj.SDO_ELEM_INFO
    ordinates = geom_obj.SDO_ORDINATES
    logger.info( "gtype       : " + str(gtype) )
    logger.info( "elem_info   : " + str(elem_info) )
    logger.info( "ordinates   : " + str(ordinates) )
    logger.info( "nr elements : " + str(len(elem_info)) )
    logger.info( "nr ordinates: " + str(len(ordinates)) )

    # Select file to save
    output_file = filesavebox(msg='Select file', title='File save dialog', default='c:/temp')
    fOut = open(output_file, 'w')

    # Parse geometry
    nr_of_elements = int(len(elem_info)/3)
    for element_nr in range(0, nr_of_elements) :

        # Process each element
        logger.info("Element       : " + str(element_nr))
        start_ordinate = int(elem_info[ (element_nr * 3) ])
        logger.info("Start ordinate: " + str(start_ordinate))
        if element_nr + 1 == nr_of_elements :
            end_ordinate = int(len(ordinates))
        else :
            end_ordinate = int(elem_info[ ((element_nr * 3) + 3) ])
        logger.info("End ordinate  : " + str(end_ordinate))
        element_type   = elem_info[ ( (element_nr * 3) + 1 ) ]
        logger.info("Element type  : " + str(element_type))

        # Process coordinates in element
        skip = False
        ring = ogr.Geometry(ogr.wkbLinearRing)
        for ordinate_nr in range(start_ordinate-1, end_ordinate-1) :
            if not skip :
                x = ordinates [ ordinate_nr ]
                y = ordinates [ (ordinate_nr + 1) ]
                ring.AddPoint(x,y)
                output_line = str(x) + " " + str(y) + " " + str(ELEMENT_TYPES [int(element_type)]) + "\n"
                fOut.write(output_line)
                skip = True
            else :
                skip = False

        ring.CloseRings()

        # Write blank line to start new element
        fOut.write("\n")

    # Close file
    fOut.close()

    logger.info(str(im_name) + " written to file")

def dump_ps_to_file ( DbConnection ) :
    """Function to dump pointstore points to a file"""

    logger.info( "Dump pointstore points to file" )
    DbCursor           = DbConnection.cursor()
    DbCursor.arraysize = 100000
    DbCursorBlob       =  DbConnection.cursor()

    # Get im to plot
    im_name = get_im_to_plot ( DbCursor )

    # Get limits of IM
    stmt = "select minx, maxx ,miny, maxy from sdb_pointstore_info where instanceid = :ID "
    DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            minx = float(row[0])
            maxx = float(row[1])
            miny = float(row[2])
            maxy = float(row[3])

    # Get query window
    msg          = "Enter query windows in x and y"
    title        = "Query window definition"
    bound_params = ["Minimum X","Maximum X","Minimum Y","Maximum Y"]
    bound_values = [ minx, maxx, miny, maxy ]  # we start with default values
    bound_values = multenterbox(msg,title, bound_params, bound_values)
    minx = float(bound_values[0])
    maxx = float(bound_values[1])
    miny = float(bound_values[2])
    maxy = float(bound_values[3])

    # Convert coordinates to col, row
    mincol, minrow = get_row_col_in_grid ( DbConnection, minx, miny )
    maxcol, maxrow = get_row_col_in_grid ( DbConnection, maxx, maxy )
    logger.info("Minimum column: " + str(mincol))
    logger.info("Minimum row   : " + str(minrow))
    logger.info("Maximum column: " + str(maxcol))
    logger.info("Maximum row   : " + str(maxrow))

    # Select and open file to save
    fOut = open(filesavebox(msg='Select file', title='File save dialog', default='c://temp'), 'w')
    start_retrieval = time.clock()
    i = 0

    # Get points
    if DB_SELECT :
        logger.info("Get points for " + str(im_name) + " (" + str(PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID]) + ")" )
        stmt = "select x, y, z from table ( sdb_pointstore_pck.readDepthsAsRecord ( :ID, :COL_START, :COL_END, :ROW_START, :ROW_END ) ) where x > :MINX and x < :MAXX and y > :MINY and y < :MAXY"
        DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID], COL_START = mincol, COL_END = maxcol, ROW_START = minrow, ROW_END = maxrow, MINX = minx, MAXX = maxx, MINY = miny, MAXY = maxy )
        while True :
            points = DbCursor.fetchmany()
            if not points :
                break
            else :
                for point in points :
                    i = i + 1
                    output_line = str(point[0]) + " " + str(point[1]) + " " + str(point[2]) + "\n"
                    fOut.write(output_line)
    else :
        logger.info("Parsing LOB on client")
        stmt = "select p.blob_id, p.offset, p.nr_points from sdb_pointstore p where p.instance_id = :ID order by blob_id, offset"
        DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID])
        tiles = DbCursor.fetchall()
        if tiles :
            for tile in tiles :
                blob_id   = int(tile[0])
                offset    = int(tile[1]) + 1
                nr_points = int(tile[2])
                stmt = "select b.blob from sdb_pointstore_blob b where  b.id = :ID"
                DbCursorBlob.execute( stmt, ID = blob_id )
                lob_pointer = DbCursorBlob.fetchone()[0]
                for j in range ( 1, nr_points ) :
                    bytes_read = lob_pointer.read(offset,struct.calcsize("<ddd"))
                    if not bytes_read :
                        break
                    else :
                        point = struct.unpack("<ddd", bytes_read)
                        output_line = str(float(point[0])) + " " + str(float(point[1]))  + " " + str(float(point[2])) + "\n"
                        fOut.write(output_line)
                        i = i + 1
                    offset = offset + struct.calcsize("<ddd")

    # Close file
    fOut.close()

    # Calculate duration and show duration
    duration = (time.clock() - start_retrieval)
    logger.info( str(i) + " points retrieved in " + str(duration)+ " seconds" )

def get_row_col_in_grid ( DbConnection, x, y ) :

    # First get grid properties
    DbCursor = DbConnection.cursor()
    stmt = "select max(row_nr), max(col_nr) from  sdb_pointstore where instance_id = :ID "
    DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            max_row_nr = int(row[0])
            max_col_nr = int(row[1])
    stmt = "select minx, maxx ,miny, maxy from sdb_pointstore_info where instanceid = :ID "
    DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            minx = float(row[0])
            maxx = float(row[1])
            miny = float(row[2])
            maxy = float(row[3])
    gridsize_x = float((maxx - minx)/max_col_nr)
    gridsize_y = float((maxy - miny)/max_row_nr)
    logger.info("Gridsize in x direction: " + str(gridsize_x))
    logger.info("Gridsize in y direction: " + str(gridsize_y))

    # Now get the column and row for x and y (lower left = 0, 0)
    col = int ( round ( ( x - minx ) / float(gridsize_x) , 0 ) )
    row = int ( round ( ( y - miny ) / float(gridsize_y) , 0 ) )

    return col, row


def plot_im ( DbConnection ) :
    """Function to plot points of individual model"""

    logger.info( "Plot individual model points" )

    DbCursor     = DbConnection.cursor()

    # Set coordinate system in and out and coordinate transformation
    epsg_code_in     = 4326
    source_srs       = osr.SpatialReference()
    source_srs.ImportFromEPSG(int(epsg_code_in))

    ################################
    # Build IM list from database
    ################################

    # Get list of IDs from database
    im_name = get_im_to_plot ( DbCursor )

    ################################
    # Select scalar to display
    ################################

    logger.info("Select which scalar to display")
    msg    = "Which scalar do you want to display?"
    title  = "Scalar selection"
    scalar = choicebox(msg, title, SCALARS )

    ################################
    # Get hull of individual model
    ################################

    logger.info( "Get geometry for object instance " + str(PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID]) + " from object class " + str(PARAMETER_LIST_VALUE[OBJECT_CLASS_ID]) )  

    geom_cursor = DbCursor.callfunc("sdb_interface_pck.getGeomAsWkt", cx_Oracle.CURSOR, [ PARAMETER_LIST_VALUE[OBJECT_CLASS_ID], PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID], PARAMETER_LIST_VALUE[GEOM_COL] ])
    for geom in geom_cursor :
        geom_wkt = str(geom[1])
    ogr_geom_in = ogr.CreateGeometryFromWkt(geom_wkt)

    ####################
    # Process hull
    ####################

    logger.info( "Process geometry " + str(ogr_geom_in.GetGeometryName()) )

    plot_geometry ( ogr_geom_in, 'r', 'b' )

    logger.info ( "IM geometry processed and plotted" )

    ########################################################
    # Get shallowest and deepest point for IM from database
    ########################################################

    logger.info("Get shallowest and deepest point of IM from database")

    # Build database connection
    OracleConnection = DbConnectionClass ( PARAMETER_LIST_VALUE[ DB_USER_SOURCE ], PARAMETER_LIST_VALUE[ DB_PASSWORD_SOURCE ], PARAMETER_LIST_VALUE[ DB_TNS_SOURCE ], "MyGIS" )

    # Based on ID get pointstore metadata
    l_ps_info_id = OracleConnection.get_pointstore_info_id ( PARAMETER_LIST_VALUE [ OBJECT_INSTANCE_ID ] )
    attributes   = [ PS_MIN_DEPTH, PS_MAX_DEPTH, PS_NR_POINTS ]
    values       = OracleConnection.get_obj_attributes ( PS_INFO_CLASS_ID, l_ps_info_id, attributes )
    shallowest   = float(values[0])
    deepest      = float(values[1])
    nr_of_points = int(values[2])

    depth_range = abs(deepest - shallowest)

    logger.info("Shallowest point of IM = " + str(shallowest))
    logger.info("Deepest point of IM    = " + str(deepest))
    logger.info("Depth range            = " + str(depth_range))
    logger.info("Number of points       = " + str(nr_of_points))

    ################################################
    # Get points for individualmodel from database
    ################################################

    # Determine which select query to use
    logger.info( "Build sql queries" )
    # First get grid properties
    stmt = "select min(row_nr), max(row_nr), min(col_nr), max(col_nr) from  sdb_pointstore where instance_id = :ID "
    DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            min_row_nr = int(row[0])
            max_row_nr = int(row[1])
            min_col_nr = int(row[2])
            max_col_nr = int(row[3])
    stmt = "select minx, maxx ,miny, maxy from sdb_pointstore_info where instanceid = :ID "
    DbCursor.execute(stmt, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            minx = float(row[0])
            maxx = float(row[1])
            miny = float(row[2])
            maxy = float(row[3])
    gridsize_x = float((maxx - minx)/max_col_nr)
    gridsize_y = float((maxy - miny)/max_row_nr)
    logger.info("Gridsize in x direction: " + str(gridsize_x))
    logger.info("Gridsize in y direction: " + str(gridsize_y))
    if scalar == DEPTH :
        scalar_column = "Z_AVG"
    if scalar == AVG_DEPTH :
        scalar_column = "Z_AVG"
    if scalar == NR_DEPTHS :
        scalar_column = "NR_POINTS"

    # Get limits of gridcells
    msg          = "Enter query windows in rows and columns"
    title        = "Query window definition"
    bound_params = ["Minimum column","Maximum column","Minimum row","Maximum row"]
    bound_values = [ min_col_nr, max_col_nr, min_row_nr, max_row_nr ]  # we start with default values
    bound_values = multenterbox(msg,title, bound_params, bound_values)
    min_col_nr = int(bound_values[0])
    max_col_nr = int(bound_values[1])
    min_row_nr = int(bound_values[2])
    max_row_nr = int(bound_values[3])

    stmt_grids  = 'select ' + str(minx) + ' + ' + str(gridsize_x) + '*col_nr, ' +  str(miny) + ' + ' + str(gridsize_y) + '*row_nr, ' + str(scalar_column) + ' from sdb_pointstore where instance_id = :ID and col_nr >= ' + str(min_col_nr) + ' and col_nr <= ' + str(max_col_nr) + ' and row_nr >= ' + str(min_row_nr) + ' and row_nr <= '  + str(max_row_nr)
    stmt_cnts   = 'select sum(nr_points) from sdb_pointstore where instance_id = :ID and col_nr >= ' + str(min_col_nr) + ' and col_nr <= ' + str(max_col_nr) + ' and row_nr >= ' + str(min_row_nr) + ' and row_nr <= '  + str(max_row_nr)
    stmt_depths = 'select x, y, z  from table ( sdb_pointstore_pck.readDepthsAsRecord ( :ID, :MINCOL, :MAXCOL, :MINROW, :MAXROW, :NR  ) ) '

    # Get gridcells from database
    logger.info( "Execute query and get gridcells from database" )
    x_g = []
    y_g = []
    z_g = []
    i = int(0)
    j = int(0)
    DbCursor.arraysize = 100000
    DbCursor.execute(stmt_grids, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
    while 1 :
        resultset = DbCursor.fetchmany()
        if not resultset :
            break
        else :
            for row in resultset :
                x_v = float(row[0])
                y_v = float(row[1])
                z_v = float(row[2])
                if i == 0 :
                    x_min = x_v
                    x_max = x_v
                    y_min = y_v
                    y_max = y_v
                    z_min = z_v
                    z_max = z_v
                    x_g.append(x_v)
                    y_g.append(y_v)
                    z_g.append(z_v)
                    j = j + 1
                else :
                    if x_v < x_min :
                        x_min = x_v
                    if x_v > x_max :
                        x_max = x_v
                    if y_v < y_min :
                        y_min = y_v
                    if y_v > y_max :
                        y_max = y_v
                    if z_v < z_min :
                        z_min = z_v
                    if z_v > z_max :
                        z_max = z_v
                    x_g.append(x_v)
                    y_g.append(y_v)
                    z_g.append(z_v)
                    j = j + 1
                i = i + 1
    nr_gridcells = int(j)
    logger.info( str(nr_gridcells) + " gridcells read from database" )

    # Execute query and get depths
    if scalar == DEPTH :
        DbCursor.execute(stmt_cnts, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID] )
        resultset = DbCursor.fetchmany()
        if resultset :
            for row in resultset :
                nr_of_points = int(row[0])
            logger.info("Number of points to plot: " + str(nr_of_points))
        if nr_of_points > MAX_NR_POINTS :
            nr_of_points = MAX_NR_POINTS
        logger.info("Number of points to plotted: " + str(nr_of_points))
        logger.info( "Execute query and get depths from database" )
        x = []
        y = []
        z = []
        i = int(0)
        j = int(0)
        DbCursor.arraysize = 100000
        DbCursor.execute(stmt_depths, ID = PARAMETER_LIST_VALUE[OBJECT_INSTANCE_ID], MINCOL = min_col_nr, MAXCOL = max_col_nr, MINROW = min_row_nr, MAXROW = max_row_nr, NR = nr_of_points )
        while 1 :
            resultset = DbCursor.fetchmany()
            if not resultset :
                break
            else :
                for row in resultset :
                    x_v = float(row[0])
                    y_v = float(row[1])
                    z_v = float(row[2])
                    if i == 0 :
                        x_min = x_v
                        x_max = x_v
                        y_min = y_v
                        y_max = y_v
                        z_min = z_v
                        z_max = z_v
                        x.append(x_v)
                        y.append(y_v)
                        z.append(z_v)
                        j = j + 1
                    else :
                        if x_v < x_min :
                            x_min = x_v
                        if x_v > x_max :
                            x_max = x_v
                        if y_v < y_min :
                            y_min = y_v
                        if y_v > y_max :
                            y_max = y_v
                        if z_v < z_min :
                            z_min = z_v
                        if z_v > z_max :
                            z_max = z_v
                        x.append(x_v)
                        y.append(y_v)
                        z.append(z_v)
                        j = j + 1
                    i = i + 1
        logger.info( str(j) + " points read from database" )

    # Now plot the gridcells
    msg = "Do you want to plot gridcells?"
    title = "Please Confirm"
    if ccbox(msg, title):     # show a Continue/Cancel dialog
        if nr_gridcells > 0 :
            if nr_gridcells > 500  :
                nr_gridcells = 500
            logger.info( "Plot first " + str(nr_gridcells) + " gridcells" )
            nr_c = 0
            for nr_c in range(nr_gridcells) :
                x_c = float(x_g[nr_c])
                y_c = float(y_g[nr_c])
                gridcell = ogr.Geometry(ogr.wkbPolygon)
                exterior = ogr.Geometry(ogr.wkbLinearRing)
                exterior.AddPoint( x_c - 0.5*gridsize_x ,y_c - 0.5*gridsize_y )
                exterior.AddPoint( x_c + 0.5*gridsize_x ,y_c - 0.5*gridsize_y )
                exterior.AddPoint( x_c + 0.5*gridsize_x ,y_c + 0.5*gridsize_y )
                exterior.AddPoint( x_c - 0.5*gridsize_x ,y_c + 0.5*gridsize_y )
                exterior.CloseRings()
                gridcell.AddGeometry(exterior)
                plot_geometry ( gridcell, 'g', 'g' )
                nr_c = nr_c + 1

    # Plot points
    logger.info("Plot scalar")
    if scalar == AVG_DEPTH or scalar == NR_DEPTHS :
        pylab.scatter(x_g,y_g,c=z_g,edgecolors='none',vmin=z_min,vmax=z_max)
        pylab.colorbar()
    if scalar == DEPTH :
        pylab.scatter(x,y,c=z,edgecolors='none',vmin=z_min,vmax=z_max)
        pylab.colorbar()

    # Show display the plot on screen
    show_plot ( im_name )

    logger.info( "Plot individual model points completed" )

def get_im_to_plot ( DbCursor ) :
    """Function to select archived or published IM"""

    # Get list of IDs from database
    im_name_list = []
    stmt  = "select i.name from sdb_individualmodel i, sdb_pointstore_info p where i.id = p.instanceid"
    DbCursor.arraysize = 100000
    DbCursor.execute(stmt)
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            im_name_list.append(str(row[0]))

    # Popup select box
    msg     = "Select individual model"
    title   = "Individual model"
    im_name = choicebox(msg, title, im_name_list)

    stmt  = "select id, sys026 from sdb_individualmodel where name = :NAME"
    DbCursor.execute(stmt, NAME = im_name )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            PARAMETER_LIST_VALUE [ OBJECT_INSTANCE_ID ] = int(row[0])

    return im_name

def show_plot ( label ) :

    logger.info( "Plot image" )

    pylab.axis('equal')
    pylab.xlabel("Longitud")
    pylab.ylabel("Latitud")
    pylab.grid(True)
    pylab.title("Individual model " + str(label) )
    pylab.show()

####################################
# Functions to build dropdown list
####################################

def get_table_name ( DbCursor, object_class_id ) :
    stmt  = "select object_class_table from sdb_object_class where id = :ID"
    DbCursor.execute(stmt, ID = object_class_id )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            object_class_name = str(row[0])
    return object_class_name

def get_list ( DbCursor, object_class_id, where_clause ) :
    """Function to get list"""
    name_list = []
    stmt = "select name from " + get_table_name ( DbCursor, object_class_id ) + str(" ") +  str(where_clause)
    DbCursor.arraysize = 100000
    DbCursor.execute(stmt)
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            name_list.append(str(row[0]))
    return name_list

def get_id ( DbCursor, object_class_id, object_class_name ) :
    stmt  = "select id from " + get_table_name ( DbCursor, object_class_id ) + " where name = :NAME"
    DbCursor.execute(stmt, NAME = object_class_name )
    resultset = DbCursor.fetchmany()
    if resultset :
        for row in resultset :
            id = int(row[0])
    return id

def select_from_dropdown_list ( DbCursor, object_class_id, msg, title, where_clause ) :
    return int(get_id ( DbCursor, object_class_id, choicebox(msg, title, get_list( DbCursor, object_class_id, where_clause ) ) ) )

####################################
# Start main program
####################################

if __name__ == "__main__":

    # Initialize logger
    logger      = logging.getLogger(MODULE_NAME)
    level       = LOGLEVELS.get(LOG_LEVEL, logging.NOTSET)
    logger.setLevel( level )
    stream_hdlr = logging.StreamHandler()
    formatter   = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_hdlr.setFormatter(formatter)
    logger.addHandler(stream_hdlr)

    ############################
    # Database connection
    ############################

    db_connection_input ()

    logger.info( "Build database connection to " + str(PARAMETER_LIST_VALUE[ DB_USER_SOURCE ]) )
    DbConnection = cx_Oracle.connect( PARAMETER_LIST_VALUE[ DB_USER_SOURCE ], PARAMETER_LIST_VALUE[ DB_PASSWORD_SOURCE ], PARAMETER_LIST_VALUE[ DB_TNS_SOURCE ])

    # Start gui
    gui_start ( DbConnection )
    
