#! /usr/bin/python

""" Function to import survey into database
"""

# Standard library imports
import os
import struct
#import sys
import binascii
import logging
import time


# Related third party imports
import cx_Oracle
from easygui import *

# Module name
MODULE_NAME = "DBA_app"

# Logging levels
LOG_LEVEL = 'info'
LOGLEVELS = {'debug'   : logging.DEBUG,
             'info'    : logging.INFO,
             'warning' : logging.WARNING,
             'error'   : logging.ERROR,
             'critical': logging.CRITICAL}

# DB connect Parameters
DB_USER_SOURCE       = "DB_USER_SOURCE"
DB_PASSWORD_SOURCE   = "DB_PASSWORD_SOURCE"
DB_TNS_SOURCE        = "DB_TNS_SOURCE"

# Database connection parameter values
PARAMETER_LIST_VALUE = {}
PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "sens"
PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "senso"
PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "10.20.0.49/sens11"
#PARAMETER_LIST_VALUE [ DB_USER_SOURCE ]     = "mtj"
#PARAMETER_LIST_VALUE [ DB_PASSWORD_SOURCE ] = "mtj"
#PARAMETER_LIST_VALUE [ DB_TNS_SOURCE ]      = "localhost/mtj"

# Menu options
DB_CONNECTION    = "DB_CONNECTION"
SELECT_QUERY     = "EXECUTE_QUERY"
SELECT_GRIDCELLS = "SELECT_GRIDCELLS"
WRITE_BIN_FILE   = "WRITE_BIN_FILE"
IMPORT_GRID      = "IMPORT_GRID"
EXIT             = "EXIT"

# Menu options dictionary
MENU_OPTIONS = {}
MENU_OPTIONS [ DB_CONNECTION ]    = "Set DB connection parameters"
MENU_OPTIONS [ SELECT_QUERY ]     = "Select query"
MENU_OPTIONS [ SELECT_GRIDCELLS ] = "Select gridcells"
MENU_OPTIONS [ WRITE_BIN_FILE ]   = "Write binary file"
MENU_OPTIONS [ IMPORT_GRID ]      = "Import grid"
MENU_OPTIONS [ EXIT ]             = "Exit"

# Database queries
SGA_USAGE = "SGA_USAGE"

# Dictionary with queries
QUERY_DICTIONARY = {}
QUERY_DICTIONARY [ SGA_USAGE ] = "select pool, name, round(bytes/1024/1024) size_in_mb from v$sgastat v where round(bytes/1024/1024) >= 1 order by 3 desc"

# Business object class
BUSINESS_OBJECT_CLASS = 172997

def a2b(a): 
    ai = ord(a) 
    return ''.join('01'[(ai >> x) & 1] for x in xrange(7, -1, -1))



#########################################
# GUI functions
#########################################

def gui_start () :
    logger.info("Start GUI")
    while True :
        msg   = "What do you want?"
        title = 'DBA application'
        buttons = [ MENU_OPTIONS [ DB_CONNECTION ], MENU_OPTIONS [ SELECT_QUERY ], MENU_OPTIONS [ WRITE_BIN_FILE ], MENU_OPTIONS [ SELECT_GRIDCELLS ], MENU_OPTIONS [ IMPORT_GRID ], MENU_OPTIONS [ EXIT ] ]
        reply   = buttonbox ( msg, title, buttons)
        if reply == MENU_OPTIONS [ DB_CONNECTION ] :
            oracle_connection, oracle_cursor  = gui_open_db_connection ()
        if reply == MENU_OPTIONS [ SELECT_QUERY ] :
            gui_select_query ( oracle_cursor )
        if reply == MENU_OPTIONS [ SELECT_GRIDCELLS ] :
            gui_select_gridcells ( oracle_cursor)
        if reply == MENU_OPTIONS [ WRITE_BIN_FILE ] :
            gui_write_binary_file ( oracle_cursor )
        if reply == MENU_OPTIONS [ IMPORT_GRID ] :
            gui_import_grid ( oracle_cursor )
        elif reply == MENU_OPTIONS [ EXIT ] :
            oracle_cursor.close()
            oracle_connection.commit()
            oracle_connection.close()
            break

def gui_open_db_connection () :
    logger.info("Open database connection GUI")
    title = 'Database connection parameters'
    msg   = "Enter database connection parameters "
    field_names   = [ DB_TNS_SOURCE, DB_USER_SOURCE , DB_PASSWORD_SOURCE ]
    return_values = [ PARAMETER_LIST_VALUE [DB_TNS_SOURCE], PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE[DB_PASSWORD_SOURCE] ]
    return_values = multpasswordbox( msg,title, field_names, return_values)
    if return_values :
        PARAMETER_LIST_VALUE [DB_TNS_SOURCE]      = return_values[0]
        PARAMETER_LIST_VALUE [DB_USER_SOURCE]     = return_values[1]
        PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE] = return_values[2]
    logger.info("Open database connection")
    oracle_connection = cx_Oracle.connect(PARAMETER_LIST_VALUE [DB_USER_SOURCE], PARAMETER_LIST_VALUE [DB_PASSWORD_SOURCE], PARAMETER_LIST_VALUE [DB_TNS_SOURCE])
    oracle_cursor     = oracle_connection.cursor()
    return oracle_connection, oracle_cursor

def gui_select_query ( oracle_cursor ) :
    logger.info("Show list with queries")
    title = 'Available queries'
    msg   = "Select query "
    choices = [ SGA_USAGE ]
    choice  = choicebox (msg, title, choices )
    query   = QUERY_DICTIONARY [ choice ]
    logger.info("Query: " + str(query))
    execute_query ( oracle_cursor, query )

def gui_select_gridcells ( oracle_cursor ) :

    #select_opt = int(1)
    #select_opt = int(2)
    #select_opt = int(3)
    select_opt = int(4)
    im_id      = 2
    oracle_cursor.arraysize = 100000
#
#
#    # Selection point by point
    if select_opt == int(1):
        start_retrieval = time.clock()
        logger.info("Select point by point and write to file")
        # Read grid from database and store in file
        output_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_output.xyz'
        fOut       = open( output_file, 'w')
        stmt       = "select /*+ RULE */ row_nr, col_nr, depth_avg from mtj_ps_gridcells s where im_id = :IM_ID and s.row_nr = :ROW_NR and s.col_nr = :COL_NR and rownum = 1"
        j = 0
        n = 0
        for r in range(1, 113 ):
            for c in range ( 1, 77 ) :
                oracle_cursor.execute(stmt, IM_ID = im_id, ROW_NR = r , COL_NR = c )
                n = n + 1
                resultset = oracle_cursor.fetchmany()
                if resultset :
                    for row in resultset :
                        j = j + 1
                        line = str(row[0]) + " " + str(row[1]) + " " + str(row[2]) + "\n"
                        fOut.write(line)
        fOut.close()
        duration = str(round(time.clock() - start_retrieval,0))
        msgbox(str(n) + " queries executed in " + duration + " seconds" )
#
#    # Select by range
#    if select_opt == int(2):
#        logger.info("Selection by range")
#        i          = 1
#        j          = 0
#        stmt       = "select /*+ RULE */ depth_avg from mtj_visualisation_grids s where im_id = :IM_ID and s.row_nr > 1 and s.row_nr <1000 and s.col_nr > 1 and s.col_nr < 1000 "
#        oracle_cursor.execute(stmt, IM_ID = im_id )
#        resultset = oracle_cursor.fetchmany()
#        while 1 :
#            resultset = oracle_cursor.fetchmany()
#            if not resultset :
#                break
#            else :
#                for row in resultset :
#                    j = j + 1
#                    grid_list.append(str(row[0]))

    # Select all
    if select_opt == int(3):
        start_retrieval = time.clock()
        logger.info("Select all and write to file")
        # Read grid from database and store in file
        output_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_output.xyz'
        fOut       = open( output_file, 'w')
        j          = 0
        #stmt       = "select row_nr, col_nr, depth_avg from mtj_ps_gridcells s where im_id = :IM_ID"
        stmt       = "select /*+ RULE */ row_nr, col_nr, depth_avg from mtj_ps_gridcells s where im_id = :IM_ID and s.row_nr >= 1 and s.row_nr <= 113 and s.col_nr >= 1 and s.col_nr <= 77 "
        oracle_cursor.execute(stmt, IM_ID = im_id )
        while 1 :
            resultset = oracle_cursor.fetchmany()
            if not resultset :
                break
            else :
                for row in resultset :
                    j = j + 1
                    line = str(row[0]) + " " + str(row[1]) + " " + str(row[2]) + "\n"
                    fOut.write(line)
                    #grid_list.append(str(row[0]))
        fOut.close()
        logger.info("Depths written to file " + str(output_file))
        # Calculate duration
        duration = str(round(time.clock() - start_retrieval,0))
        msgbox(str(j) + " points retrieved in " + duration + " seconds" )

    if select_opt == int(4) :
        start_retrieval = time.clock()
        logger.info("Select points from BLOB")
        output_file_bin  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_blob_output.bin'
        output_file_asc = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_blob_output.asc'
        fOut       = open( output_file_bin, 'wb')
        j          = 0

        # Write depths to binary file
        logger.info("Write depths to binary file")
        stmt = 'select depths from mtj_ps_depths where im_id = :IM_ID and rownum = 1'
        oracle_cursor.execute(stmt, IM_ID = im_id )
        resultset = oracle_cursor.fetchmany()
        for row in resultset :
            depth_data = row[0].read()
            fOut.write( depth_data )
        fOut.close()
        # Calculate duration
        duration = str(round(time.clock() - start_retrieval,0))
        msgbox(str(j) + " points retrieved in " + duration + " seconds" )

        # Write depths to ascii file
        logger.info("Write depths to ascii file")
        fIn  = open( output_file_bin, 'rb')
        fOut = open( output_file_asc, 'w')
        while True:
            bytes_read = fIn.read(struct.calcsize("<fff"))
            if not bytes_read:
                break
            try :
                data = struct.unpack("<fff", bytes_read)
                line = str(data[0]) + " " + str(data[1]) + " " + str(data[2])
                print line
            except :
                logger.info("Error reading bytes")
        fIn.close()
        fOut.close()




def gui_store_grid ( oracle_cursor ) :
    None

#    # Store gridcells in database
#
#                    depths.append( ( float(c[0]), float(c[1]), float(c[2]), str(c[3]), str(c[4]), str(c[5]), str(c[6]), str(c[7]), str(c[8]), str(c[9]), str(c[10]), str(c[11]), str(c[12]) ) )
#                i = i + 1
#
#            if i % BathyDbLib.NR_OF_ROWS_PER_INSERT == 0 or i == nr_of_lines:
#                DbConnection.insert_depth( insert_stmt, depths )
#
#
#    l_insert = self.oracle_cursor.callfunc("sdb_interface_pck.getclientdml", str, [insert_stmt_id])
#    oracle_cursor.prepare( l_insert )
#    oracle_cursor.executemany(None, depths)


def gui_write_binary_file ( oracle_cursor ) :

    #  Read ascii file and write binary file
    title        = 'Inputfile selection'
    msg          = 'Select inputfile'
    input_file   = 'D:/Geodata/USA/Bathymetry/Portsmouth/H07140.xyz'
    input_file   = fileopenbox(msg, title, input_file)
    output_dir   = os.path.dirname( input_file )
    output_file  = os.path.basename( input_file ).split(".")[0] + str(".bin")
    asc_file_out = os.path.basename( input_file ).split(".")[0] + str(".asc")
    logger.info("Output file : " + str(output_dir)  )
    logger.info("Output dir  : " + str(output_file) )
    os.chdir(output_dir)
    # Write binary file
    logger.info("Write binary file")
    fIn  = open( input_file , 'r')
    fOut = open( output_file, 'wb')
    for line in fIn :
        line_items = line.split()
        for i in range (0,len(line_items)) :
            data = struct.pack('f', float(line_items[i]))
            fOut.write(data)
    fIn.close()
    fOut.close()

    # Write ascii file
    fIn  = open( output_file , 'r')
    fOut = open( asc_file_out, 'w')
    logger.info("Write ascii file")
    while True:
        bytes_read = fIn.read(struct.calcsize("<fff"))
        if not bytes_read:
            break
        try :
            data = struct.unpack("<fff", bytes_read)
        except :
            logger.info("Error reading bytes")
        fOut.write(str(data))
    fIn.close()
    fOut.close()

#    # Store binary file as blob
#    logger.info("Store file as BLOB in database")
#    nr_of_inserts       = 0
#    max_nr_of_inserts   = 10
#    start_retrieval     = time.clock()
###################################################################
##    inputs = []
##    inputs.append(open(output_file, 'rb'))
##    while True :
##        for input in inputs:
##            binary_data = input.read()
##            blobfile = oracle_cursor.var(cx_Oracle.BLOB)
##            blobfile.setvalue(0, binary_data)
##        stmt = 'insert into mtj_depth_blob ( mtj_blob ) values ( :DEPTHS )'
##        oracle_cursor.execute( stmt, DEPTHS = blobfile )
##        nr_of_inserts = nr_of_inserts + 1
##        if nr_of_inserts == max_nr_of_inserts :
##                break
###################################################################
##    blobdata = oracle_cursor.var(cx_Oracle.BLOB)
##    stmt     = 'insert into mtj_depth_blob ( mtj_blob ) values ( :DEPTHS )'
##    while True :
##        blobdata.setvalue(0, open(output_file, 'rb').read() )
##        oracle_cursor.execute( stmt, DEPTHS = blobdata )
##        nr_of_inserts = nr_of_inserts + 1
##        if nr_of_inserts == max_nr_of_inserts :
##            break
###################################################################
#    input_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_small.xyz'
#
#    # Count number of lines
#    logger.info("Count number of lines in file")
#    fIn = open(input_file,'r')
#    nr_of_lines = 0
#    for line in fIn :
#        nr_of_lines = nr_of_lines + 1
#    fIn.close()
#    logger.info(str(nr_of_lines) + " in file")
#
#    logger.info("Start storing gridcells in database")
#    start_retrieval = time.clock()
#    i           = 0
#    insert_list = []
#    point_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/H00741A.bin'
#    blobdata    = oracle_cursor.var(cx_Oracle.BLOB)
#    stmt        = 'insert into MTJ_VIS_GRID_BLOB ( row_nr, col_nr, depth_avg ) values ( :1, :2, :3 ) '
#
#    # Add row and col to DB
#    fIn         = open(input_file, 'r')
#    blobdata.setvalue(0, open(point_file, 'rb').read() )
#    for line in fIn:
#        i = i + 1
#        #logger.info("Process line " + str(i))
#        items = line.split()
#        insert_list.append (( int(items[0]), int(items[1]), float(items[2]) ))
#        if i % 10000 == 0 or i == nr_of_lines:
#            logger.info("Insert")
#            oracle_cursor.prepare( stmt )
#            oracle_cursor.executemany(None, insert_list)
#            logger.info(str(i) + " gridcells written to database")
#            insert_list = []
#    fIn.close()
#    # Calculate duration
#    duration = str(round(time.clock() - start_retrieval,0))
#    logger.info("Insert gridcells in " + str(duration) + " seconds")
#
#    # Add depths BLOB
#    logger.info("Start storing depth BLOBs database")
#    start_retrieval = time.clock()
#    stmt        = 'insert into MTJ_VIS_GRID_BLOB ( depth_points ) values ( :DEPTHS ) '
#    fIn         = open(input_file, 'r')
#    i           = 0
#    blobdata.setvalue(0, open(point_file, 'rb').read() )
#    for line in fIn:
#        i = i + 1
#        oracle_cursor.execute( stmt, DEPTHS = blobdata )
#        if i % 10000 == 0 or i == nr_of_lines:
#            logger.info(str(i) + " depth blobs inserted")
#    fIn.close()
#    logger.info(str(i) + " depth BLOBs written to database")
#    # Calculate duration
#    duration = str(round(time.clock() - start_retrieval,0))
#    logger.info("Insert depth BLOBs in " + str(duration) + " seconds")
#
#    # Calculate duration
#    duration = str(round(time.clock() - start_retrieval,0))
#    logger.info("In " + str(duration) + " seconds")
#    #msgbox("Duration of inserts of " + str(max_nr_of_inserts) + " BLOBS is " + duration + " seconds" )

def gui_import_grid ( oracle_cursor ) :

    # Function to import grid and depths into database
    grid_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_small.xyz'
    #grid_file  = 'D:/Geodata/USA/Bathymetry/Portsmouth/SENS_GRID_even_smaller.xyz'
    point_file = 'D:/Geodata/USA/Bathymetry/Portsmouth/H00741B.bin'

    # ID of IM to load grid for
    im_id = 2

    # Get tmp table names from database
    grid_table  = oracle_cursor.var(cx_Oracle.STRING)
    point_table = oracle_cursor.var(cx_Oracle.STRING)

    # Create tmp tables in database
    oracle_cursor.callproc('mtj_create_import_tables',[im_id, grid_table, point_table])
    logger.info("Grid table  is " + str(grid_table.getvalue())  )
    logger.info("Point table is " + str(point_table.getvalue()) )

    # Count number of lines in gridfile
    logger.info("Count number of lines in file")
    fIn = open(grid_file,'r')
    nr_of_lines = 0
    for line in fIn :
        nr_of_lines = nr_of_lines + 1
    fIn.close()
    logger.info(str(nr_of_lines) + " lines in file")

    # Store grids in database
    logger.info("Start storing gridcells in database")
    start_retrieval = time.clock()
    i           = 0
    insert_list = []
    nr_depths   = 1
    blobdata    = oracle_cursor.var(cx_Oracle.BLOB)
    stmt_g      = 'insert into ' + str(grid_table.getvalue())  + ' ( row_nr, col_nr, depth_avg, depth_min, depth_max, nr_depths, im_id ) values ( :1, :2, :3, :4, :5, :6, :7 ) '
    stmt_p      = 'insert into ' + str(point_table.getvalue()) + ' ( row_nr, col_nr, depths, im_id ) values ( :1, :2, :3, :4 ) '
    blobdata.setvalue(0, open(point_file, 'rb').read() )
    fIn         = open(grid_file, 'r')
    for line in fIn:
        i = i + 1
        # Add items to append list grids
        insert_list.append (( int(line.split()[0]), int(line.split()[1]), float(line.split()[2]), float(line.split()[2]), float(line.split()[2]), nr_depths, im_id ))
        # Insert depth blob
        oracle_cursor.execute( stmt_p, ( int(line.split()[0]), int(line.split()[1]), blobdata, im_id ) )
        # Store grids every 10000 cells
        if i % 10000 == 0 or i == nr_of_lines:
            oracle_cursor.prepare( stmt_g )
            oracle_cursor.executemany(None, insert_list)
            logger.info(str(i) + " gridcells written to database")
            insert_list = []
    fIn.close()
    duration = str(round(time.clock() - start_retrieval,0))
    logger.info("Gridcells inserted in " + str(duration) + " seconds")

    # Store grids in database
#    logger.info("Start storing depths in database")
#    start_retrieval = time.clock()
#    i           = 0
#    blobdata    = oracle_cursor.var(cx_Oracle.BLOB)
#    stmt_p      = 'insert into ' + str(point_table.getvalue()) + ' ( row_nr, col_nr, depths, im_id ) values ( :1, :2, :3, :4 ) '
#    blobdata.setvalue(0, open(point_file, 'rb').read() )
#    fIn         = open(grid_file, 'r')
#    for line in fIn:
#        i = i + 1
#        # Insert depth blob
#        oracle_cursor.execute( stmt_p, ( int(line.split()[0]), int(line.split()[1]), blobdata, im_id ) )
#        if i % 10000 == 0 or i == nr_of_lines:
#            logger.info(str(i) + " depths written to database")
#    fIn.close()
#    duration = str(round(time.clock() - start_retrieval,0))
#    logger.info("Depths inserted in " + str(duration) + " seconds")

    # Create indexes and add partitions to tables
    logger.info("Create indexes and add partitions to tables")
    start_retrieval = time.clock()
    oracle_cursor.callproc('mtj_commit_import',[im_id, grid_table.getvalue(), point_table.getvalue()])
    duration = str(round(time.clock() - start_retrieval,0))
    logger.info("Indexes created in " + str(duration) + " seconds")

def execute_query ( oracle_cursor, query ) :
    logger.info("Execute query")
    columns = get_columns ( query )
    oracle_cursor.execute( query )
    rows = oracle_cursor.fetchall ()
    if rows :
        result_list = []
        for row in rows :
            record_str = str(row[0]) + "      " + str(row[1]) + "      " + str(row[2]) + "\n"
            result_list.append (record_str)
        textbox (columns, "Found records:", result_list)

def get_columns ( query ) :
    columns = ''
    item_list = query.rstrip().split(',')
    for item in item_list :
        item_upper   = str.upper( str(item) )
        if 'SELECT' in item_upper :
            element_list = item_upper.rstrip().split()
            if len(element_list) == 2 :
                column = element_list[1]
            elif len(element_list) == 3 :
                column = element_list[2]
            columns = columns + column
        elif 'FROM' not in item_upper :
            element_list = item_upper.rstrip().split()
            if len(element_list) == 1 :
                column = element_list[0]
            elif len(element_list) == 2 :
                column = element_list[1]
            columns = columns + '       ' + column
        else :
            element_list = item_upper.rstrip().split()
            if element_list[1] == 'FROM' :
                column = element_list[0]
            elif element_list[2] == 'FROM' :
                column = element_list[1]
            columns = columns + '       ' + column
    logger.info ( "Columns: " + str(columns) )
    return columns

####################################
# Start main program
####################################

if __name__ == "__main__":

    # Initialize logger
    logger      = logging.getLogger(MODULE_NAME)
    level       = LOGLEVELS.get(LOG_LEVEL, logging.NOTSET)
    logger.setLevel( level )
    stream_hdlr = logging.StreamHandler()
    formatter   = logging.Formatter("%(asctime)s - %(name)s - %(levelname)s - %(message)s")
    stream_hdlr.setFormatter(formatter)
    logger.addHandler(stream_hdlr)

    # Start gui
    gui_start ()
    
